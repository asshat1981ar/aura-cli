// __tests__/plugins/validation/PluginObjectValidator.test.ts
import { validatePluginObject } from '../../../plugins/validation/PluginObjectValidator';
import { IPlugin } from '../../../types/plugin/IPlugin';
import { PluginType } from '../../../types/plugin/PluginType';
import { IWorkflowNodePlugin } from '../../../types/plugin/IWorkflowNodePlugin';
import { IIntegrationPlugin } from '../../../types/plugin/IIntegrationPlugin';
import { IUiExtensionPlugin } from '../../../types/plugin/IUiExtensionPlugin';
import { z } from 'zod';

// Mock simple plugin implementations
const mockPluginContext: any = {}; // Mock as needed

const createMockPlugin = (overrides: Partial<IPlugin> = {}): IPlugin => ({
  id: 'mock-plugin',
  name: 'Mock Plugin',
  version: '1.0.0',
  author: 'Mock Author',
  description: 'A mock plugin for testing.',
  type: PluginType.WorkflowNode, // Default type
  onLoad: jest.fn(async () => {}),
  onUnload: jest.fn(async () => {}),
  ...overrides,
});

const createMockWorkflowNodePlugin = (overrides: Partial<IWorkflowNodePlugin> = {}): IWorkflowNodePlugin => ({
  ...createMockPlugin({ type: PluginType.WorkflowNode }),
  inputs: [{ name: 'in', type: 'string' }],
  outputs: [{ name: 'out', type: 'string' }],
  execute: jest.fn(async () => ({})),
  ...overrides,
});

const createMockIntegrationPlugin = (overrides: Partial<IIntegrationPlugin> = {}): IIntegrationPlugin => ({
  ...createMockPlugin({ type: PluginType.Integration }),
  integratesWith: ['serviceA', 'serviceB'],
  getService: jest.fn(() => ({})),
  ...overrides,
});

const createMockUiExtensionPlugin = (overrides: Partial<IUiExtensionPlugin> = {}): IUiExtensionPlugin => ({
  ...createMockPlugin({ type: PluginType.UiExtension }),
  extensionPoint: 'dashboard.header',
  renderComponent: jest.fn(() => 'div'), // Mock a React ComponentType
  ...overrides,
});


describe('PluginObjectValidator', () => {
  it('should successfully validate a valid WorkflowNode plugin', () => {
    const plugin = createMockWorkflowNodePlugin();
    expect(() => validatePluginObject(plugin, PluginType.WorkflowNode)).not.toThrow();
    const validated = validatePluginObject(plugin, PluginType.WorkflowNode);
    expect(validated.type).toBe(PluginType.WorkflowNode);
  });

  it('should successfully validate a valid Integration plugin', () => {
    const plugin = createMockIntegrationPlugin();
    expect(() => validatePluginObject(plugin, PluginType.Integration)).not.toThrow();
    const validated = validatePluginObject(plugin, PluginType.Integration);
    expect(validated.type).toBe(PluginType.Integration);
  });

  it('should successfully validate a valid UI Extension plugin', () => {
    const plugin = createMockUiExtensionPlugin();
    expect(() => validatePluginObject(plugin, PluginType.UiExtension)).not.toThrow();
    const validated = validatePluginObject(plugin, PluginType.UiExtension);
    expect(validated.type).toBe(PluginType.UiExtension);
  });

  it('should throw ZodError if a required base property is missing', () => {
    const plugin = createMockWorkflowNodePlugin({ id: undefined as any });
    expect(() => validatePluginObject(plugin, PluginType.WorkflowNode)).toThrow(z.ZodError);
    try {
      validatePluginObject(plugin, PluginType.WorkflowNode);
    } catch (e: any) {
      expect(e.issues).toEqual(
        expect.arrayContaining([expect.objectContaining({ path: ['id'] })])
      );
    }
  });

  it('should throw ZodError if WorkflowNode plugin is missing execute method', () => {
    const plugin = createMockWorkflowNodePlugin({ execute: undefined as any });
    expect(() => validatePluginObject(plugin, PluginType.WorkflowNode)).toThrow(z.ZodError);
    try {
      validatePluginObject(plugin, PluginType.WorkflowNode);
    } catch (e: any) {
      expect(e.issues).toEqual(
        expect.arrayContaining([expect.objectContaining({ path: ['execute'] })])
      );
    }
  });

  it('should throw ZodError if Integration plugin is missing integratesWith', () => {
    const plugin = createMockIntegrationPlugin({ integratesWith: undefined as any });
    expect(() => validatePluginObject(plugin, PluginType.Integration)).toThrow(z.ZodError);
    try {
      validatePluginObject(plugin, PluginType.Integration);
    } catch (e: any) {
      expect(e.issues).toEqual(
        expect.arrayContaining([expect.objectContaining({ path: ['integratesWith'] })])
      );
    }
  });

  it('should throw ZodError if UI Extension plugin is missing extensionPoint', () => {
    const plugin = createMockUiExtensionPlugin({ extensionPoint: undefined as any });
    expect(() => validatePluginObject(plugin, PluginType.UiExtension)).toThrow(z.ZodError);
    try {
      validatePluginObject(plugin, PluginType.UiExtension);
    } catch (e: any) {
      expect(e.issues).toEqual(
        expect.arrayContaining([expect.objectContaining({ path: ['extensionPoint'] })])
      );
    }
  });

  it('should throw ZodError if plugin type mismatch', () => {
    const plugin = createMockWorkflowNodePlugin();
    // Try to validate a WorkflowNode plugin as an Integration plugin
    expect(() => validatePluginObject(plugin, PluginType.Integration)).toThrow(z.ZodError);
    try {
      validatePluginObject(plugin, PluginType.Integration);
    } catch (e: any) {
      expect(e.issues).toEqual(
        expect.arrayContaining([expect.objectContaining({ path: ['type'] })])
      );
    }
  });
});
