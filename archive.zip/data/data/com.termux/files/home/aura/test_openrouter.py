import os
import requests
import json

# Simulate ModelAdapter's __init__
openrouter_key = os.getenv("OPENROUTER_API_KEY")

if not openrouter_key:
    print("OPENROUTER_API_KEY is not set in this environment.")
    exit(1)

# Simulate ModelAdapter's call_openrouter
def test_openrouter_call(prompt: str) -> str:
    url = "https://api.openrouter.ai/v1/chat/completions"

    headers = {
        "Authorization": f"Bearer {openrouter_key}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": "openrouter/auto", # Using auto for flexibility
        "messages": [{"role": "user", "content": prompt}]
    }

    try:
        print(f"Attempting call to {url} with model openrouter/auto...")
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        response.raise_for_status() # Raise an exception for HTTP errors

        data = response.json()
        if "choices" in data and data["choices"]:
            return data["choices"][0]["message"]["content"]
        else:
            return f"OpenRouter response missing 'choices': {data}"
    except requests.exceptions.RequestException as e:
        return f"Request failed: {e}"
    except json.JSONDecodeError as e:
        return f"Failed to decode JSON response: {e}, Response content: {response.text}"
    except Exception as e:
        return f"An unexpected error occurred: {e}"

# Run the test
test_prompt = "Hello, OpenRouter! Are you working?"
result = test_openrouter_call(test_prompt)
print("\n--- Test Result ---")
print(result)
