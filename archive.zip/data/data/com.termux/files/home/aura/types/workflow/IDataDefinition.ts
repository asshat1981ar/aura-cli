// types/workflow/IDataDefinition.ts
export interface IDataDefinition {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'object' | 'array' | 'enum' | 'any';
  description?: string;
  required?: boolean;
  defaultValue?: any;
  options?: string[] | number[]; // For 'enum' type
  schema?: Record<string, any>; // For 'object' or 'array' with specific schema (e.g., JSON Schema)
}
