// __tests__/utils/services/GoogleAIService.test.ts
import GoogleAIService from '../../../utils/services/GoogleAIService';
import MultiServiceApiClient from '../../../utils/MultiServiceApiClient';
import { ApiService } from '../../../utils/ApiKeyManager';
import axios from 'axios';

// Mock MultiServiceApiClient to control the axios instance it returns
jest.mock('../../../utils/MultiServiceApiClient', () => ({
  getClient: jest.fn(),
}));

describe('GoogleAIService', () => {
  const mockAxiosInstance = {
    post: jest.fn(),
  } as unknown as axios.AxiosInstance;

  beforeEach(() => {
    jest.clearAllMocks();
    (MultiServiceApiClient.getClient as jest.Mock).mockResolvedValue(mockAxiosInstance);
  });

  describe('chatCompletion', () => {
    const mockMessages = [{ role: 'user', parts: [{ text: 'Hello' }] }];
    const mockResponseData = {
      candidates: [{
        content: { role: 'model', parts: [{ text: 'Hi from Gemini!' }] },
        finishReason: 'STOP',
        index: 0,
      }],
      usageMetadata: { promptTokenCount: 10, candidatesTokenCount: 5, totalTokenCount: 15 },
    };

    it('should call generateContent API with default model', async () => {
      mockAxiosInstance.post.mockResolvedValue({ data: mockResponseData });

      const response = await GoogleAIService.chatCompletion(mockMessages);

      expect(MultiServiceApiClient.getClient).toHaveBeenCalledWith(ApiService.Google);
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/models/gemini-pro:generateContent', {
        contents: mockMessages,
        generationConfig: {
          temperature: undefined,
          candidate_count: undefined,
        },
      });
      expect(response).toEqual(mockResponseData);
    });

    it('should call generateContent API with specified model and options', async () => {
      mockAxiosInstance.post.mockResolvedValue({ data: mockResponseData });

      const options = { model: 'gemini-pro-vision', temperature: 0.7, candidate_count: 2 };
      const response = await GoogleAIService.chatCompletion(mockMessages, options);

      expect(MultiServiceApiClient.getClient).toHaveBeenCalledWith(ApiService.Google);
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/models/gemini-pro-vision:generateContent', {
        contents: mockMessages,
        generationConfig: {
          temperature: 0.7,
          candidate_count: 2,
        },
      });
      expect(response).toEqual(mockResponseData);
    });
  });

  describe('generateEmbedding', () => {
    const mockInput = 'This is a test sentence.';
    const mockResponseData = {
      embeddings: [{ value: [0.1, 0.2, 0.3] }],
    };

    it('should call embedContent API with default model', async () => {
      mockAxiosInstance.post.mockResolvedValue({ data: mockResponseData });

      const response = await GoogleAIService.generateEmbedding(mockInput);

      expect(MultiServiceApiClient.getClient).toHaveBeenCalledWith(ApiService.Google);
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/models/embedding-001:embedContent', {
        content: { parts: [{ text: mockInput }] },
      });
      expect(response).toEqual(mockResponseData);
    });

    it('should call embedContent API with specified model', async () => {
      mockAxiosInstance.post.mockResolvedValue({ data: mockResponseData });

      const model = 'my-custom-embedder';
      const response = await GoogleAIService.generateEmbedding(['sentence1', 'sentence2'], model);

      expect(MultiServiceApiClient.getClient).toHaveBeenCalledWith(ApiService.Google);
      expect(mockAxiosInstance.post).toHaveBeenCalledWith(`/models/${model}:embedContent`, {
        content: { parts: [{ text: 'sentence1' }, { text: 'sentence2' }] },
      });
      expect(response).toEqual(mockResponseData);
    });
  });
});
