// plugins/example/example-workflow-node.ts
import { IWorkflowNodePlugin } from '../../types/plugin/IWorkflowNodePlugin';
import { PluginType } from '../../types/plugin/PluginType';
import { IExecutionContext } from '../../types/workflow/IExecutionContext';
import { IInputDefinition, IOutputDefinition } from '../../types/workflow/IDataDefinition';
import { IPluginContext } from '../../types/plugin/IPluginContext';

class ExampleWorkflowNode implements IWorkflowNodePlugin {
  id = 'com.example.workflow.sum-numbers';
  name = 'Sum Numbers Node';
  version = '1.0.0';
  author = 'AURA Example';
  description = 'A simple workflow node that sums two input numbers.';
  type = PluginType.WorkflowNode;

  inputs: IInputDefinition[] = [
    { name: 'num1', type: 'number', description: 'First number to sum', required: true },
    { name: 'num2', type: 'number', description: 'Second number to sum', required: true },
  ];

  outputs: IOutputDefinition[] = [
    { name: 'sum', type: 'number', description: 'The sum of num1 and num2' },
  ];

  async onLoad(context: IPluginContext): Promise<void> {
    context.logger.info(`Workflow Node '${this.name}' loaded.`);
  }

  async onUnload(context: IPluginContext): Promise<void> {
    context.logger.info(`Workflow Node '${this.name}' unloaded.`);
  }

  async execute(context: IExecutionContext): Promise<{ sum: number }> {
    const { num1, num2 } = context.data;
    if (typeof num1 !== 'number' || typeof num2 !== 'number') {
      context.services.logger.error(`Invalid input for Sum Numbers Node. Expected numbers, got: ${JSON.stringify(context.data)}`);
      throw new Error('Invalid input: num1 and num2 must be numbers.');
    }
    const sum = num1 + num2;
    context.services.logger.info(`Sum Numbers Node executed: ${num1} + ${num2} = ${sum}`);
    return { sum };
  }
}

export default ExampleWorkflowNode;
