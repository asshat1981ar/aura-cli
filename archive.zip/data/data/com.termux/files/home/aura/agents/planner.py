from typing import List
import json
import re # Import re

EVOLUTION_PROMPT = """
You are AURA — an autonomous recursive engineering system.

Current Goal:
{goal}

System State:
- Memory Snapshot: {memory}
- Similar Past Problems: {similar}
- Known Weaknesses: {weakness}

You must:

1. Analyze structural gaps.
2. Propose capability upgrades.
3. Design execution steps.
4. Predict failure modes.
5. Suggest improvements to your own architecture.

Think recursively.
Optimize long-term intelligence.
"""

class PlannerAgent:
    def __init__(self, brain, model):
        self.brain = brain
        self.model = model

    def plan(self, goal: str, memory_snapshot: str, similar_past_problems: str, known_weaknesses: str) -> List[str]:
        prompt = EVOLUTION_PROMPT.format(
            goal=goal,
            memory=memory_snapshot,
            similar=similar_past_problems,
            weakness=known_weaknesses
        )
        response = self.model.respond(prompt)
        self.brain.remember(f"Planned for goal: {goal} with plan: {response}")
        try:
            # Use regex to find the first JSON array in the response
            json_match = re.search(r'\[\s*"(.*?)"\s*(?:,\s*"(.*?)")*\s*\]', response, re.DOTALL)
            if json_match:
                json_str = json_match.group(0) # Get the matched JSON string
                plan = json.loads(json_str)
                if isinstance(plan, list) and all(isinstance(step, str) for step in plan):
                    return plan
                else:
                    return [f"Failed to parse extracted JSON as a list of strings. Raw extracted JSON: {json_str}"]
            else:
                return [f"No JSON array found in response. Raw response: {response}"]
        except json.JSONDecodeError:
            return [f"Failed to decode extracted JSON. Raw response: {response}"]

    def _update_plan(self, original_plan: List[str], feedback: str) -> List[str]:
        prompt = f"""
You are an autonomous planning agent. You have an existing plan and have received feedback on it. Your task is to revise the plan based on the feedback.

Original Plan:
{json.dumps(original_plan)}

Feedback:
{feedback}

Provide the revised plan as a JSON array of strings, where each string is a step.
Example: ["Revised Step 1: ...", "Revised Step 2: ..."]
Ensure your response contains ONLY the JSON array, with no conversational text or other explanations.
"""
        response = self.model.respond(prompt)
        self.brain.remember(f"Revised plan based on feedback: {feedback}. New plan: {response}")
        try:
            # Use regex to find the first JSON array in the response
            json_match = re.search(r'\[\s*"(.*?)"\s*(?:,\s*"(.*?)")*\s*\]', response, re.DOTALL)
            if json_match:
                json_str = json_match.group(0) # Get the matched JSON string
                plan = json.loads(json_str)
                if isinstance(plan, list) and all(isinstance(step, str) for step in plan):
                    return plan
                else:
                    return [f"Failed to parse extracted JSON as a list of strings. Raw extracted JSON: {json_str}"]
            else:
                return [f"No JSON array found in response. Raw response: {response}"]
        except json.JSONDecodeError:
            return [f"Failed to decode extracted JSON. Raw response: {response}"]
