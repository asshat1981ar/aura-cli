import re

class HybridClosedLoop:

    _bootstrap_prompt_template = """You are AURA, a closed-loop autonomous development workflow.

You must follow exactly these phases:

1. DEFINE
2. PLAN
3. IMPLEMENT
4. TEST
5. CRITIQUE
6. IMPROVE
7. VERSION
8. SUMMARY

You must optimize across four axes:

A: Performance
B: Stability
C: Security
D: Code Elegance

Evaluation Rules:
- Score each axis from 1–10.
- Identify measurable weaknesses.
- Improvements must remain within the existing architecture.
- Do not introduce new workflow phases.
- Do not redesign the loop structure.

Objective:
{GOAL}

System Snapshot:
{STATE}

Return output strictly structured as a JSON object with the following keys.
The "IMPLEMENT" section should describe file changes using a 'file_path', 'old_code', and 'new_code' structure.
The "CRITIQUE" section should be a JSON object with specific score keys.

{
  "DEFINE": "A clear definition of the current problem or task.",
  "PLAN": "A detailed step-by-step plan to address the DEFINE stage, focusing on the current iteration.",
  "IMPLEMENT": {
    "file_path": "path/to/file.py",
    "old_code": "Existing code snippet to be replaced.",
    "new_code": "New code snippet that replaces old_code."
  },
  "TEST": "Specific test commands or steps to verify the IMPLEMENTATION. Always include expected output or success criteria.",
  "CRITIQUE": {
    "performance_score": "Score from 1-10, focusing on efficiency and resource usage.",
    "stability_score": "Score from 1-10, focusing on reliability and error handling.",
    "security_score": "Score from 1-10, focusing on vulnerability and secure practices.",
    "elegance_score": "Score from 1-10, focusing on code clarity, maintainability, and design patterns.",
    "weaknesses": ["List identified weaknesses or areas for improvement."]
  },
  "IMPROVE": "Based on CRITIQUE, a plan for the next iteration's improvements.",
  "VERSION": "A concise description of the changes made in this iteration, suitable for a git commit message.",
  "SUMMARY": "A brief overall summary of this iteration's progress and outcomes."
}
"""

    def __init__(self, model, brain, git_tools):
        self.model = model
        self.brain = brain
        self.git = git_tools

        self.weights = {
            "performance": 0.30,
            "stability": 0.30,
            "security": 0.25,
            "elegance": 0.15
        }

        self.previous_score = 0
        self.regression_count = 0
        self.stable_convergence_count = 0 # Added for Robust Confirmation

    def snapshot(self):
        return f"Memory entries: {len(self.brain.recall_all())}"

    def extract_scores(self, critique_dict: dict):
        scores = {}
        for key in self.weights:
            dict_key = f"{key}_score"
            if dict_key in critique_dict and isinstance(critique_dict[dict_key], int):
                scores[key] = critique_dict[dict_key]
            else:
                print(f"Warning: Score '{dict_key}' not found or invalid in CRITIQUE. Defaulting to 0.")
                scores[key] = 0
        return scores

    def weighted_score(self, scores):
        return sum(scores[k] * self.weights[k] for k in scores)

    def absolute_pass(self, score):
        return score >= 8.5

    def relative_pass(self, score):
        # Only consider relative pass if there was a previous score to compare against (i.e., not the very first run)
        return score > self.previous_score if self.previous_score != 0 else True

    def run(self, goal):

        state = self.snapshot()
        prompt = self._bootstrap_prompt_template.format(GOAL=goal, STATE=state)

        structured_response = {
            "DEFINE": "Error: Model response failed.",
            "PLAN": "Error: Model response failed.",
            "IMPLEMENT": {},
            "TEST": "Error: Model response failed.",
            "CRITIQUE": {
                "performance_score": 0,
                "stability_score": 0,
                "security_score": 0,
                "elegance_score": 0,
                "weaknesses": ["Model response failed due to an exception or invalid JSON."]
            },
            "IMPROVE": "Error: Model response failed.",
            "VERSION": "Error: Model response failed.",
            "SUMMARY": "Error: Model response failed."
        }

        raw_response = "" # Initialize raw_response for potential error logging

        try:
            raw_response = self.model.respond(prompt)
            parsed_response = json.loads(raw_response)
            # Basic validation to ensure it's a dict and has expected keys
            expected_keys = ["DEFINE", "PLAN", "IMPLEMENT", "TEST", "CRITIQUE", "IMPROVE", "VERSION", "SUMMARY"]
            if not isinstance(parsed_response, dict) or not all(key in parsed_response for key in expected_keys):
                raise ValueError("Model response is not a valid structured JSON or missing required keys.")
            structured_response.update(parsed_response) # Update default with actual response
        except json.JSONDecodeError as e:
            print(f"Error: Model returned invalid JSON for goal '{goal}': {e}\nRaw Response: {raw_response}")
            structured_response["CRITIQUE"]["weaknesses"].append(f"JSONDecodeError: {e}. Raw: {raw_response[:200]}...")
            self.stable_convergence_count = 0
            self.regression_count += 1
        except Exception as e:
            print(f"Error: Model.respond failed for goal '{goal}': {e}")
            # structured_response already defaults to error state
            self.stable_convergence_count = 0
            self.regression_count += 1

        # Now, extract scores from the structured_response
        scores = self.extract_scores(structured_response["CRITIQUE"])
        current_score = self.weighted_score(scores)

        # Apply changes from IMPLEMENT section first, then evaluate outcome (to be done by external agent)
        # For now, this loop assumes the IMPLEMENT section is handled externally and then rerun.
        # This part of the code mainly focuses on score evaluation and Git workflow.

        # Store the current state as a stash before making changes for potential rollback
        try:
            self.git.stash(message=f"Pre-iteration stash for goal: {goal}")
        except GitToolsError as e:
            # Log the error but don't terminate the loop immediately, as stashing might fail if no changes
            print(f"Warning: Failed to stash changes at start of iteration for goal '{goal}': {e}")


        # Regression detection (after changes are applied and scores are re-evaluated)
        # This part needs to be revisited as the "IMPLEMENT" changes are applied externally.
        # The current score is for the *previous* state if this is the first evaluation after model response.
        # However, for now, let's keep the existing logic and assume external agent will re-evaluate.

        if current_score < self.previous_score:
            self.regression_count += 1
            self.stable_convergence_count = 0 # Reset stable convergence on regression
        else:
            self.regression_count = 0
            # If the score improved or stayed same, and there was a stash, pop it.
            # If the score decreased, keep the stash for potential rollback.
            # This logic needs refinement with external application of changes.

        self.previous_score = current_score

        self.brain.remember(goal)
        self.brain.remember(structured_response) # Remember the structured response

        # Git commit logic:
        # Only commit if we have a stable convergence or a significant improvement
        # This is a temporary rule for now. A better rule would involve testing.
        if self.stable_convergence_count >= 1 or current_score > self.previous_score: # Commit on any improvement or single stable pass
            try:
                self.git.commit_all(f"AURA evolution: {structured_response.get('VERSION', f'Iteration for {goal}')}")
                # If committed successfully, we can pop the stash if it exists
                try:
                    self.git.stash_pop()
                except GitToolsError as e:
                    print(f"Warning: Failed to pop stash after successful commit: {e}")
            except GitToolsError as e:
                print(f"Error: Failed to commit changes for goal '{goal}': {e}. Rolling back current changes.")
                try:
                    self.git.rollback_last_commit(f"Rollback failed commit for goal: {goal}")
                except GitToolsError as rb_e:
                    print(f"Critical Error: Failed to rollback after failed commit for goal '{goal}': {rb_e}")
                self.regression_count += 1 # Treat failed commit as a regression
        else: # If no improvement or regression, then implicitly changes are not applied/reverted
            # If there was a stash, and no commit, pop the stash to revert changes from this iteration
            try:
                self.git.stash_pop()
                print(f"Reverted changes for goal '{goal}' due to no improvement or regression.")
            except GitToolsError as e:
                print(f"Warning: Failed to pop stash to revert changes for goal '{goal}': {e}")

        if self.regression_count >= 3:
            # The rollback logic here is more complex now with external application.
            # For now, it implies the *last successful* commit was bad.
            # Given the new stash-based approach, this regression count means consecutive
            # iterations failed to improve/converge after external application.
            print("Repeated regression detected. Consider restoring a checkpoint.")
            return json.dumps({"FINAL_STATUS": "Terminated: Repeated regression detected."})

        # Robust Confirmation Logic:
        if self.absolute_pass(current_score) and (current_score >= self.previous_score): # Changed relative_pass
            self.stable_convergence_count += 1
            if self.stable_convergence_count >= 3:
                # Assuming external agent will process the structured_response
                final_output = structured_response
                final_output["FINAL_STATUS"] = f"Optimization converged at {current_score} with Robust Confirmation."
                return json.dumps(final_output)
        else:
            self.stable_convergence_count = 0 # Reset if conditions are not met

        # If not converged, continue evolution
        current_status = f"Continuing evolution (Score: {current_score}, Stable Convergence Count: {self.stable_convergence_count})"
        current_output = structured_response
        current_output["STATUS"] = current_status
        return json.dumps(current_output)


