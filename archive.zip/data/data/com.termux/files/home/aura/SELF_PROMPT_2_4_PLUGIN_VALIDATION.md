# Self-Prompt: 2.4 Plugin Validation System

## THOUGHT
The objective of this phase is to implement a robust plugin validation system that ensures the structural integrity, security, and compatibility of dynamically loaded plugins. This system will leverage the type definitions from Phase 2.1 and the context/sandbox considerations from Phase 2.3. Validation will occur at various stages: upon discovery (manifest validation), upon loading (plugin object validation), and during execution (input/output data validation for workflow nodes). The goal is to prevent faulty or malicious plugins from disrupting the application.

## QUESTIONS
1.  What library or approach will be used for schema-based validation (e.g., Zod, Yup, JSON Schema)?
2.  How will `IPluginManifest` validation be implemented to ensure all required fields are present and correctly typed?
3.  How will plugin instances be validated against their declared `IPlugin` interfaces at runtime (e.g., using type guards or structural checks)?
4.  How will input and output data for `IWorkflowNodePlugin`s be validated against `IInputDefinition` and `IOutputDefinition` schemas during execution?
5.  What error handling strategy will be in place for validation failures, and how will these errors be communicated?
6.  How will the validation system integrate with the `PluginRegistry` and `PluginRuntime`?

## PLAN
1.  **Choose Validation Library**:
    *   Decision: Use **Zod** for schema-based validation due to its TypeScript-first approach and strong type inference capabilities.
2.  **Implement Manifest Validator**:
    *   Create `plugins/validation/PluginManifestValidator.ts`.
    *   Define a Zod schema for `IPluginManifest`.
    *   Implement a function `validateManifest(manifest: any): IPluginManifest` that uses the Zod schema to parse and validate the raw `plugin.json` content.
    *   Integrate this validator into `PluginRegistry.discoverPlugins`.
3.  **Implement Plugin Object Validator**:
    *   Create `plugins/validation/PluginObjectValidator.ts`.
    *   Implement type guards or Zod schemas for `IPlugin`, `IWorkflowNodePlugin`, `IIntegrationPlugin`, `IUiExtensionPlugin`.
    *   Implement a function `validatePlugin(plugin: any, expectedType: PluginType): IPlugin | IWorkflowNodePlugin | ...` to verify the instantiated plugin object against its declared type.
    *   Integrate this validator into `PluginRegistry.loadAndRegisterPlugin`.
4.  **Implement Workflow Node Data Validator**:
    *   Create `plugins/validation/WorkflowNodeDataValidator.ts`.
    *   Implement `validateInputData(data: Record<string, any>, inputDefinitions: IInputDefinition[]): void` which validates input data against `IInputDefinition` schemas.
    *   Implement `validateOutputData(data: any, outputDefinitions: IOutputDefinition[]): void` which validates output data against `IOutputDefinition` schemas.
    *   Integrate these validators into `PluginRuntime.executeWorkflowNode`.
5.  **Standardize Validation Errors**:
    *   Define custom error types or a standardized error format for validation failures.
    *   Ensure validation errors are logged using `Logger`.

## VERIFICATION
1.  **Unit Tests for `PluginManifestValidator`**:
    *   Test successful validation of a valid manifest.
    *   Test failure for missing required fields, invalid types, and malformed JSON.
2.  **Unit Tests for `PluginObjectValidator`**:
    *   Test successful validation of a plugin instance against its interface.
    *   Test failure for missing methods or properties.
3.  **Unit Tests for `WorkflowNodeDataValidator`**:
    *   Test `validateInputData` with valid and invalid input data (matching `IDataDefinition` schema).
    *   Test `validateOutputData` with valid and invalid output data.
4.  **Integration with `PluginRegistry`**:
    *   Test `PluginRegistry.discoverPlugins` with valid and invalid `plugin.json` files to ensure manifest validation is applied.
    *   Test `PluginRegistry.loadAndRegisterPlugin` with plugins that do not fully conform to their interfaces to ensure object validation.
5.  **Integration with `PluginRuntime`**:
    *   Test `PluginRuntime.executeWorkflowNode` with inputs that violate `IInputDefinition` schemas, and verify that validation errors are caught and handled.
6.  **Code Review**:
    *   Ensure validation logic is comprehensive and correctly uses the chosen library (Zod).
    *   Verify error messages are clear and actionable.
```
