# Self-Prompt: 2.2 Plugin Registry Implementation

## THOUGHT
The objective of this phase is to implement a central `PluginRegistry` responsible for discovering, loading, managing, and providing access to all plugins within Project OP. This registry will serve as the single source of truth for plugin information, ensuring that plugins are correctly initialized, their lifecycle events are managed, and other parts of the application can safely interact with them. It will leverage the plugin type definitions established in Phase 2.1. The registry should be a singleton to ensure consistent state across the application.

## QUESTIONS
1.  How will plugins be discovered (e.g., file system scan, explicit registration, manifest files)?
2.  What mechanism will be used to load plugin code dynamically (e.g., `import()`, `require`)?
3.  How will plugin dependencies (defined in `IPluginManifest`) be resolved and managed during loading?
4.  What is the lifecycle of a plugin within the registry (discovery -> loading -> initialization (`onLoad`) -> activation -> deactivation (`onUnload`) -> unloading)?
5.  How will the `IPluginContext` be created and passed to plugins during their `onLoad` and `onUnload` methods?
6.  How will other parts of the application query the registry to find specific types of plugins (e.g., all `IWorkflowNodePlugin`s, an `IIntegrationPlugin` by ID)?
7.  How will the singleton pattern be enforced for the `PluginRegistry`?

## PLAN
1.  **Design `PluginRegistry` Class**:
    *   Create `plugins/PluginRegistry.ts`.
    *   Implement as a singleton to ensure a single instance across the application.
    *   Store loaded plugins in an internal map (e.g., `Map<string, IPlugin>`).
    *   Store the `IPluginContext` to pass to plugins.
2.  **Implement Plugin Discovery**:
    *   Develop a method `discoverPlugins(pluginDirs: string[]): Promise<void>` that scans specified directories for `plugin.json` manifest files.
    *   Parse `plugin.json` files and validate them against `IPluginManifest`.
3.  **Implement Plugin Loading**:
    *   Develop a method `loadPlugin(manifest: IPluginManifest): Promise<IPlugin>` that dynamically loads the plugin's entry point (`manifest.entryPoint`).
    *   Handle potential circular dependencies or missing dependencies (initially, simple error reporting).
4.  **Implement Plugin Lifecycle Management**:
    *   `registerPlugin(plugin: IPlugin, manifest: IPluginManifest): Promise<void>`: Adds an instantiated plugin to the registry and calls its `onLoad` method with the `IPluginContext`.
    *   `unregisterPlugin(pluginId: string): Promise<void>`: Calls `onUnload` and removes the plugin from the registry.
5.  **Implement Plugin Querying**:
    *   Add methods like `getPlugin<T extends IPlugin>(id: string): T | undefined`.
    *   Add `getPluginsByType<T extends IPlugin>(type: PluginType): T[]`.
6.  **Instantiate `IPluginContext`**:
    *   Create an instance of `IPluginContext` within the `PluginRegistry` constructor or an initialization method, providing access to `Logger`, `ConfigService`, `ApiKeyManager`, etc.

## VERIFICATION
1.  **Unit Tests for `PluginRegistry` Singleton**:
    *   Verify that only one instance of `PluginRegistry` can be created.
2.  **Unit Tests for Plugin Discovery**:
    *   Mock file system operations to test `discoverPlugins` correctly identifies `plugin.json` files.
    *   Test validation of `plugin.json` manifests.
3.  **Unit Tests for Plugin Loading/Lifecycle**:
    *   Mock dynamic import/require calls.
    *   Test `loadPlugin` successfully loads and instantiates dummy plugins.
    *   Verify `onLoad` and `onUnload` methods are called at appropriate times.
    *   Test dependency resolution (basic checks).
4.  **Unit Tests for Plugin Querying**:
    *   Test `getPlugin` and `getPluginsByType` return correct plugin instances.
5.  **Integration Test (Dummy Plugins)**:
    *   Use the example plugins created in 2.1 verification to test the full lifecycle: discover -> load -> register -> query -> unregister.
6.  **Code Review**:
    *   Ensure thread-safety (if applicable) and robust error handling.
    *   Verify clear separation of concerns.
