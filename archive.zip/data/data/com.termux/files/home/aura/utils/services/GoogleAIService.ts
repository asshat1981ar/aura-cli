// utils/services/GoogleAIService.ts
import MultiServiceApiClient from '../MultiServiceApiClient';
import { ApiService } from '../ApiKeyManager';

interface GoogleChatMessage {
  role: 'user' | 'model'; // Gemini typically uses 'user' and 'model'
  parts: Array<{ text: string }>;
}

interface GoogleChatCompletionOptions {
  model?: string; // e.g., "gemini-pro"
  temperature?: number;
  candidate_count?: number; // Number of generated responses
  // Add other Google AI specific options as needed
}

interface GoogleChatCompletionResponse {
  candidates: Array<{
    content: GoogleChatMessage;
    finishReason: string;
    index: number;
  }>;
  usageMetadata: {
    promptTokenCount: number;
    candidatesTokenCount: number;
    totalTokenCount: number;
  };
}

interface GoogleEmbeddingResponse {
  embeddings: Array<{
    value: number[];
  }>;
}


class GoogleAIService {
  private static service: ApiService = ApiService.Google;

  /**
   * Performs a chat completion using the Google Gemini API.
   * @param messages Conversation history.
   * @param options Chat completion options.
   * @returns Promise<GoogleChatCompletionResponse>
   */
  static async chatCompletion(
    messages: GoogleChatMessage[],
    options?: GoogleChatCompletionOptions
  ): Promise<GoogleChatCompletionResponse> {
    const client = await MultiServiceApiClient.getClient(GoogleAIService.service);
    // Google's API path includes the model name directly
    const model = options?.model || 'gemini-pro';
    const response = await client.post<GoogleChatCompletionResponse>(
      `/models/${model}:generateContent`,
      {
        contents: messages,
        generationConfig: {
          temperature: options?.temperature,
          candidate_count: options?.candidate_count,
          // Add other generation config options
        },
      }
    );
    return response.data;
  }

  /**
   * Generates embeddings for a given text using the Google AI API.
   * @param text The text to generate embeddings for.
   * @param model The embedding model to use (e.g., "embedding-001").
   * @returns Promise<GoogleEmbeddingResponse>
   */
  static async generateEmbedding(
    text: string | string[],
    model: string = 'embedding-001'
  ): Promise<GoogleEmbeddingResponse> {
    const client = await MultiServiceApiClient.getClient(GoogleAIService.service);
    const response = await client.post<GoogleEmbeddingResponse>(
      `/models/${model}:embedContent`,
      {
        content: { parts: Array.isArray(text) ? text.map(t => ({text: t})) : [{ text }] },
      }
    );
    return response.data;
  }
}

export default GoogleAIService;
