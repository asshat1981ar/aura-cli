#!/data/data/com.termux/files/usr/bin/bash

echo "Attempting to synchronize Termux DNS with Android system DNS..."

# Get primary and secondary DNS from Android system properties
DNS1=$(getprop net.dns1)
DNS2=$(getprop net.dns2)

# Define the Termux resolv.conf path
RESOLV_CONF="$PREFIX/etc/resolv.conf"

echo "Android System DNS Primary: $DNS1"
echo "Android System DNS Secondary: $DNS2"

# Clear existing resolv.conf content and write new nameservers
# Ensure that if DNS1 is empty, we don't write an invalid line
echo -n > "$RESOLV_CONF" # Clear file or create if it doesn't exist

if [ -n "$DNS1" ]; then # Check if DNS1 is not empty
    echo "nameserver $DNS1" >> "$RESOLV_CONF"
    echo "Added primary nameserver: $DNS1"
else
    echo "Primary DNS from system properties is empty. Using Google DNS as fallback."
    echo "nameserver 8.8.8.8" >> "$RESOLV_CONF"
    echo "nameserver 8.8.4.4" >> "$RESOLV_CONF"
fi

if [ -n "$DNS2" ]; then # Check if DNS2 is not empty
    # Only add secondary if it's different from primary and not empty
    if [ "$DNS2" != "$DNS1" ]; then
        echo "nameserver $DNS2" >> "$RESOLV_CONF"
        echo "Added secondary nameserver: $DNS2"
    else
        echo "Secondary DNS is same as primary, not adding again."
    fi
fi

# Add fallback public DNS if neither system DNS was found or they are insufficient
if [ -z "$DNS1" ] && [ -z "$DNS2" ]; then
    echo "Adding Cloudflare DNS as additional fallback."
    echo "nameserver 1.1.1.1" >> "$RESOLV_CONF"
    echo "nameserver 1.0.0.1" >> "$RESOLV_CONF"
fi

echo "Current $RESOLV_CONF content:"
cat "$RESOLV_CONF"

echo "DNS synchronization complete. Please try running your application again."
echo "If issues persist, you might need to restart Termux or your device."
