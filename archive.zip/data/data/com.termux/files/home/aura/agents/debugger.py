import re

class DebuggerAgent:
    def __init__(self, brain, model):
        self.brain = brain
        self.model = model

    def diagnose(self, stderr: str) -> dict:
        # Placeholder for now.
        # This will be replaced with actual LLM-based diagnosis.
        # For now, it returns a very basic structured diagnosis.
        if "ModuleNotFoundError" in stderr:
            match = re.search(r"ModuleNotFoundError: No module named '(\w+)'", stderr)
            missing_module = match.group(1) if match else "unknown"
            return {
                "error_type": "ModuleNotFoundError",
                "summary": f"Missing module: {missing_module}",
                "fix_strategy": f"Add `import {missing_module}` or `pip install {missing_module}`",
                "raw_stderr": stderr
            }
        elif "ImportError" in stderr:
            return {
                "error_type": "ImportError",
                "summary": "General import error.",
                "fix_strategy": "Check import statements and module availability.",
                "raw_stderr": stderr
            }
        elif "SyntaxError" in stderr:
            return {
                "error_type": "SyntaxError",
                "summary": "Syntax error in the code.",
                "fix_strategy": "Review the code for typos or incorrect syntax.",
                "raw_stderr": stderr
            }
        elif "NameError" in stderr:
            match = re.search(r"NameError: name '(\w+)' is not defined", stderr)
            undefined_name = match.group(1) if match else "unknown"
            return {
                "error_type": "NameError",
                "summary": f"Undefined name: {undefined_name}",
                "fix_strategy": f"Define '{undefined_name}' before use.",
                "raw_stderr": stderr
            }
        elif "TypeError" in stderr:
            return {
                "error_type": "TypeError",
                "summary": "Type mismatch error.",
                "fix_strategy": "Check data types of variables and function arguments.",
                "raw_stderr": stderr
            }
        else:
            return {
                "error_type": "UnknownError",
                "summary": "An unknown error occurred during execution.",
                "fix_strategy": "Review the raw stderr for more details and debug step-by-step.",
                "raw_stderr": stderr
            }
