# AURA Core Components Refactoring Plan

## Overview
This plan outlines a systematic approach to address critical bugs, security vulnerabilities, performance bottlenecks, and areas for code refactoring within the AURA core components. The primary objective is to enhance the system's robustness, security, and performance while significantly improving code readability and maintainability. Emphasis will be placed on clear code, comprehensive testing, and architectural documentation to ensure deep semantic understanding throughout the refactoring process.

## Scope Definition (CRITICAL)
### In Scope
- Addressing all issues identified by the codebase_investigator in `aura_cli.py`, `core/hybrid_loop.py`, `core/goal_queue.py`, `core/goal_archive.py`, `core/model_adapter.py`, and `core/git_tools.py`.
- Implementing persistence for core data structures.
- Improving error handling and robustness of critical operations.
- Enhancing semantic understanding through code clarity, comments, docstrings, and architectural documentation.

### Out of Scope (DO NOT TOUCH)
- Any new feature development not directly related to fixing the identified issues.
- Unrelated refactoring or "nice-to-haves" that do not contribute to the core objectives of robustness, security, or performance.
- Upgrading external libraries unless explicitly required to resolve an identified issue.

## Current State Analysis

### `core/hybrid_loop.py`
- **Reasoning**: This is the core logic engine of the application. It contains critical flaws in its version control strategy (committing on every cycle, including regressions) and relies on brittle string parsing to evaluate model output. It also completely lacks the step of applying the code changes suggested by the AI model, which is a fundamental gap in the workflow.
- **KeySymbols**: `HybridClosedLoop`, `run`, `extract_scores`, `git.commit_all`, `git.rollback_last_commit`

### `core/model_adapter.py`
- **Reasoning**: This file contains a highly dangerous global monkeypatch for `socket.getaddrinfo` which can cause widespread, hard-to-debug network issues. Its fallback logic is clumsy, and its tool-calling mechanism is brittle and insecure, relying on regex and lacking an allowlist for executable tools.
- **KeySymbols**: `patched_getaddrinfo`, `respond`, `_execute_tool`

### `core/goal_archive.py`
- **Reasoning**: This component fails to persist the history of completed goals, meaning all historical data is lost when the application closes. This is a critical flaw for a system intended to have memory and track its performance over time.
- **KeySymbols**: `GoalArchive`, `record`

### `core/goal_queue.py`
- **Reasoning**: This component uses a Python `list` as a queue, which leads to inefficient O(n) performance for `pop(0)`. It should be replaced with `collections.deque` for O(1) performance, following standard Python best practices. It also lacks persistence.
- **KeySymbols**: `GoalQueue`, `next`

### `core/git_tools.py`
- **Reasoning**: This class abstracts Git operations but its error handling is weak; it prints errors to the console instead of raising exceptions, preventing the calling code from reacting to failures. The presence of `stash` provides an opportunity to implement a much safer workflow in `hybrid_loop.py` and `git_tools.py`.
- **KeySymbols**: `GitTools`, `commit_all`, `rollback_last_commit`, `stash`

### `aura_cli.py`
- **Reasoning**: The CLI is the main entry point. It relies on string parsing of results from the `hybrid_loop`, which is brittle. The `GitTools` class was originally defined here, indicating a need for better code organization (which was partially addressed). The CLI could be improved with a proper library like `click` or `argparse`.
- **KeySymbols**: `main`

## Implementation Phases

### Phase 1: Establish Core Stability - Security & Git Foundation
- **Goal**: Ensure the system's foundational security and establish a safe, reliable Git interaction model, with clear error handling.
- **Steps**:
  1. [ ] **Remove Dangerous Monkeypatch (`core/model_adapter.py`)**: Locate and eliminate the global `socket.getaddrinfo` monkeypatch. Implement a more robust and explicit network handling strategy if required by other components.
  2. [ ] **Secure Tool Execution (`core/model_adapter.py`)**: Redesign the tool-calling mechanism to use a clear allowlist for permitted tools. Replace fragile regex-based parsing of model output for tool calls with structured data (e.g., JSON).
  3. [ ] **Improve GitTools Error Handling (`core/git_tools.py`)**: Modify all methods within the `GitTools` class (`commit_all`, `rollback_last_commit`, `stash`, `apply_stash`, etc.) to raise specific, descriptive exceptions (e.g., `GitError`, `StashError`) on failure, instead of merely printing to the console.
- **Semantic Understanding Focus**: Add comments explaining the rationale for security changes and the new error propagation model. Ensure new exception types are self-documenting.
- **Verification**:
  - **Automated**: Write unit tests for `model_adapter` to confirm the monkeypatch is absent and that only allowlisted tools can be executed. Add unit tests for `git_tools` to verify that appropriate exceptions are raised under simulated failure conditions.
  - **Manual**: Attempt to run the system with intentionally malformed tool calls via `model_adapter`; verify explicit failure messages. Manually simulate Git failures (e.g., attempting a commit with no changes, rolling back beyond the initial commit) and confirm that `GitTools` propagates errors correctly.

### Phase 2: Reconstruct Core AI Loop (`core/hybrid_loop.py`)
- **Goal**: Overhaul the main AI loop to correctly apply model-generated code changes, use a robust Git workflow, communicate with structured data, and provide clear semantic feedback.
- **Steps**:
  1. [ ] **Refactor `HybridClosedLoop.run`**:
      *   Modify the `run` method to expect and parse structured output (JSON) from the model, including code changes, a clear justification, and a confidence score.
      *   Implement a dedicated step within the loop to programmatically *apply* model-generated code changes to the filesystem (e.g., by integrating the `replace` tool or direct file writing based on structured diffs).
      *   Integrate `GitTools.stash` and `GitTools.apply_stash` to enable an iterative, non-committing workflow during the AI's internal experimentation phase. Commits should only occur *after* model-generated changes are successfully applied and verified.
  2. [ ] **Remove Brittle String Parsing**: Replace all regex-based parsing within `HybridClosedLoop` (especially `extract_scores`) with robust JSON parsing.
  3. [ ] **Introduce Explicit Versioning**: Integrate `kit_create_checkpoint` and `kit_restore_checkpoint` into the `hybrid_loop` workflow to allow explicit, user-controlled versioning and rollback points during complex AI tasks.
- **Semantic Understanding Focus**: Update docstrings for `HybridClosedLoop` and its methods to reflect the new structured communication and Git workflow. Add comments explaining the decision-making logic of the loop and how model outputs are interpreted and applied. Ensure the structured model output itself contributes to semantic clarity.
- **Verification**:
  - **Automated**: Write comprehensive unit tests for `HybridClosedLoop` ensuring correct JSON parsing, successful application of dummy code changes, proper stashing/applying, and correct checkpoint integration.
  - **Manual**: Execute the `hybrid_loop` with a complex task requiring multiple code modifications. Verify that code changes are applied correctly, the Git history remains clean between iterations (only successful, verified changes are committed), and that explicit checkpoints can be restored.

### Phase 3: Enhance Data Management - Persistence & Efficiency
- **Goal**: Ensure long-term persistence for the AI's memory and optimize queue operations, making data flow semantically clear.
- **Steps**:
  1. [ ] **Implement Persistence for `core/goal_archive.py`**: Add functionality to `GoalArchive` to save and load the history of completed goals. This could use a simple JSON file, YAML, or a lightweight embedded database like SQLite.
  2. [ ] **Implement Persistence for `core/goal_queue.py`)**: Add functionality to `GoalQueue` to save and load its current state, ensuring goals are not lost across application restarts.
  3. [ ] **Optimize `core/goal_queue.py`**: Replace the underlying `list` implementation with `collections.deque` for all queue operations (`add`, `next`, `pop`) to achieve O(1) performance.
- **Semantic Understanding Focus**: Ensure the chosen persistence format (JSON, SQLite schema) is clear and self-documenting. Update docstrings for `GoalArchive` and `GoalQueue` to describe their persistence mechanisms and optimized performance characteristics.
- **Verification**:
  - **Automated**: Write unit tests for `GoalArchive` and `GoalQueue` verifying the correct saving and loading of states, and that `deque` operations maintain O(1) efficiency.
  - **Manual**: Add several goals to the queue, complete some, then restart the application. Verify that both the queue and the archive state are correctly restored, and that operations feel responsive.

### Phase 4: CLI Refinement & Integration
- **Goal**: Improve the robustness and user experience of the command-line interface, making its interaction with the core semantically unambiguous.
- **Steps**:
  1. [ ] **Improve `aura_cli.py` Result Parsing**: Update the `main` function and any other relevant parts of `aura_cli.py` to consume structured output (JSON) from the `hybrid_loop`. This removes reliance on brittle string matching.
  2. [ ] **(Optional) Introduce `click` or `argparse`**: Refactor CLI argument parsing to use a dedicated library (`click` or `argparse`) for better maintainability, clearer command definitions, and improved user experience. This can be considered a follow-up task if time permits.
- **Semantic Understanding Focus**: Update CLI help messages and usage instructions to reflect the new, more robust interaction model. Ensure error messages from the CLI are clear and actionable.
- **Verification**:
  - **Automated**: Write unit tests for `aura_cli.py` ensuring correct parsing of structured output from the `hybrid_loop` mock responses.
  - **Manual**: Run `aura_cli.py` with various commands and inputs, including valid and invalid scenarios. Verify correct behavior, clear output, and robust error handling.

## Semantic Understanding Across All Phases

*   **Code Clarity & Naming**: Throughout all refactoring, strictly prioritize clear, concise code with highly descriptive variable, function, and class names that accurately convey their purpose and behavior.
*   **Targeted Comments**: Add high-value comments to explain *why* certain architectural decisions were made, particularly in complex areas like the `hybrid_loop`'s control flow, `model_adapter`'s tool execution, and new Git strategies. Avoid redundant "what" comments.
*   **Comprehensive Docstrings**: Ensure all public functions, methods, and classes across the affected files have comprehensive, up-to-date docstrings adhering to a consistent style (e.g., Google or Sphinx format), explaining their purpose, arguments, and return values.
*   **Architectural Documentation**: Create a new Markdown document at `docs/architecture/aura_core_design.md`. This document will detail the new design of the `hybrid_loop`, `model_adapter` (especially tool execution), the robust Git workflow, and the persistence mechanisms for goals, ensuring a high-level semantic understanding of the system's core.