// plugins/PluginRegistry.ts
import { IPlugin } from '../types/plugin/IPlugin';
import { IPluginManifest } from '../types/plugin/IPluginManifest';
import { PluginType } from '../types/plugin/PluginType';
import { IPluginContext } from '../types/plugin/IPluginContext';

// Import all core services needed for IPluginContext
import Logger from '../utils/Logger';
import ConfigService from '../utils/ConfigService';
import { ApiKeyManager } from '../utils/ApiKeyManager';
import AuthService from '../utils/AuthService';
import BiometricAuthService from '../utils/BiometricAuthService';
import MultiServiceApiClient from '../utils/MultiServiceApiClient';
import PluginRuntime from './PluginRuntime'; // Import PluginRuntime
import * as fs from 'fs/promises'; // For async file system operations
import * as path from 'path'; // For path manipulation
import { validateManifest } from './validation/PluginManifestValidator'; // Import manifest validator
import { validatePluginObject } from './validation/PluginObjectValidator'; // Import plugin object validator


class PluginRegistry {
  private static instance: PluginRegistry;
  private plugins: Map<string, IPlugin> = new Map();
  public pluginContext: IPluginContext; // Made public so PluginRuntime can access
  private pluginRuntime: PluginRuntime; // Instantiate PluginRuntime

  private constructor() {
    // Instantiate IPluginContext with all core services
    this.pluginContext = {
      logger: Logger,
      config: ConfigService,
      apiKeyManager: ApiKeyManager,
      authService: AuthService,
      biometricAuthService: BiometricAuthService,
      apiClient: MultiServiceApiClient,
      // Add other core services here as they are developed
    };
    this.pluginRuntime = new PluginRuntime(this); // Pass itself to runtime for context access
  }

  static getInstance(): PluginRegistry {
    if (!PluginRegistry.instance) {
      PluginRegistry.instance = new PluginRegistry();
    }
    return PluginRegistry.instance;
  }
  // --- Plugin Management Methods (to be implemented) ---

  /**
   * Discovers plugins from specified directories by scanning for plugin.json files.
   * @param pluginDirs An array of directory paths to scan for plugins.
   * @returns A promise resolving to an array of valid IPluginManifest objects.
   */
  async discoverPlugins(pluginDirs: string[]): Promise<IPluginManifest[]> {
    const discoveredManifests: IPluginManifest[] = [];

    for (const dir of pluginDirs) {
      Logger.debug(`Scanning for plugins in directory: ${dir}`);
      try {
        const entries = await fs.readdir(dir, { withFileTypes: true });
        for (const entry of entries) {
          if (entry.isDirectory()) {
            const pluginDirPath = path.join(dir, entry.name);
            const manifestPath = path.join(pluginDirPath, 'plugin.json');
            try {
              const manifestContent = await fs.readFile(manifestPath, 'utf-8');
              const rawManifest = JSON.parse(manifestContent);
              const manifest: IPluginManifest = validateManifest(rawManifest); // Use Zod validation

              // Store the path to the plugin's root directory for loading the entryPoint later
              (manifest as any)._pluginRootPath = pluginDirPath;
              discoveredManifests.push(manifest);
              Logger.info(`Discovered plugin: ${manifest.name} (${manifest.id}) from ${manifestPath}`);
            } catch (readError: any) {
              if (readError.code === 'ENOENT') {
                Logger.debug(`No plugin.json found in ${pluginDirPath}.`);
              } else if (readError.name === 'ZodError') {
                Logger.warn(`Validation failed for plugin.json at ${manifestPath}: ${readError.message}`);
              }
              else {
                Logger.error(`Error reading or parsing plugin.json at ${manifestPath}:`, readError);
              }
            }
          }
        }
      } catch (dirReadError: any) {
        if (dirReadError.code === 'ENOENT') {
          Logger.warn(`Plugin directory not found: ${dir}`);
        } else {
          Logger.error(`Error scanning plugin directory ${dir}:`, dirReadError);
        }
      }
    }
    return discoveredManifests;
  }

  /**
   * Loads and registers a plugin from its manifest.
   * @param manifest The manifest of the plugin to load.
   * @returns A promise resolving to the loaded plugin instance.
   */
  async loadAndRegisterPlugin(manifest: IPluginManifest): Promise<IPlugin> {
    if (this.plugins.has(manifest.id)) {
      Logger.warn(`Plugin '${manifest.id}' is already loaded. Skipping.`);
      return this.plugins.get(manifest.id)!;
    }

    // Basic dependency check (can be expanded later for versioning)
    if (manifest.dependencies) {
      for (const depId in manifest.dependencies) {
        if (!this.plugins.has(depId)) {
          Logger.warn(`Dependency '${depId}' for plugin '${manifest.id}' not found. Plugin might not function correctly.`);
          // For now, we allow loading but log a warning. A stricter approach would throw.
        }
      }
    }

    const pluginPath = path.join((manifest as any)._pluginRootPath, manifest.entryPoint);
    Logger.info(`Loading plugin entry point: ${pluginPath}`);

    try {
      // Dynamic import to load the plugin code
      // Node.js dynamic import is typically absolute path or relative from current module
      const pluginModule = await import(pluginPath);
      const PluginClass = pluginModule.default;

      if (!PluginClass) {
        throw new Error(`Plugin entry point '${manifest.entryPoint}' does not have a default export.`);
      }

      const pluginInstance = new PluginClass(); // Instantiate first
      let validatedPlugin: IPlugin;
      try {
        validatedPlugin = validatePluginObject(pluginInstance, manifest.type);
      } catch (validationError: any) {
        if (validationError.name === 'ZodError') {
          Logger.error(`Plugin object validation failed for '${manifest.id}':`, validationError);
          throw new Error(`Plugin '${manifest.id}' object validation failed: ${validationError.message}`);
        }
        throw validationError; // Re-throw other errors
      }
      
      if (validatedPlugin.id !== manifest.id) {
          Logger.warn(`Plugin '${manifest.id}' has a manifest ID mismatch with its internal ID '${validatedPlugin.id}'. Using manifest ID for registry.`);
          // Potentially enforce manifest ID over internal ID, or throw. For now, warn.
      }


      const loadResult = await this.pluginRuntime.loadPlugin(pluginInstance);
      if (!loadResult.success) {
          throw new Error(`Plugin '${manifest.id}' onLoad failed: ${loadResult.error?.message}`);
      }
      this.plugins.set(manifest.id, pluginInstance);
      Logger.info(`Plugin '${manifest.name}' (${manifest.id}) loaded and registered.`);
      return pluginInstance;
    } catch (error: any) {
      Logger.error(`Failed to load or register plugin '${manifest.id}' from ${pluginPath}:`, error);
      throw new Error(`Plugin loading failed for '${manifest.id}': ${error.message}`);
    }
  }

  /**
   * Unloads a plugin by its ID.
   * @param pluginId The ID of the plugin to unload.
   * @returns A promise that resolves when the plugin is unloaded.
   */
  async unloadPlugin(pluginId: string): Promise<void> {
    const plugin = this.plugins.get(pluginId);
    if (plugin) {
      const unloadResult = await this.pluginRuntime.unloadPlugin(plugin);
      if (!unloadResult.success) {
          throw new Error(`Plugin '${pluginId}' onUnload failed: ${unloadResult.error?.message}`);
      }
      this.plugins.delete(pluginId);
      Logger.info(`Plugin '${plugin.name}' (${pluginId}) unloaded.`);
    } else {
      Logger.warn(`Attempted to unload non-existent plugin: ${pluginId}`);
    }
  }

  /**
   * Retrieves a plugin by its ID.
   * @param id The ID of the plugin.
   * @returns The plugin instance or undefined if not found.
   */
  getPlugin<T extends IPlugin>(id: string): T | undefined {
    return this.plugins.get(id) as T;
  }

  /**
   * Retrieves all plugins of a specific type.
   * @param type The type of plugins to retrieve.
   * @returns An array of plugin instances.
   */
  getPluginsByType<T extends IPlugin>(type: PluginType): T[] {
    const matchingPlugins: T[] = [];
    for (const plugin of this.plugins.values()) {
      if (plugin.type === type) {
        matchingPlugins.push(plugin as T);
      }
    }
    return matchingPlugins;
  }
}

export default PluginRegistry.getInstance();
