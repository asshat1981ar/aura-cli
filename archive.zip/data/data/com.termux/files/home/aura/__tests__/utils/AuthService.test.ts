// __tests__/utils/AuthService.test.ts
import AuthService from '../../utils/AuthService';
import SecureStorage from '../../utils/SecureStorage';

jest.mock('../../utils/SecureStorage', () => ({
  setItem: jest.fn(),
  getItem: jest.fn(),
  deleteItem: jest.fn(),
}));

describe('AuthService', () => {
  const MOCK_ACCESS_TOKEN = 'mock_access_token';
  const MOCK_REFRESH_TOKEN = 'mock_refresh_token';
  const MOCK_EXPIRES_IN = 3600; // 1 hour

  beforeEach(() => {
    jest.clearAllMocks();
    jest.spyOn(Date, 'now').mockReturnValue(1678886400000); // Mock current time for consistent expiry calculations
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('should store tokens and expiry correctly', async () => {
    await AuthService.setTokens(MOCK_ACCESS_TOKEN, MOCK_REFRESH_TOKEN, MOCK_EXPIRES_IN);
    const expectedExpiryTime = 1678886400000 + (MOCK_EXPIRES_IN * 1000); // current_mock_time + 1 hour
    expect(SecureStorage.setItem).toHaveBeenCalledWith('oauth_access_token', MOCK_ACCESS_TOKEN);
    expect(SecureStorage.setItem).toHaveBeenCalledWith('oauth_refresh_token', MOCK_REFRESH_TOKEN);
    expect(SecureStorage.setItem).toHaveBeenCalledWith('oauth_access_token_expiry', String(expectedExpiryTime));
  });

  it('should retrieve access token', async () => {
    (SecureStorage.getItem as jest.Mock).mockResolvedValueOnce(MOCK_ACCESS_TOKEN);
    const token = await AuthService.getAccessToken();
    expect(SecureStorage.getItem).toHaveBeenCalledWith('oauth_access_token');
    expect(token).toBe(MOCK_ACCESS_TOKEN);
  });

  it('should retrieve refresh token', async () => {
    (SecureStorage.getItem as jest.Mock).mockResolvedValueOnce(MOCK_REFRESH_TOKEN);
    const token = await AuthService.getRefreshToken();
    expect(SecureStorage.getItem).toHaveBeenCalledWith('oauth_refresh_token');
    expect(token).toBe(MOCK_REFRESH_TOKEN);
  });

  describe('isAccessTokenExpired', () => {
    it('should return true if no expiry info is found', async () => {
      (SecureStorage.getItem as jest.Mock).mockResolvedValueOnce(null);
      const expired = await AuthService.isAccessTokenExpired();
      expect(expired).toBe(true);
    });

    it('should return true if access token has expired', async () => {
      const expiredTime = Date.now() - 1000; // 1 second ago
      (SecureStorage.getItem as jest.Mock).mockResolvedValueOnce(String(expiredTime));
      const expired = await AuthService.isAccessTokenExpired();
      expect(expired).toBe(true);
    });

    it('should return false if access token is not expired', async () => {
      const futureTime = Date.now() + 10000; // 10 seconds from now
      (SecureStorage.getItem as jest.Mock).mockResolvedValueOnce(String(futureTime));
      const expired = await AuthService.isAccessTokenExpired();
      expect(expired).toBe(false);
    });
  });

  it('should clear all OAuth tokens', async () => {
    await AuthService.clearTokens();
    expect(SecureStorage.deleteItem).toHaveBeenCalledWith('oauth_access_token');
    expect(SecureStorage.deleteItem).toHaveBeenCalledWith('oauth_refresh_token');
    expect(SecureStorage.deleteItem).toHaveBeenCalledWith('oauth_access_token_expiry');
  });

  describe('refreshAccessToken', () => {
    it('should refresh tokens if refresh token is valid', async () => {
      // Mock setTokens call inside refreshAccessToken
      const setTokensSpy = jest.spyOn(AuthService, 'setTokens');
      const newTokens = await AuthService.refreshAccessToken('valid_refresh_token');
      
      expect(setTokensSpy).toHaveBeenCalled();
      expect(newTokens).toHaveProperty('accessToken');
      expect(newTokens).toHaveProperty('refreshToken');
      expect(newTokens).toHaveProperty('expiresIn');
      expect(newTokens?.accessToken).toMatch(/^new_simulated_access_token_/);
    });

    it('should return null if refresh token is invalid', async () => {
      const newTokens = await AuthService.refreshAccessToken('invalid_refresh_token');
      expect(newTokens).toBeNull();
    });
  });
});
