// __tests__/utils/AiRouter.test.ts
import AiRouter from '../../utils/AiRouter';
import ConfigService from '../../utils/ConfigService';
import { ApiService } from '../../utils/ApiKeyManager';
import OpenAIService from '../../utils/services/OpenAIService';
import AnthropicService from '../../utils/services/AnthropicService';
import GoogleAIService from '../../utils/services/GoogleAIService';
import DeepLService from '../../utils/services/DeepLService';

jest.mock('../../utils/ConfigService', () => ({
  getActiveAiService: jest.fn(),
  getDefaultModel: jest.fn(),
}));

jest.mock('../../utils/services/OpenAIService', () => ({
  chatCompletion: jest.fn(),
  generateEmbedding: jest.fn(),
}));

jest.mock('../../utils/services/AnthropicService', () => ({
  chatCompletion: jest.fn(),
}));

jest.mock('../../utils/services/GoogleAIService', () => ({
  chatCompletion: jest.fn(),
  generateEmbedding: jest.fn(),
}));

jest.mock('../../utils/services/DeepLService', () => ({
  translate: jest.fn(),
}));

describe('AiRouter', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('chatCompletion', () => {
    const messages = [{ role: 'user', content: 'Hello' }];
    const options = { temperature: 0.7 };

    it('should route chat completion to OpenAI', async () => {
      (ConfigService.getActiveAiService as jest.Mock).mockResolvedValue(ApiService.OpenAI);
      (ConfigService.getDefaultModel as jest.Mock).mockResolvedValue('gpt-4');
      (OpenAIService.chatCompletion as jest.Mock).mockResolvedValue({ response: 'OpenAI Chat' });

      const result = await AiRouter.chatCompletion(messages, options);

      expect(OpenAIService.chatCompletion).toHaveBeenCalledWith(messages, { ...options, model: 'gpt-4' });
      expect(result).toEqual({ response: 'OpenAI Chat' });
    });

    it('should route chat completion to Anthropic', async () => {
      (ConfigService.getActiveAiService as jest.Mock).mockResolvedValue(ApiService.Anthropic);
      (ConfigService.getDefaultModel as jest.Mock).mockResolvedValue('claude-3');
      (AnthropicService.chatCompletion as jest.Mock).mockResolvedValue({ response: 'Anthropic Chat' });

      const result = await AiRouter.chatCompletion(messages, options);

      expect(AnthropicService.chatCompletion).toHaveBeenCalledWith(messages, { ...options, model: 'claude-3' });
      expect(result).toEqual({ response: 'Anthropic Chat' });
    });

    it('should route chat completion to Google', async () => {
      (ConfigService.getActiveAiService as jest.Mock).mockResolvedValue(ApiService.Google);
      (ConfigService.getDefaultModel as jest.Mock).mockResolvedValue('gemini-pro');
      (GoogleAIService.chatCompletion as jest.Mock).mockResolvedValue({ response: 'Google Chat' });

      const result = await AiRouter.chatCompletion(messages, options);

      expect(GoogleAIService.chatCompletion).toHaveBeenCalledWith(messages, { ...options, model: 'gemini-pro' });
      expect(result).toEqual({ response: 'Google Chat' });
    });

    it('should throw error for unsupported chat service', async () => {
      (ConfigService.getActiveAiService as jest.Mock).mockResolvedValue(ApiService.DeepL); // DeepL does not have chat
      await expect(AiRouter.chatCompletion(messages, options)).rejects.toThrow(
        'Chat completion not supported for active service: deepl'
      );
    });
  });

  describe('generateEmbedding', () => {
    const input = 'embed this text';
    const options = { model: 'text-embedding-custom' };

    it('should route embedding generation to OpenAI', async () => {
      (ConfigService.getActiveAiService as jest.Mock).mockResolvedValue(ApiService.OpenAI);
      (ConfigService.getDefaultModel as jest.Mock).mockResolvedValue('text-embedding-ada-002');
      (OpenAIService.generateEmbedding as jest.Mock).mockResolvedValue({ embedding: [0.1, 0.2] });

      const result = await AiRouter.generateEmbedding(input, options.model);

      expect(OpenAIService.generateEmbedding).toHaveBeenCalledWith(input, options.model);
      expect(result).toEqual({ embedding: [0.1, 0.2] });
    });

    it('should route embedding generation to Google', async () => {
      (ConfigService.getActiveAiService as jest.Mock).mockResolvedValue(ApiService.Google);
      (ConfigService.getDefaultModel as jest.Mock).mockResolvedValue('embedding-001');
      (GoogleAIService.generateEmbedding as jest.Mock).mockResolvedValue({ embedding: [0.3, 0.4] });

      const result = await AiRouter.generateEmbedding(input, options.model);

      expect(GoogleAIService.generateEmbedding).toHaveBeenCalledWith(input, options.model);
      expect(result).toEqual({ embedding: [0.3, 0.4] });
    });

    it('should use default embedding model if none provided and no config default', async () => {
      (ConfigService.getActiveAiService as jest.Mock).mockResolvedValue(ApiService.OpenAI);
      (ConfigService.getDefaultModel as jest.Mock).mockResolvedValue(null); // No default model in config
      (OpenAIService.generateEmbedding as jest.Mock).mockResolvedValue({ embedding: [0.5, 0.6] });

      const result = await AiRouter.generateEmbedding(input);

      expect(OpenAIService.generateEmbedding).toHaveBeenCalledWith(input, 'text-embedding-ada-002'); // Fallback default
      expect(result).toEqual({ embedding: [0.5, 0.6] });
    });

    it('should throw error for unsupported embedding service', async () => {
      (ConfigService.getActiveAiService as jest.Mock).mockResolvedValue(ApiService.Anthropic); // Anthropic does not have embedding
      await expect(AiRouter.generateEmbedding(input)).rejects.toThrow(
        'Embedding generation not supported for active service: anthropic'
      );
    });
  });

  describe('translate', () => {
    const text = 'Hello';
    const options = { target_lang: 'es' };

    it('should route translation to DeepL', async () => {
      (ConfigService.getActiveAiService as jest.Mock).mockResolvedValue(ApiService.DeepL);
      (DeepLService.translate as jest.Mock).mockResolvedValue({ translation: 'Hola' });

      const result = await AiRouter.translate(text, options);

      expect(DeepLService.translate).toHaveBeenCalledWith(text, options);
      expect(result).toEqual({ translation: 'Hola' });
    });

    it('should throw error for unsupported translation service', async () => {
      (ConfigService.getActiveAiService as jest.Mock).mockResolvedValue(ApiService.OpenAI); // OpenAI does not have translate
      await expect(AiRouter.translate(text, options)).rejects.toThrow(
        'Translation not supported by active service: openai'
      );
    });
  });
});
