// __tests__/plugins/validation/PluginManifestValidator.test.ts
import { validateManifest } from '../../../plugins/validation/PluginManifestValidator';
import { PluginType } from '../../../types/plugin/PluginType';
import { z } from 'zod';

describe('PluginManifestValidator', () => {
  it('should successfully validate a correct manifest', () => {
    const validManifest = {
      id: 'com.example.test-plugin',
      name: 'Test Plugin',
      version: '1.0.0',
      author: 'Test Author',
      description: 'A manifest for testing.',
      type: PluginType.WorkflowNode,
      entryPoint: 'index.js',
      dependencies: {
        'com.another.plugin': '^1.2.3',
      },
      config: {
        setting1: 'value',
      },
      locales: ['en', 'fr'],
    };

    expect(() => validateManifest(validManifest)).not.toThrow();
    const validated = validateManifest(validManifest);
    expect(validated).toEqual(validManifest);
  });

  it('should throw ZodError for missing required fields', () => {
    const invalidManifest = {
      id: 'com.example.invalid',
      name: 'Invalid Plugin',
      // Missing version, author, description, type, entryPoint
    };

    expect(() => validateManifest(invalidManifest)).toThrow(z.ZodError);
    try {
      validateManifest(invalidManifest);
    } catch (e: any) {
      expect(e.issues).toEqual(
        expect.arrayContaining([
          expect.objectContaining({ path: ['version'] }),
          expect.objectContaining({ path: ['author'] }),
          expect.objectContaining({ path: ['description'] }),
          expect.objectContaining({ path: ['type'] }),
          expect.objectContaining({ path: ['entryPoint'] }),
        ])
      );
    }
  });

  it('should throw ZodError for invalid version format', () => {
    const invalidManifest = {
      id: 'id', name: 'name', version: '1.0', author: 'author',
      description: 'desc', type: PluginType.Integration, entryPoint: 'entry.js',
    };
    expect(() => validateManifest(invalidManifest)).toThrow(z.ZodError);
    try {
      validateManifest(invalidManifest);
    } catch (e: any) {
      expect(e.issues[0].message).toContain('Invalid version format');
    }
  });

  it('should throw ZodError for invalid dependency semver', () => {
    const invalidManifest = {
      id: 'id', name: 'name', version: '1.0.0', author: 'author',
      description: 'desc', type: PluginType.Integration, entryPoint: 'entry.js',
      dependencies: { 'bad-dep': 'invalid-version' }
    };
    expect(() => validateManifest(invalidManifest)).toThrow(z.ZodError);
    try {
      validateManifest(invalidManifest);
    } catch (e: any) {
      expect(e.issues[0].message).toContain('Invalid semver range for dependency');
    }
  });

  it('should throw ZodError for invalid PluginType', () => {
    const invalidManifest = {
      id: 'id', name: 'name', version: '1.0.0', author: 'author',
      description: 'desc', type: 'unknown_type', entryPoint: 'entry.js',
    };
    expect(() => validateManifest(invalidManifest)).toThrow(z.ZodError);
    try {
      validateManifest(invalidManifest);
    } catch (e: any) {
      expect(e.issues[0].message).toContain('Invalid enum value');
    }
  });
});
