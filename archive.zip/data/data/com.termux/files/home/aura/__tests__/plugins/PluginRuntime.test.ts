// __tests__/plugins/PluginRuntime.test.ts
import PluginRuntime from '../../plugins/PluginRuntime';
import { IPluginContext } from '../../types/plugin/IPluginContext';
import { IPlugin } from '../../types/plugin/IPlugin';
import { IWorkflowNodePlugin } from '../../types/plugin/IWorkflowNodePlugin';
import Logger from '../../utils/Logger';
import { PluginType } from '../../types/plugin/PluginType';

// Mock PluginRegistry to provide a mock pluginContext
const mockPluginContext: IPluginContext = {
  logger: Logger,
  config: {} as any, // Mock as needed
  apiKeyManager: {} as any,
  authService: {} as any,
  biometricAuthService: {} as any,
  apiClient: {} as any,
};

const mockPluginRegistry = {
  pluginContext: mockPluginContext,
};

// Mock Logger
jest.mock('../../utils/Logger', () => ({
  info: jest.fn(),
  warn: jest.fn(),
  error: jest.fn(),
  debug: jest.fn(),
}));

describe('PluginRuntime', () => {
  let pluginRuntime: PluginRuntime;
  let mockPlugin: jest.Mocked<IPlugin>;
  let mockWorkflowNodePlugin: jest.Mocked<IWorkflowNodePlugin>;

  beforeEach(() => {
    jest.clearAllMocks();
    pluginRuntime = new PluginRuntime(mockPluginRegistry as any);

    mockPlugin = {
      id: 'mock-plugin',
      name: 'Mock Plugin',
      onLoad: jest.fn(),
      onUnload: jest.fn(),
      // Minimal IPlugin properties
      version: '1.0.0',
      author: 'Mock Author',
      description: 'Mock Description',
      type: PluginType.WorkflowNode, // Can be any type for base IPlugin tests
    };

    mockWorkflowNodePlugin = {
      ...mockPlugin, // Inherit base plugin properties
      type: PluginType.WorkflowNode,
      inputs: [],
      outputs: [],
      execute: jest.fn(),
    };
  });

  describe('loadPlugin', () => {
    it('should call onLoad successfully and return success', async () => {
      mockPlugin.onLoad.mockResolvedValueOnce(undefined);
      const result = await pluginRuntime.loadPlugin(mockPlugin);
      expect(mockPlugin.onLoad).toHaveBeenCalledWith(mockPluginContext);
      expect(result.success).toBe(true);
      expect(Logger.info).toHaveBeenCalledWith(expect.stringContaining('onLoad executed successfully.'));
    });

    it('should catch onLoad errors and return failure', async () => {
      const error = new Error('Load failed');
      mockPlugin.onLoad.mockRejectedValueOnce(error);
      const result = await pluginRuntime.loadPlugin(mockPlugin);
      expect(mockPlugin.onLoad).toHaveBeenCalledWith(mockPluginContext);
      expect(result.success).toBe(false);
      expect(result.error?.message).toContain('Plugin onLoad failed');
      expect(Logger.error).toHaveBeenCalledWith(expect.stringContaining('Error during onLoad'), error);
    });
  });

  describe('unloadPlugin', () => {
    it('should call onUnload successfully and return success', async () => {
      mockPlugin.onUnload.mockResolvedValueOnce(undefined);
      const result = await pluginRuntime.unloadPlugin(mockPlugin);
      expect(mockPlugin.onUnload).toHaveBeenCalledWith(mockPluginContext);
      expect(result.success).toBe(true);
      expect(Logger.info).toHaveBeenCalledWith(expect.stringContaining('onUnload executed successfully.'));
    });

    it('should catch onUnload errors and return failure', async () => {
      const error = new Error('Unload failed');
      mockPlugin.onUnload.mockRejectedValueOnce(error);
      const result = await pluginRuntime.unloadPlugin(mockPlugin);
      expect(mockPlugin.onUnload).toHaveBeenCalledWith(mockPluginContext);
      expect(result.success).toBe(false);
      expect(result.error?.message).toContain('Plugin onUnload failed');
      expect(Logger.error).toHaveBeenCalledWith(expect.stringContaining('Error during onUnload'), error);
    });
  });

  describe('executeWorkflowNode', () => {
    const mockData = { inputA: 10, inputB: 20 };
    const mockWorkflowId = 'wf-123';
    const mockNodeId = 'node-456';
    const mockOutput = { sum: 30 };

    it('should call execute successfully and return success with data', async () => {
      mockWorkflowNodePlugin.execute.mockResolvedValueOnce(mockOutput);
      const result = await pluginRuntime.executeWorkflowNode(
        mockWorkflowNodePlugin,
        mockData,
        mockWorkflowId,
        mockNodeId
      );

      const expectedExecutionContext = {
        data: mockData,
        services: mockPluginContext,
        workflowId: mockWorkflowId,
        nodeId: mockNodeId,
      };

      expect(mockWorkflowNodePlugin.execute).toHaveBeenCalledWith(expectedExecutionContext);
      expect(result.success).toBe(true);
      expect(result.data).toEqual(mockOutput);
      expect(Logger.debug).toHaveBeenCalledWith(expect.stringContaining('executed successfully.'), { workflowId: mockWorkflowId, nodeId: mockNodeId });
    });

    it('should catch execute errors and return failure', async () => {
      const error = new Error('Execution failed');
      mockWorkflowNodePlugin.execute.mockRejectedValueOnce(error);
      const result = await pluginRuntime.executeWorkflowNode(
        mockWorkflowNodePlugin,
        mockData,
        mockWorkflowId,
        mockNodeId
      );

      expect(mockWorkflowNodePlugin.execute).toHaveBeenCalledTimes(1);
      expect(result.success).toBe(false);
      expect(result.error?.message).toContain('Workflow node execution failed');
      expect(Logger.error).toHaveBeenCalledWith(expect.stringContaining('Error during execute'), error, { workflowId: mockWorkflowId, nodeId: mockNodeId });
    });
  });
});
