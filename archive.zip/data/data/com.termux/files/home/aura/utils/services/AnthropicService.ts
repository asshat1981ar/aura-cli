// utils/services/AnthropicService.ts
import MultiServiceApiClient from '../MultiServiceApiClient';
import { ApiService } from '../ApiKeyManager';

interface AnthropicMessage {
  role: 'user' | 'assistant';
  content: string;
}

interface AnthropicChatCompletionOptions {
  model?: string; // e.g., "claude-3-opus-20240229"
  temperature?: number;
  max_tokens?: number; // max_tokens_to_sample is required by Anthropic
  system?: string; // System prompt
  // Add other Anthropic specific options as needed
}

interface AnthropicChatCompletionResponse {
  id: string;
  type: string;
  role: string;
  model: string;
  stop_reason: string;
  stop_sequence: string | null;
  usage: {
    input_tokens: number;
    output_tokens: number;
  };
  content: Array<{
    type: string;
    text: string;
  }>;
}

class AnthropicService {
  private static service: ApiService = ApiService.Anthropic;

  /**
   * Performs a chat completion using the Anthropic Messages API.
   * @param messages Conversation history.
   * @param options Chat completion options.
   * @returns Promise<AnthropicChatCompletionResponse>
   */
  static async chatCompletion(
    messages: AnthropicMessage[],
    options: AnthropicChatCompletionOptions // max_tokens is required for Anthropic
  ): Promise<AnthropicChatCompletionResponse> {
    const client = await MultiServiceApiClient.getClient(AnthropicService.service);
    const response = await client.post<AnthropicChatCompletionResponse>('/messages', {
      model: options.model || 'claude-3-sonnet-20240229', // Default model
      max_tokens: options.max_tokens || 1024, // max_tokens_to_sample is required, using generic max_tokens
      messages,
      system: options.system,
      temperature: options.temperature,
      // Add other options here
    });
    return response.data;
  }
}

export default AnthropicService;
