import os
import sys
import json
import re
from datetime import datetime
from pathlib import Path

# Rich output
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich import print as rprint

# AURA core
sys.path.insert(0, str(Path(__file__).parent))

from memory.brain import Brain
from core.model_adapter import ModelAdapter
from core.goal_queue import GoalQueue
from core.goal_archive import GoalArchive
from core.vector_store import VectorStore
from core.git_tools import GitTools
from core.evolution_loop import EvolutionLoop
from core.hybrid_loop import HybridClosedLoop

# Existing agents
from agents.coder import CoderAgent
from agents.tester import TesterAgent
from agents.planner import PlannerAgent
from agents.critic import CriticAgent
from agents.scaffolder import ScaffolderAgent

# New agents — the self-improvement enablers
from agents.applicator import ApplicatorAgent
from agents.sandbox import SandboxAgent
from agents.router import RouterAgent
from agents.debugger import DebuggerAgent # Added DebuggerAgent import

# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────

CRITIC_PASS_THRESHOLD    = 7.5   # Minimum weighted score to accept a solution
MAX_REFINEMENT_CYCLES    = 4     # Iterations before escalating to mutation
REGRESSION_TOLERANCE     = 0.5   # Score drop that triggers rollback
ENABLED_MODELS           = ["openai", "gemini", "openrouter"]

os.environ.setdefault(
    "GIT_PYTHON_GIT_EXECUTABLE",
    "/data/data/com.termux/files/usr/bin/git"
)

console = Console()


# ─────────────────────────────────────────────────────────────────────────────
# Initialisation
# ─────────────────────────────────────────────────────────────────────────────

def build_system():
    """Instantiate and wire all agents. Returns a namespace of components."""
    brain    = Brain()
    adapter  = ModelAdapter()
    router   = RouterAgent(brain, adapter, enabled_models=ENABLED_MODELS)

    # Patch adapter so all model calls go through RouterAgent
    # (preserves existing code paths that call model.respond())
    adapter.respond = router.route

    tester      = TesterAgent(brain, adapter)
    planner     = PlannerAgent(brain, adapter)
    critic      = CriticAgent(brain, adapter)
    scaffolder  = ScaffolderAgent(brain, adapter)
    coder       = CoderAgent(brain, adapter, tester=tester)
    applicator  = ApplicatorAgent(brain, backup_dir=".aura/backups")
    sandbox     = SandboxAgent(brain, timeout=30)
    debugger    = DebuggerAgent(brain, adapter) # Instantiate DebuggerAgent

    vector_store = VectorStore(adapter, brain)
    git_tools    = GitTools()
    goal_queue   = GoalQueue()
    goal_archive = GoalArchive()

    from agents.mutator import MutatorAgent
    mutator = MutatorAgent()

    evolution_loop = EvolutionLoop(
        planner, coder, critic, brain, vector_store, git_tools, mutator
    )
    hybrid_loop = HybridClosedLoop(adapter, brain, git_tools)

    return {
        "brain": brain, "adapter": adapter, "router": router,
        "planner": planner, "coder": coder, "critic": critic,
        "applicator": applicator, "sandbox": sandbox, "debugger": debugger, # Added debugger here
        "tester": tester, "scaffolder": scaffolder,
        "vector_store": vector_store, "git_tools": git_tools,
        "goal_queue": goal_queue, "goal_archive": goal_archive,
        "evolution_loop": evolution_loop, "hybrid_loop": hybrid_loop,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Score extraction
# ─────────────────────────────────────────────────────────────────────────────

SCORE_RE = re.compile(r"(\d+(?:\.\d+)?)\s*/\s*10|score[:\s]+(\d+(?:\.\d+)?)", re.IGNORECASE)

def extract_critic_score(critique_text: str) -> float:
    matches = SCORE_RE.findall(critique_text)
    scores  = [float(a or b) for a, b in matches if (a or b)]
    return sum(scores) / len(scores) if scores else 5.0  # Default mid-score


# ─────────────────────────────────────────────────────────────────────────────
# Core self-improvement cycle
# ─────────────────────────────────────────────────────────────────────────────

def run_self_improvement_cycle(goal: str, sys: dict) -> dict:
    """
    Execute one complete autonomous self-improvement cycle for a goal.

    Returns a result dict with keys:
      success, final_score, iterations, applied_path, rollback_needed
    """
    planner    = sys["planner"]
    coder      = sys["coder"]
    critic     = sys["critic"]
    applicator = sys["applicator"]
    sandbox    = sys["sandbox"]
    git_tools  = sys["git_tools"]
    brain      = sys["brain"]
    vector_store = sys["vector_store"]
    debugger   = sys["debugger"] # Added debugger here

    console.print(Panel(f"[bold cyan]GOAL:[/bold cyan] {goal}", title="🔄 New Cycle"))

    # ── Phase 1: Plan ────────────────────────────────────────────────────────
    memory_snapshot      = "\n".join(brain.recall_all()[-20:])  # Last 20 entries
    similar_past         = "\n".join(vector_store.search(goal))
    known_weaknesses     = "\n".join(brain.recall_weaknesses()) if hasattr(brain, "recall_weaknesses") else ""

    console.print("[bold yellow]Phase 1/5:[/bold yellow] Planning...")
    tasks = planner.plan(
        goal=goal,
        memory_snapshot=memory_snapshot,
        similar_past_problems=similar_past,
        known_weaknesses=known_weaknesses,
    )
    task_str = "\n".join(tasks) if isinstance(tasks, list) else str(tasks)

    # ── Phase 2-4: Generate → Apply → Validate (refinement loop) ────────────
    best_code      = None
    best_result    = None
    best_score     = 0.0
    last_apply     = None
    sandbox_feedback = ""

    for iteration in range(1, MAX_REFINEMENT_CYCLES + 1):
        console.print(f"[bold yellow]Phase 2/5:[/bold yellow] Coding (iteration {iteration}/{MAX_REFINEMENT_CYCLES})...")

        # CoderAgent must include # AURA_TARGET: <path> directive in output
        enhanced_task = (
            f"{task_str}\n\n"
            f"IMPORTANT: Begin the code block with a comment: # AURA_TARGET: <relative/path/to/file.py>\n"
            f"This path is where the code will be written to disk.\n"
            + (f"\nPrevious sandbox errors to fix:\n{sandbox_feedback}" if sandbox_feedback else "")
        )
        raw_code_output = coder.implement(enhanced_task)

        # ── Apply to filesystem ───────────────────────────────────────────
        console.print("[bold yellow]Phase 3/5:[/bold yellow] Applying to filesystem...")
        apply_result = applicator.apply(raw_code_output)

        if not apply_result.success:
            console.print(f"[bold red]Apply failed:[/bold red] {apply_result.error}")
            sandbox_feedback = f"ApplicatorAgent could not write file: {apply_result.error}"
            continue

        last_apply = apply_result
        console.print(f"[green]✓ Written → {apply_result.target_path}[/green]")

        # ── Real execution ────────────────────────────────────────────────
        console.print("[bold yellow]Phase 4/5:[/bold yellow] Sandbox execution...")
        sandbox_result = sandbox.run_file(apply_result.target_path)
        console.print(f"  {sandbox_result.summary()}")

        if sandbox_result.timed_out:
            sandbox_feedback = "Code timed out (>30s). Ensure no infinite loops."
            applicator.rollback(apply_result)
            continue

        if not sandbox_result.success:
            # Use DebuggerAgent to diagnose the root cause
            diagnosis = debugger.diagnose(sandbox_result.stderr)
            
            sandbox_feedback = (
                f"Exit code {sandbox_result.exit_code}\n"
                f"ERROR TYPE: {diagnosis.get('error_type', 'Unknown')}\n"
                f"SUMMARY: {diagnosis.get('summary', 'No specific summary provided.')}\n"
                f"FIX STRATEGY: {diagnosis.get('fix_strategy', 'No specific fix strategy provided.')}\n"
                f"RAW STDERR (first 600 chars):\n{diagnosis.get('raw_stderr', '')[:600]}"
            )
            applicator.rollback(apply_result)
            continue

        # ── Critique ──────────────────────────────────────────────────────
        console.print("[bold yellow]Phase 5/5:[/bold yellow] Critic evaluation...")
        critique = critic.critique_code(
            task=goal,
            code=apply_result.code,
            requirements=(
                f"Sandbox passed (exit 0).\nStdout:\n{sandbox_result.stdout[:400]}"
            ),
        )
        score = extract_critic_score(critique)
        console.print(f"  Critic score: [bold]{score:.2f}[/bold] / 10.0")

        if score > best_score:
            best_score  = score
            best_code   = apply_result.code
            best_result = apply_result

        if score >= CRITIC_PASS_THRESHOLD:
            console.print(f"[bold green]✓ Accepted at score {score:.2f}[/bold green]")
            break

        # Not good enough yet — rollback and refine
        sandbox_feedback = f"Critic score was {score:.2f}/10:\n{critique[:400]}"
        applicator.rollback(apply_result)

    # ── Commit accepted work ──────────────────────────────────────────────────
    if best_result and best_result.success and best_score >= CRITIC_PASS_THRESHOLD:
        try:
            git_tools.commit_all(f"AURA autonomously improved: {goal[:60]}")
            console.print("[bold green]✓ Committed to git[/bold green]")
        except Exception as e:
            console.print(f"[yellow]Git commit skipped: {e}[/yellow]")

        # Add accepted code to vector store for future recall
        vector_store.add(f"SOLVED: {goal}\n{best_code[:300]}")

        return {
            "success": True,
            "final_score": best_score,
            "iterations": iteration,
            "applied_path": best_result.target_path,
            "rollback_needed": False,
        }

    # ── All iterations failed ─────────────────────────────────────────────────
    console.print(f"[bold red]✗ Goal not resolved after {MAX_REFINEMENT_CYCLES} iterations.[/bold red]")
    if last_apply:
        applicator.rollback(last_apply)
    return {
        "success": False,
        "final_score": best_score,
        "iterations": MAX_REFINEMENT_CYCLES,
        "applied_path": None,
        "rollback_needed": True,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Main execution
# ─────────────────────────────────────────────────────────────────────────────

def main():
    sys_components = build_system()
    goal_queue   = sys_components["goal_queue"]
    goal_archive = sys_components["goal_archive"]
    router       = sys_components["router"]

    console.print(Panel(
        "[bold cyan]AURA v2[/bold cyan] — Autonomous Self-Improvement System\n"
        "Commands: [green]goal <text>[/green] | [green]run[/green] | "
        "[green]status[/green] | [green]exit[/green]",
        title="🧠 AURA Online"
    ))

    while True:
        try:
            raw = input("\n[AURA]> ").strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[yellow]AURA shutting down.[/yellow]")
            break

        if not raw:
            continue

        if raw.lower() == "exit":
            break

        elif raw.lower().startswith("goal "):
            goal_text = raw[5:].strip()
            goal_queue.add(goal_text)
            console.print(f"[green]✓ Goal queued:[/green] {goal_text}")

        elif raw.lower() == "run":
            if not goal_queue.has_goals():
                console.print("[yellow]No goals in queue. Use: goal <description>[/yellow]")
                continue

            while goal_queue.has_goals():
                current_goal = goal_queue.next()
                result = run_self_improvement_cycle(current_goal, sys_components)
                goal_archive.record(current_goal, result["final_score"])

                status = "✅ DONE" if result["success"] else "❌ BLOCKED"
                console.print(
                    f"{status} | score={result['final_score']:.2f} "
                    f"| iter={result['iterations']} "
                    f"| path={result.get('applied_path', 'N/A')}"
                )

        elif raw.lower() == "status":
            table = Table(title="AURA System Status")
            table.add_column("Component")
            table.add_column("Status")
            table.add_row("Goals queued", str(len(goal_queue.queue)))
            table.add_row("Goals completed", str(len(goal_archive.completed)))
            table.add_row("Model routing", router.report().split("\n")[0])
            console.print(table)
            console.print(router.report())

        elif raw.lower().startswith("evolution "):
            goal_text = raw[10:].strip()
            console.print(f"[cyan]Running evolution loop for:[/cyan] {goal_text}")
            result = sys_components["evolution_loop"].run(goal_text)
            console.print(result)

        else:
            # Direct prompt to router for interactive use
            response = sys_components["router"].route(raw)
            console.print(Panel(response, title="AURA Response"))


if __name__ == "__main__":
    main()
