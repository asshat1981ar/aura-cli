def replace_code(file_path: str, old_code: str, new_code: str, dry_run: bool = False):
    """
    Replaces a block of code in a file.
    If dry_run is True, it prints the changes without modifying the file.
    """
    try:
        with open(file_path, 'r') as file:
            content = file.read()

        if old_code not in content:
            print(f"Warning: old_code not found in '{file_path}'. No changes made.")
            return

        new_content = content.replace(old_code, new_code)

        if dry_run:
            print(f"--- DRY RUN: Changes for {file_path} ---")
            print("--- OLD CODE ---")
            print(old_code)
            print("--- NEW CODE ---")
            print(new_code)
            print("--------------------------------------")
        else:
            with open(file_path, 'w') as file:
                file.write(new_content)
            print(f"Successfully replaced code in '{file_path}'")

    except FileNotFoundError:
        print(f"Error: File not found at '{file_path}'")
    except Exception as e:
        print(f"An error occurred during code replacement: {e}")
