// plugins/validation/PluginObjectValidator.ts
import { z } from 'zod';
import { IPlugin } from '../../types/plugin/IPlugin';
import { PluginType } from '../../types/plugin/PluginType';
import { IWorkflowNodePlugin } from '../../types/plugin/IWorkflowNodePlugin';
import { IIntegrationPlugin } from '../../types/plugin/IIntegrationPlugin';
import { IUiExtensionPlugin } from '../../types/plugin/IUiExtensionPlugin';

// Re-use PluginTypeSchema from PluginManifestValidator or define here
const PluginTypeSchema = z.nativeEnum(PluginType);

// Base Plugin Schema (for structural validation of IPlugin)
const BasePluginSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  version: z.string().regex(/^\d+\.\d+\.\d+(-.+)?$/),
  author: z.string().min(1),
  description: z.string().min(1),
  type: PluginTypeSchema,
  onLoad: z.function().args(z.any()).returns(z.promise(z.void())), // context type is any for Zod here
  onUnload: z.function().args(z.any()).returns(z.promise(z.void())),
});

// IWorkflowNodePlugin Schema
const WorkflowNodePluginSchema = BasePluginSchema.extend({
  type: z.literal(PluginType.WorkflowNode),
  inputs: z.array(z.object({ // Basic schema for IInputDefinition
    name: z.string(),
    type: z.string(),
    // Add other IInputDefinition fields if necessary for validation
  })),
  outputs: z.array(z.object({ // Basic schema for IOutputDefinition
    name: z.string(),
    type: z.string(),
    // Add other IOutputDefinition fields if necessary for validation
  })),
  execute: z.function().args(z.any()).returns(z.promise(z.any())),
});

// IIntegrationPlugin Schema
const IntegrationPluginSchema = BasePluginSchema.extend({
  type: z.literal(PluginType.Integration),
  integratesWith: z.array(z.string()),
  getService: z.function().args(z.string()).returns(z.any()),
});

// IUiExtensionPlugin Schema
const UiExtensionPluginSchema = BasePluginSchema.extend({
  type: z.literal(PluginType.UiExtension),
  extensionPoint: z.string().min(1),
  renderComponent: z.function().args(z.any()).returns(z.any()), // Returns React.ComponentType
});

/**
 * Validates a plugin instance against its expected interface based on PluginType.
 * @param plugin The instantiated plugin object.
 * @param expectedType The PluginType it's expected to conform to.
 * @returns The validated plugin object (casted to the correct interface).
 * @throws {z.ZodError} if validation fails.
 */
export function validatePluginObject(plugin: any, expectedType: PluginType): IPlugin | IWorkflowNodePlugin | IIntegrationPlugin | IUiExtensionPlugin {
  switch (expectedType) {
    case PluginType.WorkflowNode:
      return WorkflowNodePluginSchema.parse(plugin);
    case PluginType.Integration:
      return IntegrationPluginSchema.parse(plugin);
    case PluginType.UiExtension:
      return UiExtensionPluginSchema.parse(plugin);
    default:
      // Fallback for base IPlugin if type is not strictly one of the specific types or for future types
      return BasePluginSchema.parse(plugin);
  }
}
