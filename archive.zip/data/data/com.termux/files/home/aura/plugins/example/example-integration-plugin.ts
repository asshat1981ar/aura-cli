// plugins/example/example-integration-plugin.ts
import { IIntegrationPlugin } from '../../types/plugin/IIntegrationPlugin';
import { PluginType } from '../../types/plugin/PluginType';
import { IPluginContext } from '../../types/plugin/IPluginContext';
import { ApiService } from '../../utils/ApiKeyManager';
import OpenAIService from '../../utils/services/OpenAIService';
import GoogleAIService from '../../utils/services/GoogleAIService';

// Example of a specific service client that this integration might expose
interface IMyIntegratedService {
  getData(): Promise<string>;
  sendData(data: string): Promise<void>;
}

class MyIntegratedService implements IMyIntegratedService {
  constructor(private client: any) {} // Assuming 'client' is an Axios instance or similar

  async getData(): Promise<string> {
    const response = await this.client.get('/data');
    return response.data;
  }

  async sendData(data: string): Promise<void> {
    await this.client.post('/data', { payload: data });
  }
}


class ExampleIntegrationPlugin implements IIntegrationPlugin {
  id = 'com.example.integration.external-api';
  name = 'External API Integration';
  version = '1.0.0';
  author = 'AURA Example';
  description = 'Integrates with a dummy external API and exposes OpenAI/Google services.';
  type = PluginType.Integration;

  integratesWith = ['dummy-external-api', ApiService.OpenAI, ApiService.Google]; // List of services it provides access to

  private dummyApiClient: any; // Placeholder for an API client instance
  private openaiServiceInstance: typeof OpenAIService | undefined;
  private googleServiceInstance: typeof GoogleAIService | undefined;

  async onLoad(context: IPluginContext): Promise<void> {
    context.logger.info(`Integration Plugin '${this.name}' loaded.`);
    // Initialize dummy API client (e.g., Axios instance)
    // For now, just a placeholder
    this.dummyApiClient = {
      get: async (path: string) => ({ data: `Data from ${path} via dummy API.` }),
      post: async (path: string, payload: any) => {
        context.logger.info(`Dummy API received POST to ${path} with ${JSON.stringify(payload)}`);
        return { status: 200 };
      }
    };

    // Optionally, store references to the actual service adapters
    this.openaiServiceInstance = OpenAIService;
    this.googleServiceInstance = GoogleAIService;
  }

  async onUnload(context: IPluginContext): Promise<void> {
    context.logger.info(`Integration Plugin '${this.name}' unloaded.`);
    this.dummyApiClient = null;
    this.openaiServiceInstance = undefined;
    this.googleServiceInstance = undefined;
  }

  getService(serviceId: string): any {
    switch (serviceId) {
      case 'dummy-external-api':
        return new MyIntegratedService(this.dummyApiClient);
      case ApiService.OpenAI:
        return this.openaiServiceInstance; // Return the static service class
      case ApiService.Google:
        return this.googleServiceInstance; // Return the static service class
      default:
        throw new Error(`Service '${serviceId}' not provided by this integration plugin.`);
    }
  }
}

export default ExampleIntegrationPlugin;
