import re
from rich import print

class CoderAgent:

    def __init__(self, brain, model, tester=None): # Removed git_manager
        self.brain = brain
        self.model = model
        self.tester = tester
        # self.git_manager = git_manager # Commented out

    def implement(self, task, max_iterations=3):
        code = ""
        tests = ""
        feedback = ""

        for i in range(max_iterations):
            prompt = f"""
You are an autonomous coding agent inside AURA.

Task:
{task}

Previous memory:
{self.brain.recall_all()}

{"Current code:\\n```python\\n" + code + "\\n```" if code else ""}
{"Tests:\\n```python\\n" + tests + "\\n```" if tests else ""}
{"Sandbox feedback:\\n" + feedback if feedback else ""}

CRITICAL: The first line of your code block MUST be: # AURA_TARGET: <path/to/file.py>
Choose a path under agents/, core/, or memory/ that reflects the task.

Then produce the complete, working Python code.
Wrap everything in a single ```python ... ``` block.
"""
            # Generate or refine code
            raw_response = self.model.respond(prompt)
            # Extract code from response (assuming it's in a markdown code block)
            new_code_match = re.search(r"```python\n(.*?)```", raw_response, re.DOTALL)
            if new_code_match:
                code = new_code_match.group(1).strip()
            else:
                code = raw_response.strip() # Fallback if no code block

            if self.tester:
                tests = self.tester.generate_tests(code, task)
                evaluation = self.tester.evaluate_code(code, tests)
                feedback = evaluation["summary"]

                if "likely pass" in feedback.lower():
                    print(f"[bold green]Iteration {i+1}: Tests likely pass. Code accepted.[/bold green]")
                    self.brain.remember(f"Code for '{task}': {code}")
                    self.brain.remember(f"Tests for '{task}': {tests}")
                    # if self.git_manager:
                    #     self.git_manager.commit(f"AURA: Implemented task: {task}") # Commented out
                    return code
                else:
                    print(f"[bold yellow]Iteration {i+1}: Tests likely fail or need improvement. Applying feedback...[/bold yellow]")
                    self.brain.remember(f"Attempt {i+1} for '{task}': {code} -> Feedback: {feedback}")
            else:
                self.brain.remember(f"Code for '{task}': {code}")
                # if self.git_manager:
                #     self.git_manager.commit(f"AURA: Implemented task: {task}") # Commented out
                return code # No tester, so return the first generated code

        print(f"[bold red]Max iterations reached for task: {task}. Returning last generated code.[/bold red]")
        self.brain.remember(f"Final code after max iterations for '{task}': {code}")
        # if self.git_manager:
        #     self.git_manager.commit(f"AURA: Implemented task: {task} (max iterations reached)") # Commented out
        return code
