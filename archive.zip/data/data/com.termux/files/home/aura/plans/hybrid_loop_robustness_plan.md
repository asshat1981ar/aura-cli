# HybridClosedLoop Robustness Implementation Plan

## Overview
Enhance the `HybridClosedLoop` class in `core/hybrid_loop.py` to improve its robustness, error handling, and overall code quality by addressing potential failure points and refining existing logic.

## Scope Definition (CRITICAL)
### In Scope
- Implement comprehensive error handling for `self.model.respond(prompt)` to prevent loop crashes.
- Improve the robustness of `extract_scores` to handle unexpected model responses gracefully.
- Uncomment and properly integrate `self.git.rollback_last_commit()` into the regression detection logic.
- Refactor the `extract_scores` regex to use raw strings to suppress `SyntaxWarning`.
### Out of Scope (DO NOT TOUCH)
- Refactoring the `bootstrap_prompt_template` to be loaded from an external source.
- Making `weights` or `absolute_pass` threshold configurable.
- Any changes outside `core/hybrid_loop.py` not directly related to its robustness and error handling (e.g., in `core/model_adapter.py`, `memory/brain.py`).

## Current State Analysis
*   `core/hybrid_loop.py`:
    *   Line ~100 (`response = self.model.respond(prompt)`): Lack of specific error handling for model response failures.
    *   Line ~27 (`match = re.search(fr"{key.capitalize()} Score:\s*(\d+)", text)`): `SyntaxWarning` due to `\s` within non-raw f-string regex. The `extract_scores` method assumes correct score format.
    *   Line ~115 (`# self.git.rollback_last_commit()`): Git rollback is commented out.

## Implementation Phases
### Phase 1: Robust Model Response Handling
-   **Goal**: Ensure the `HybridClosedLoop` gracefully handles failures from `self.model.respond(prompt)`.
-   **Steps**:
    1.  [x] Wrap the `self.model.respond(prompt)` call in a `try-except` block.
    2.  [x] Catch `Exception` to cover all potential failures from the model adapter.
    3.  [x] If an exception occurs, log the error using `print` (for now) and return a structured response indicating failure, with scores that explicitly prevent convergence (e.g., all 0s) and a descriptive message. This message must be parsable by `extract_scores` but indicate an error.
    4.  [x] Modify `aura_cli.py` to recognize and handle this structured error response from `loop.run()` without crashing, potentially printing a more user-friendly message.
-   **Verification**:
    *   Automated: Create unit tests in `tests/test_hybrid_loop.py` to verify that `HybridClosedLoop.run` catches exceptions from `model.respond` and returns a structured error response with scores that prevent convergence.
    *   Manual: Introduce a controlled error in `ModelAdapter.respond` (e.g., raise an exception) and observe that `aura_cli.py` does not crash, and the `HybridClosedLoop` reports the error gracefully with scores that prevent convergence.

### Phase 2: Enhanced `extract_scores` Robustness
-   **Goal**: Make `extract_scores` more resilient to unexpected model response formats.
-   **Steps**:
    1.  [x] In `extract_scores`, if `match` is `None` for any score, log a warning message to the console indicating which score was not found.
    2.  [x] The current default to 0 is acceptable for non-matching scores for now, as it will naturally prevent convergence.
-   **Verification**:
    *   Automated: Create unit tests in `tests/test_hybrid_loop.py` to:
        *   Verify `extract_scores` handles responses with missing score lines by logging a warning and assigning a default score (e.g., 0).
        *   Verify `extract_scores` correctly parses scores from varied spacing.
    *   Manual: Temporarily modify `ModelAdapter.respond` to return a `[CRITIQUE]` block with a missing score (e.g., "Performance Score" absent) and observe that `extract_scores` logs a warning and defaults to 0 for that score without crashing.

### Phase 3: Integrate Git Rollback
-   **Goal**: Fully enable the automatic rollback functionality on repeated regression.
-   **Steps**:
    1.  [x] Uncomment `self.git.rollback_last_commit()` within the `if self.regression_count >= 3:` block.
    2.  [x] Add a `print` statement before and after the rollback call for logging purposes.
-   **Verification**:
    *   Automated: Create unit tests in `tests/test_hybrid_loop.py` to:
        *   Mock `git_tools.rollback_last_commit` and verify it's called when `regression_count` reaches 3.
        *   Verify appropriate logging messages are generated before and after rollback.
    *   Manual: Simulate a scenario where scores regress 3 consecutive times (e.g., by modifying `MockModelAdapter` to return decreasing scores) to observe that `rollback_last_commit` is called and reported.

