// types/plugin/IPlugin.ts
import { PluginType } from './PluginType';
import { IPluginContext } from './IPluginContext';

export interface IPlugin {
  id: string;
  name: string;
  version: string;
  author: string;
  description: string;
  type: PluginType;

  /**
   * Called when the plugin is loaded and activated by the platform.
   * Use this for initialization, registering services, etc.
   * @param context Provides access to core platform services.
   */
  onLoad(context: IPluginContext): Promise<void>;

  /**
   * Called when the plugin is being unloaded or deactivated.
   * Use this for cleanup, unregistering event listeners, etc.
   * @param context Provides access to core platform services.
   */
  onUnload(context: IPluginContext): Promise<void>;
}
