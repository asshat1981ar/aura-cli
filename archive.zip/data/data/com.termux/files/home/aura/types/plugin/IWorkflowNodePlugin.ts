// types/plugin/IWorkflowNodePlugin.ts
import { IPlugin } from './IPlugin';
import { PluginType } from './PluginType';
import { IInputDefinition, IOutputDefinition } from '../workflow/IDataDefinition'; // Assuming IInput/IOutput extends IDataDefinition
import { IExecutionContext } from '../workflow/IExecutionContext';

export interface IWorkflowNodePlugin extends IPlugin {
  type: PluginType.WorkflowNode; // Enforce specific plugin type

  inputs: IInputDefinition[];
  outputs: IOutputDefinition[];

  /**
   * Executes the core logic of the workflow node.
   * @param context The execution context for the node.
   * @returns A promise resolving to the output data of the node.
   */
  execute(context: IExecutionContext): Promise<any>;
}
