// __tests__/utils/ConfigService.test.ts
import ConfigService from '../../utils/ConfigService';
import SecureStorage from '../../utils/SecureStorage';
import { ApiService } from '../../utils/ApiKeyManager';

jest.mock('../../utils/SecureStorage', () => ({
  setItem: jest.fn(),
  getItem: jest.fn(),
  deleteItem: jest.fn(),
}));

describe('ConfigService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('setActiveAiService', () => {
    it('should set the active AI service', async () => {
      await ConfigService.setActiveAiService(ApiService.Anthropic);
      expect(SecureStorage.setItem).toHaveBeenCalledWith('config_active_ai_service', ApiService.Anthropic);
    });
  });

  describe('getActiveAiService', () => {
    it('should return the active AI service if set', async () => {
      (SecureStorage.getItem as jest.Mock).mockResolvedValueOnce(ApiService.Google);
      const activeService = await ConfigService.getActiveAiService();
      expect(SecureStorage.getItem).toHaveBeenCalledWith('config_active_ai_service');
      expect(activeService).toBe(ApiService.Google);
    });

    it('should return OpenAI as default if no active service is set', async () => {
      (SecureStorage.getItem as jest.Mock).mockResolvedValueOnce(null);
      const activeService = await ConfigService.getActiveAiService();
      expect(SecureStorage.getItem).toHaveBeenCalledWith('config_active_ai_service');
      expect(activeService).toBe(ApiService.OpenAI);
    });
  });

  describe('setDefaultModel', () => {
    it('should set the default model for a service', async () => {
      await ConfigService.setDefaultModel(ApiService.OpenAI, 'gpt-4-turbo');
      expect(SecureStorage.setItem).toHaveBeenCalledWith('config_default_model_openai', 'gpt-4-turbo');
    });
  });

  describe('getDefaultModel', () => {
    it('should get the default model for a service', async () => {
      (SecureStorage.getItem as jest.Mock).mockResolvedValueOnce('claude-3-opus');
      const model = await ConfigService.getDefaultModel(ApiService.Anthropic);
      expect(SecureStorage.getItem).toHaveBeenCalledWith('config_default_model_anthropic');
      expect(model).toBe('claude-3-opus');
    });

    it('should return null if no default model is set for a service', async () => {
      (SecureStorage.getItem as jest.Mock).mockResolvedValueOnce(null);
      const model = await ConfigService.getDefaultModel(ApiService.Google);
      expect(SecureStorage.getItem).toHaveBeenCalledWith('config_default_model_google');
      expect(model).toBeNull();
    });
  });

  describe('clearAiConfig', () => {
    it('should clear the active AI service configuration', async () => {
      const consoleWarnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});
      await ConfigService.clearAiConfig();
      expect(SecureStorage.deleteItem).toHaveBeenCalledWith('config_active_ai_service');
      expect(consoleWarnSpy).toHaveBeenCalledWith(
        "clearAiConfig only clears the active AI service. Default models need explicit deletion or a different tracking mechanism."
      );
      consoleWarnSpy.mockRestore();
    });
  });
});
