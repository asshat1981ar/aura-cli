import sqlite3
import networkx as nx
import os # Import os
from pathlib import Path
from typing import List
from textblob import TextBlob # Import TextBlob

class Brain:

    def __init__(self):
        # Construct absolute path for the database file
        db_file_path = Path(__file__).parent / "brain.db"
        # Ensure the directory exists
        Path(__file__).parent.mkdir(exist_ok=True) # Already created by Path("memory").mkdir(exist_ok=True)
        self.db = sqlite3.connect(str(db_file_path)) # Connect using absolute path
        self.graph = nx.Graph()
        self._init_db()
        
    def _init_db(self):
        self.db.execute("""
        CREATE TABLE IF NOT EXISTS memory(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT
        )
        """)
        self.db.execute("""
        CREATE TABLE IF NOT EXISTS weaknesses(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            description TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
        """)
        self.db.execute("""
        CREATE TABLE IF NOT EXISTS vector_store_data(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT,
            embedding BLOB
        )
        """)
        self.db.commit()

    def remember(self, text: str):
        # Store in textual memory
        cursor = self.db.execute(
            "INSERT INTO memory(content) VALUES (?)",
            (text,)
        )
        self.db.commit()

    def recall_all(self):
        rows = self.db.execute("SELECT content FROM memory").fetchall()
        return [r[0] for r in rows]

    def add_weakness(self, weakness_description: str):
        self.db.execute("INSERT INTO weaknesses(description) VALUES (?)", (weakness_description,))
        self.db.commit()

    def recall_weaknesses(self) -> list[str]:
        rows = self.db.execute("SELECT description FROM weaknesses ORDER BY timestamp DESC").fetchall()
        return [r[0] for r in rows]

    def reflect(self):
        memory_entries = self.recall_all()
        weakness_entries = self.recall_weaknesses()
        return f"System has {len(memory_entries)} memory entries and {len(weakness_entries)} identified weaknesses."

    def relate(self, a: str, b: str):
        self.graph.add_edge(a, b)

    def analyze_critique_for_weaknesses(self, critique: str):
        # Using TextBlob for sentiment analysis and noun phrase extraction
        blob = TextBlob(critique)
        
        found_weaknesses = False
        for sentence in blob.sentences:
            # Check for negative sentiment
            if sentence.sentiment.polarity < -0.1: # Threshold for negative sentiment
                weakness_description = f"Negative sentiment detected: '{sentence.strip()}'."
                if sentence.noun_phrases:
                    weakness_description += f" Key phrases: {', '.join(sentence.noun_phrases)}."
                self.add_weakness(weakness_description)
                found_weaknesses = True
            # Also keep a keyword-based check as a fallback or for specific terms
            elif any(keyword in str(sentence).lower() for keyword in ["fail", "error", "bug", "issue", "inefficient", "suboptimal", "lacks", "missing", "weakness"]):
                self.add_weakness(f"Keyword-based weakness detected: '{sentence.strip()}'")
                found_weaknesses = True
        
        if not found_weaknesses:
            print("Brain: No significant weaknesses detected in critique (either not negative sentiment or no keywords).")