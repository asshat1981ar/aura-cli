// utils/SecureStorage.web.ts
import AsyncStorage from '@react-native-async-storage/async-storage'; // Expo provides this or similar for web
import { webcrypto } from 'crypto'; // Node.js compatible Web Crypto API, might need polyfill for browser

// Placeholder for a crypto key. In a real app, this would be securely generated/derived.
// DO NOT USE IN PRODUCTION AS IS.
const ENCRYPTION_KEY_PLACEHOLDER = 'YOUR_SUPER_SECRET_KEY_PLACEHOLDER_12345678901234'; // Must be 32 bytes for AES-256

async function encrypt(text: string, key: string): Promise<string> {
  if (!webcrypto) {
    console.warn("Web Crypto API not available. Data will be stored unencrypted.");
    return text;
  }
  try {
    const encoder = new TextEncoder();
    const data = encoder.encode(text);
    const iv = webcrypto.getRandomValues(new Uint8Array(16)); // Initialization Vector

    // Use a derived key for AES-GCM
    const aesKey = await webcrypto.subtle.importKey(
      'raw',
      encoder.encode(key.padEnd(32, '0').slice(0, 32)), // Pad/truncate key to 32 bytes
      { name: 'AES-GCM' },
      false,
      ['encrypt', 'decrypt']
    );

    const encrypted = await webcrypto.subtle.encrypt(
      { name: 'AES-GCM', iv: iv },
      aesKey,
      data
    );

    // Concat IV and encrypted data for storage
    const encryptedArray = new Uint8Array(encrypted);
    const result = new Uint8Array(iv.length + encryptedArray.length);
    result.set(iv, 0);
    result.set(encryptedArray, iv.length);

    return btoa(String.fromCharCode(...result)); // Base64 encode
  } catch (error) {
    console.error("Encryption failed:", error);
    return text; // Fallback to unencrypted in case of crypto error
  }
}

async function decrypt(encryptedText: string, key: string): Promise<string> {
  if (!webcrypto) {
    console.warn("Web Crypto API not available. Cannot decrypt data.");
    return encryptedText;
  }
  try {
    const decoder = new TextEncoder(); // Use encoder for key derivation consistency
    const encryptedArrayBuffer = Uint8Array.from(atob(encryptedText), c => c.charCodeAt(0));

    const iv = encryptedArrayBuffer.slice(0, 16);
    const encryptedData = encryptedArrayBuffer.slice(16);

    const aesKey = await webcrypto.subtle.importKey(
      'raw',
      decoder.encode(key.padEnd(32, '0').slice(0, 32)), // Pad/truncate key to 32 bytes
      { name: 'AES-GCM' },
      false,
      ['encrypt', 'decrypt']
    );

    const decrypted = await webcrypto.subtle.decrypt(
      { name: 'AES-GCM', iv: iv },
      aesKey,
      encryptedData
    );

    const decoderText = new TextDecoder();
    return decoderText.decode(decrypted);
  } catch (error) {
    console.error("Decryption failed:", error);
    return encryptedText; // Fallback to returning raw encrypted text if decryption fails
  }
}


const SecureStorageWeb = {
  async setItem(key: string, value: string): Promise<void> {
    const encryptedValue = await encrypt(value, ENCRYPTION_KEY_PLACEHOLDER);
    await AsyncStorage.setItem(key, encryptedValue);
  },

  async getItem(key: string): Promise<string | null> {
    const encryptedValue = await AsyncStorage.getItem(key);
    if (encryptedValue === null) {
      return null;
    }
    return await decrypt(encryptedValue, ENCRYPTION_KEY_PLACEHOLDER);
  },

  async deleteItem(key: string): Promise<void> {
    await AsyncStorage.removeItem(key);
  },

  async hasItem(key: string): Promise<boolean> {
    const value = await AsyncStorage.getItem(key);
    return value !== null;
  },

  async clearAll(): Promise<void> {
    await AsyncStorage.clear();
  },
};

export default SecureStorageWeb;
