# Create Prompt Template

Please create a reusable prompt template for:

## Prompt Template Structure

### 1. Template Metadata

**Template Name**: Generic Prompt Template Creator

**Category**: Prompt Engineering

**Purpose**: To guide the creation of high-quality, reusable AI prompt templates, ensuring consistency and adherence to best practices.

**Use Cases**:
- Developing new AI capabilities requiring structured prompts.
- Standardizing prompt creation across a team or project.
- Documenting prompt engineering best practices.

**Target Audience**:
- Skill level: Intermediate to Advanced
- Role: AI Engineers, Prompt Engineers, Developers, Technical Writers
- Context: Any task requiring structured and repeatable AI interaction

### 2. Template Variables

Define all customizable parts:

**Required Variables:**
- `{{new_template_name}}`: The descriptive name of the prompt template you are creating (e.g., "Code Review Security").
- `{{new_template_category}}`: The category of the prompt template you are creating (e.g., "Technical", "Analysis", "Creative").
- `{{new_template_purpose}}`: A concise statement of what the new prompt template accomplishes.
- `{{new_template_use_cases}}`: A bulleted list of specific scenarios when to use this new template.
- `{{new_template_target_audience}}`: A bulleted list describing the skill level, role, and context of the users for this new template.
- `{{new_template_required_vars_def}}`: Markdown table or list defining the required variables for the *new* template. Format: `* `{{variable_name}}`: Description of what goes here`.
- `{{new_template_optional_vars_def}}`: Markdown table or list defining the optional variables for the *new* template. Format: `* `{{optionalVar}}`: Description (defaults to: X)`.
- `{{new_template_main_content}}`: The core textual content of the prompt template you are creating, including the role/context, objective, and where the variables (`{{...}}`) should be placed.
- `{{new_template_output_format}}`: A clear description of the desired output structure and format for the *new* template.

**Optional Variables:**
- `{{new_template_example_values}}`: Example values for variables in the *new* template (defaults to: empty markdown block).
- `{{new_template_constraints_reqs}}`: Specific constraints and requirements for the *new* template (defaults to: empty markdown block).
- `{{new_template_additional_guidelines}}`: Any extra guidelines or instructions for the *new* template (defaults to: empty markdown block).
- `{{new_template_examples_full}}`: Full input/output examples demonstrating the *new* template's usage (defaults to: empty markdown block).
- `{{new_template_variations_mods}}`: Descriptions of possible variations or modifications for the *new* template (defaults to: empty markdown block).
- `{{new_template_common_mistakes}}`: Common pitfalls and how to avoid them when using the *new* template (defaults to: empty markdown block).
- `{{new_template_optimization_tips}}`: Tips for optimizing the results from the *new* template (defaults to: empty markdown block).
- `{{new_template_testing_checklist}}`: A checklist for testing the *new* template effectively (defaults to: empty markdown block).
- `{{new_template_documentation_section}}`: A section outlining how to document the *new* template for sharing (defaults to: empty markdown block).

### 3. The Prompt Template

```
[ROLE/CONTEXT]
You are an expert prompt engineer creating a new AI prompt template.

[OBJECTIVE]
Your goal is to define a high-quality, reusable prompt template for:
Template Name: {{new_template_name}}
Category: {{new_template_category}}
Purpose: {{new_template_purpose}}
Use Cases:
{{new_template_use_cases}}
Target Audience:
{{new_template_target_audience}}

[TEMPLATE DEFINITION]
Define the structure and content of the new prompt template below, including its variables, main content, and output format.

## Template Variables

**Required Variables:**
{{new_template_required_vars_def}}

**Optional Variables:**
{{new_template_optional_vars_def}}

**Example Values:**
```
{{new_template_example_values}}
```

## The Prompt Template Content

```
{{new_template_main_content}}
```

## Output Format

{{new_template_output_format}}

[ADDITIONAL SECTIONS]
{{new_template_constraints_reqs}}
{{new_template_additional_guidelines}}
{{new_template_examples_full}}
{{new_template_variations_mods}}
{{new_template_common_mistakes}}
{{new_template_optimization_tips}}
{{new_template_testing_checklist}}
{{new_template_documentation_section}}

```

### 4. Prompt Engineering Best Practices Applied

#### Clarity
- ✅ Clear role definition
- ✅ Explicit objective
- ✅ Specific requirements (for the new template)
- ✅ Defined output format (for the new template)

#### Completeness
- ✅ All necessary context provided (for the new template's creation)
- ✅ Edge cases considered (by asking for relevant sections in the new template)
- ✅ Examples included (by asking for examples in the new template)
- ✅ Constraints specified (by asking for constraints in the new template)

#### Flexibility
- ✅ Variables for customization (in the new template)
- ✅ Optional parameters (in the new template)
- ✅ Adaptable to different inputs (for the new template)

#### Effectiveness
- ✅ Structured output (for the new template)
- ✅ Clear expectations (for the new template)
- ✅ Actionable instructions (for the new template)
- ✅ Quality guidelines (for the new template)

### 5. Usage Instructions

#### How to Use This Template (Generic Prompt Template Creator)

**Step 1: Define Your New Prompt Template's Needs**
Gather information for the prompt template you want to create. This includes its name, category, purpose, use cases, target audience, and the specific variables, content, and output format it will require.

**Step 2: Fill in Template Variables**
Replace the `{{new_template_...}}` variables in *this* template with the details of the *new* prompt template you are designing. Pay close attention to providing clear and concise descriptions for all variables and sections of your new template.

**Step 3: Review and Adjust**
- Check that all required `{{new_template_...}}` variables are filled with accurate information about your new prompt template.
- Adjust the content within the `{{new_template_main_content}}` block to precisely reflect the prompt you intend to create.
- Consider adding content to optional sections like `{{new_template_constraints_reqs}}` or `{{new_template_examples_full}}` for a more robust new template.

**Step 4: Execute**
Submit *this* completed prompt (with your new template's details filled in) to an AI model. The AI will then generate the actual prompt template you designed.

**Step 5: Iterate**
Based on the generated prompt template, refine *this* template's input. For example, if the generated prompt isn't clear, adjust your `{{new_template_main_content}}` or `{{new_template_output_format}}` inputs in *this* template.

### 6. Example Implementations

#### Example 1: Basic Use Case (Creating a simple "Summarize Text" template)

**Input for Generic Prompt Template Creator:**
```
{{new_template_name}}: "Summarize Text"
{{new_template_category}}: "Content Creation"
{{new_template_purpose}}: "To summarize provided text into a concise overview."
{{new_template_use_cases}}: "* Quick content review
* Generating abstracts
* Extracting key information"
{{new_template_target_audience}}: "* Skill level: Beginner
* Role: Content creators, Researchers
* Context: Any text needing summarization"
{{new_template_required_vars_def}}: "* `{{text_to_summarize}}`: The full text content to be summarized."
{{new_template_optional_vars_def}}: "* `{{length}}`: Desired length of the summary (e.g., 'short', 'medium', 'long'). (defaults to: 'medium')"
{{new_template_main_content}}: "[ROLE/CONTEXT]
You are a helpful assistant.

[OBJECTIVE]
Summarize the following text:

{{text_to_summarize}}

[CONSTRAINTS/REQUIREMENTS]
- The summary should be {{length}}.

[OUTPUT FORMAT]
Provide a concise summary in paragraph form."
{{new_template_output_format}}: "A concise summary in paragraph form."
{{new_template_example_values}}: "{{text_to_summarize}}: "[A long article about AI]"
{{length}}: "short""
```

**Completed Prompt (to be sent to AI):**
```
[ROLE/CONTEXT]
You are an expert prompt engineer creating a new AI prompt template.

[OBJECTIVE]
Your goal is to define a high-quality, reusable prompt template for:
Template Name: Summarize Text
Category: Content Creation
Purpose: To summarize provided text into a concise overview.
Use Cases:
* Quick content review
* Generating abstracts
* Extracting key information
Target Audience:
* Skill level: Beginner
* Role: Content creators, Researchers
* Context: Any text needing summarization

[TEMPLATE DEFINITION]
Define the structure and content of the new prompt template below, including its variables, main content, and output format.

## Template Variables

**Required Variables:**
* `{{text_to_summarize}}`: The full text content to be summarized.

**Optional Variables:**
* `{{length}}`: Desired length of the summary (e.g., 'short', 'medium', 'long'). (defaults to: 'medium')

**Example Values:**
```
{{text_to_summarize}}: "[A long article about AI]"
{{length}}: "short"
```

## The Prompt Template Content

```
[ROLE/CONTEXT]
You are a helpful assistant.

[OBJECTIVE]
Summarize the following text:

{{text_to_summarize}}

[CONSTRAINTS/REQUIREMENTS]
- The summary should be {{length}}.

[OUTPUT FORMAT]
Provide a concise summary in paragraph form.
```

## Output Format

A concise summary in paragraph form.

[ADDITIONAL SECTIONS]
```

```

**Expected Output:**
```
[ROLE/CONTEXT]
You are a helpful assistant.

[OBJECTIVE]
Summarize the following text:

{{text_to_summarize}}

[CONSTRAINTS/REQUIREMENTS]
- The summary should be {{length}}.

[OUTPUT FORMAT]
Provide a concise summary in paragraph form.
```

#### Example 2: Advanced Use Case (Creating a "Code Refactoring Suggestions" template)

**Input for Generic Prompt Template Creator:**
```
{{new_template_name}}: "Code Refactoring Suggestions"
{{new_template_category}}: "Technical"
{{new_template_purpose}}: "To analyze provided code and suggest improvements for performance, readability, and maintainability."
{{new_template_use_cases}}: "* Code reviews
* Technical debt reduction
* Learning best practices"
{{new_template_target_audience}}: "* Skill level: Intermediate to Expert
* Role: Software Engineers, Code Reviewers
* Context: Any programming language"
{{new_template_required_vars_def}}: "* `{{code_snippet}}`: The code block to be analyzed.
* `{{language}}`: The programming language of the code snippet (e.g., Python, JavaScript)."
{{new_template_optional_vars_def}}: "* `{{focus_areas}}`: Specific areas to focus on (e.g., 'performance', 'security', 'readability'). (defaults to: 'all')"
{{new_template_main_content}}: "[ROLE/CONTEXT]
You are an expert software engineer and refactoring specialist.

[OBJECTIVE]
Analyze the following {{language}} code snippet and provide refactoring suggestions, focusing on {{focus_areas}}:

```{{language}}
{{code_snippet}}
```

[OUTPUT FORMAT]
Provide suggestions categorized by type (e.g., Performance, Readability, Maintainability) with code examples where applicable."
{{new_template_output_format}}: "Suggestions categorized by type (e.g., Performance, Readability, Maintainability) with code examples where applicable. Use Markdown."
{{new_template_constraints_reqs}}: "Please ensure:
- Suggestions are actionable.
- Maintain existing functionality.
- Prioritize impact over minor changes."
{{new_template_common_mistakes}}: "Mistake 1: Suggesting breaking changes without warning.
Mistake 2: Focusing on stylistic issues over functional improvements.
Mistake 3: Providing vague or non-implementable advice."
```

**Completed Prompt (to be sent to AI):**
```
[ROLE/CONTEXT]
You are an expert prompt engineer creating a new AI prompt template.

[OBJECTIVE]
Your goal is to define a high-quality, reusable prompt template for:
Template Name: Code Refactoring Suggestions
Category: Technical
Purpose: To analyze provided code and suggest improvements for performance, readability, and maintainability.
Use Cases:
* Code reviews
* Technical debt reduction
* Learning best practices
Target Audience:
* Skill level: Intermediate to Expert
* Role: Software Engineers, Code Reviewers
* Context: Any programming language

[TEMPLATE DEFINITION]
Define the structure and content of the new prompt template below, including its variables, main content, and output format.

## Template Variables

**Required Variables:**
* `{{code_snippet}}`: The code block to be analyzed.
* `{{language}}`: The programming language of the code snippet (e.g., Python, JavaScript).

**Optional Variables:**
* `{{focus_areas}}`: Specific areas to focus on (e.g., 'performance', 'security', 'readability'). (defaults to: 'all')

**Example Values:**
```

```

## The Prompt Template Content

```
[ROLE/CONTEXT]
You are an expert software engineer and refactoring specialist.

[OBJECTIVE]
Analyze the following {{language}} code snippet and provide refactoring suggestions, focusing on {{focus_areas}}:

```{{language}}
{{code_snippet}}
```

[OUTPUT FORMAT]
Provide suggestions categorized by type (e.g., Performance, Readability, Maintainability) with code examples where applicable.
```

## Output Format

Suggestions categorized by type (e.g., Performance, Readability, Maintainability) with code examples where applicable. Use Markdown.

[ADDITIONAL SECTIONS]
Please ensure:
- Suggestions are actionable.
- Maintain existing functionality.
- Prioritize impact over minor changes.

Mistake 1: Suggesting breaking changes without warning.
Mistake 2: Focusing on stylistic issues over functional improvements.
Mistake 3: Providing vague or non-implementable advice.

```

### 7. Variations and Modifications

#### Variation 1: Output Format Change
**Modification:** Change the `[OUTPUT FORMAT]` section to request JSON or XML for programmatic parsing.
**When to Use:** When the output needs to be consumed by another system or script.

---

#### Variation 2: Language Specificity
**Modification:** Include a `{{version}}` variable for language/framework versions (e.g., Python 3.9, React 18).
**When to Use:** When code behavior or best practices are version-dependent.

### 8. Common Mistakes to Avoid

**Mistake 1: Being Too Vague in New Template Descriptions**
- ❌ Bad: "Analyzes code" (for `new_template_purpose`)
- ✅ Good: "Analyzes provided code to identify security vulnerabilities and suggest fixes."

**Mistake 2: Not Defining All Variables for the New Template**
- ❌ Bad: Forgetting to list `{{language}}` in `{{new_template_required_vars_def}}` if the new template uses it.
- ✅ Good: Ensuring every variable used in `{{new_template_main_content}}` is defined in either required or optional variables.

**Mistake 3: Unclear Output Format for the New Template**
- ❌ Bad: "Just give me the answer" (for `new_template_output_format`)
- ✅ Good: "Provide a bulleted list of findings, categorized by severity (High, Medium, Low)."

### 9. Optimization Tips

#### For Better Clarity (for the New Template you are creating):
- Use simple, direct language in the `[ROLE/CONTEXT]` and `[OBJECTIVE]` sections.
- Break complex tasks in `[OBJECTIVE]` into smaller steps.
- Provide clear examples for `{{new_template_examples_full}}`.

#### For Better Results (from the New Template you are creating):
- Specify desired output format rigorously in `{{new_template_output_format}}`.
- Include quality criteria in `{{new_template_constraints_reqs}}`.
- Provide success examples in `{{new_template_examples_full}}`.
- Set clear boundaries for the AI's response scope.

#### For Better Reusability (of the New Template you are creating):
- Use variables (`{{...}}`) for all changing parts of the new prompt.
- Keep the structure of the `{{new_template_main_content}}` consistent.
- Document edge cases and variations thoroughly.
- Provide usage examples that cover various scenarios.

### 10. Testing Your Template (for the New Template you are creating)

#### Test Checklist:
- [ ] The new template works with minimal input.
- [ ] The new template works with complex input.
- [ ] Edge cases for the new template are handled appropriately.
- [ ] The new template's output format is consistent.
- [ ] Instructions within the new template are clear.
- [ ] Variables in the new template are well-defined and used correctly.
- [ ] Examples for the new template are helpful and accurate.

#### Test Cases:
1. **Simple case**: Test the new template with basic input.
2. **Complex case**: Test the new template with detailed and extensive input.
3. **Edge case**: Test the new template with unusual or boundary condition input.
4. **Error case**: Test the new template with invalid or malformed input to see how it handles errors.

### 11. Template Categories (for the New Template you are creating)

#### Technical Prompts
- Code generation
- Code review
- Architecture design
- Debugging
- Optimization

#### Analysis Prompts
- Data analysis
- Performance analysis
- Security analysis
- Trend analysis
- Comparison

#### Creative Prompts
- Content writing
- Ideation
- Storytelling
- Design concepts
- Marketing copy

#### Learning Prompts
- Explanations
- Tutorials
- Study guides
- Question generation
- Learning paths

#### Professional Prompts
- Email drafting
- Report writing
- Documentation
- Presentations
- Summaries

### 12. Advanced Template Features (for the New Template you are creating)

#### Conditional Logic
```
{{if variable1}}
  Include this section when variable1 is provided
{{endif}}

{{if-else variable2}}
  Use this when variable2 is X
{{else}}
  Use this otherwise
{{endif}}
```

#### Multi-Step Templates
```
Step 1: [First task]
{{variable1}}

Step 2: Based on Step 1, [second task]
{{variable2}}

Step 3: Combining results, [final task]
```

#### Iterative Templates
```
For each {{item}} in {{collection}}:
1. Analyze {{item}}
2. Compare with {{criteria}}
3. Output results
```

### 13. Documentation Template (for the New Template you are creating)

For sharing your template with others, this is the suggested structure:

```markdown
# Template Name: {{new_template_name}}

## Description
{{new_template_purpose}}

## When to Use
{{new_template_use_cases}}

## Variables

### Required
{{new_template_required_vars_def}}

### Optional
{{new_template_optional_vars_def}}

## Template

```
{{new_template_main_content}}
```

## Examples

{{new_template_examples_full}}

## Notes
{{new_template_additional_guidelines}}
{{new_template_common_mistakes}}
{{new_template_optimization_tips}}
```

### 14. Prompt Template Library Organization (for the New Template you are creating)

#### File Structure
```
templates/
├── {{new_template_category|lower}}/
│   ├── {{new_template_name|kebab-case}}.md
│   └── ...
└── ...
```

#### Naming Convention
- Use kebab-case for filenames.
- Descriptive names.
- Include category prefix if needed.
- Example: `tech-code-review-security.md`

### 15. Quality Checklist for Templates (for the New Template you are creating)

**Structure:**
- [ ] Clear role/context defined in `{{new_template_main_content}}`.
- [ ] Explicit objective defined in `{{new_template_main_content}}`.
- [ ] Well-defined variables listed in `{{new_template_required_vars_def}}` and `{{new_template_optional_vars_def}}`.
- [ ] Structured output format specified in `{{new_template_output_format}}`.
- [ ] Examples provided in `{{new_template_examples_full}}` (if applicable).

**Content:**
- [ ] Comprehensive requirements detailed in `{{new_template_constraints_reqs}}`.
- [ ] Appropriate constraints specified.
- [ ] Quality guidelines included in `{{new_template_additional_guidelines}}`.
- [ ] Edge cases covered in `{{new_template_examples_full}}` or `{{new_template_common_mistakes}}`.

**Usability:**
- [ ] The new template is easy to understand.
- [ ] The new template is easy to customize using its variables.
- [ ] Clear instructions are provided for its usage.
- [ ] Good documentation is generated (if `{{new_template_documentation_section}}` is used).

**Effectiveness:**
- [ ] The new template produces consistent results.
- [ ] The new template works across its defined use cases.
- [ ] The new template handles variations well.
- [ ] The new template has been tested and validated (refer to `{{new_template_testing_checklist}}`).
