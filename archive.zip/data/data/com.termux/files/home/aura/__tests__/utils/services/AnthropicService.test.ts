// __tests__/utils/services/AnthropicService.test.ts
import AnthropicService from '../../../utils/services/AnthropicService';
import MultiServiceApiClient from '../../../utils/MultiServiceApiClient';
import { ApiService } from '../../../utils/ApiKeyManager';
import axios from 'axios';

// Mock MultiServiceApiClient to control the axios instance it returns
jest.mock('../../../utils/MultiServiceApiClient', () => ({
  getClient: jest.fn(),
}));

describe('AnthropicService', () => {
  const mockAxiosInstance = {
    post: jest.fn(),
  } as unknown as axios.AxiosInstance;

  beforeEach(() => {
    jest.clearAllMocks();
    (MultiServiceApiClient.getClient as jest.Mock).mockResolvedValue(mockAxiosInstance);
  });

  describe('chatCompletion', () => {
    const mockMessages = [{ role: 'user', content: 'Hello' }];
    const mockOptions = { max_tokens: 100 }; // Anthropic requires max_tokens
    const mockResponseData = {
      id: 'msg_01A01A01A01A01A01A01A01A',
      type: 'message',
      role: 'assistant',
      model: 'claude-3-sonnet-20240229',
      stop_reason: 'end_turn',
      stop_sequence: null,
      usage: { input_tokens: 10, output_tokens: 20 },
      content: [{ type: 'text', text: 'Hi there from Claude!' }],
    };

    it('should call messages API with default model and max_tokens', async () => {
      mockAxiosInstance.post.mockResolvedValue({ data: mockResponseData });

      const response = await AnthropicService.chatCompletion(mockMessages, mockOptions);

      expect(MultiServiceApiClient.getClient).toHaveBeenCalledWith(ApiService.Anthropic);
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/messages', {
        model: 'claude-3-sonnet-20240229',
        max_tokens: 100,
        messages: mockMessages,
      });
      expect(response).toEqual(mockResponseData);
    });

    it('should call messages API with specified model and options', async () => {
      mockAxiosInstance.post.mockResolvedValue({ data: mockResponseData });

      const options = { model: 'claude-3-opus-20240229', temperature: 0.8, max_tokens: 200, system: 'You are helpful.' };
      const response = await AnthropicService.chatCompletion(mockMessages, options);

      expect(MultiServiceApiClient.getClient).toHaveBeenCalledWith(ApiService.Anthropic);
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/messages', {
        model: 'claude-3-opus-20240229',
        max_tokens: 200,
        messages: mockMessages,
        system: 'You are helpful.',
        temperature: 0.8,
      });
      expect(response).toEqual(mockResponseData);
    });

    it('should use default max_tokens if not provided in options', async () => {
      mockAxiosInstance.post.mockResolvedValue({ data: mockResponseData });

      const options = { model: 'claude-3-sonnet-20240229' }; // No max_tokens
      await AnthropicService.chatCompletion(mockMessages, options);

      expect(mockAxiosInstance.post).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({ max_tokens: 1024 }) // Expect default 1024
      );
    });
  });
});
