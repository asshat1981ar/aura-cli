# Self-Prompt: 2.3 Plugin Context (Sandbox)

## THOUGHT
The objective of this phase is to implement the runtime environment and security mechanisms for plugins, ensuring they operate within a controlled "sandbox" and interact with the platform through the defined `IPluginContext` and `IExecutionContext` interfaces. This involves creating a `PluginRuntime` or `PluginSandbox` class responsible for isolating plugin execution, providing controlled access to platform services, and managing any potential security risks associated with dynamically loaded code. The goal is to prevent malicious or faulty plugins from compromising the main application.

## QUESTIONS
1.  How will plugin execution be isolated to prevent direct access to sensitive global objects or file system operations outside of designated boundaries?
2.  What is the best way to inject the `IPluginContext` and `IExecutionContext` into plugin methods (`onLoad`, `onUnload`, `execute`) while maintaining type safety and security?
3.  How will resource limits (e.g., CPU, memory, network access) be imposed on plugin execution? (Consider platform limitations: Node.js vs. Web vs. React Native).
4.  What mechanisms will be used to handle errors and exceptions originating from plugin code, ensuring they don't crash the main application?
5.  How will the "sandbox" be structured for different environments (Node.js for server-side plugins/dev tools, Web for browser plugins, React Native for mobile plugins)?
6.  How will communication between the main application and sandboxed plugins occur (e.g., message passing, shared event bus)?

## PLAN
1.  **Design `PluginRuntime` Class**:
    *   Create `plugins/PluginRuntime.ts`.
    *   Implement a class responsible for orchestrating plugin execution within a controlled environment.
    *   It will take `IPluginContext` and potentially a reference to `PluginRegistry`.
2.  **Isolate Plugin Execution (Conceptual/Basic)**:
    *   For Node.js environments: Explore options like `vm` module (for basic sandboxing) or separate worker threads (`worker_threads`) for stronger isolation. (Note: Full, robust sandboxing is complex and may exceed initial scope, focus on controlled access.)
    *   For Web/React Native: Reliance on the browser's/JS engine's inherent sandboxing and careful API exposure.
    *   **Initial Focus**: Focus on controlling access to `IPluginContext` services and preventing direct global access.
3.  **Controlled Context Injection**:
    *   The `PluginRuntime` will call plugin methods (`onLoad`, `onUnload`, `execute`) and pass a carefully constructed `IPluginContext` and `IExecutionContext`.
    *   Ensure that services in `IPluginContext` are exposed safely (e.g., not allowing plugins to directly manipulate `ApiKeyManager` to delete all keys without proper authorization). Read-only access or delegated methods.
4.  **Error Handling for Plugin Execution**:
    *   Implement `try...catch` blocks around plugin method calls within `PluginRuntime`.
    *   Log plugin errors using `Logger` and prevent them from propagating to the main event loop.
    *   Consider returning a standardized `PluginExecutionResult` (success/failure, error details).
5.  **Resource Limits (Placeholder)**:
    *   Document the need for resource limits. For initial implementation, this will be a `TODO` for future enhancement, as it's highly environment-dependent.
6.  **Communication (Placeholder)**:
    *   Document the need for message passing or an event bus for complex plugin-app communication. For initial implementation, plugins interact directly via context methods.

## VERIFICATION
1.  **Unit Tests for `PluginRuntime`**:
    *   Test `PluginRuntime` successfully calls `onLoad`, `onUnload`, and `execute` of mocked plugins.
    *   Verify that plugins receive the correct `IPluginContext` and `IExecutionContext`.
    *   Test error handling: ensure plugin errors are caught, logged, and don't crash the runtime.
    *   Mock attempts by plugins to access unauthorized global objects (if basic sandboxing is implemented).
2.  **Integration with `PluginRegistry`**:
    *   Test that `PluginRegistry` can load plugins, and `PluginRuntime` can then execute them.
    *   Verify the `IPluginContext` passed to `onLoad` contains correctly initialized services.
3.  **Code Review**:
    *   Review `PluginRuntime.ts` for security vulnerabilities and potential points of escape from the sandbox.
    *   Ensure adherence to principles of least privilege when exposing services via `IPluginContext`.
    *   Verify clear logging of plugin activities and errors.
```
