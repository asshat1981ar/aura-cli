// __tests__/utils/SecureStorage.test.ts
import SecureStorage from '../../utils/SecureStorage';
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';

// Mock expo-secure-store and AsyncStorage
jest.mock('expo-secure-store', () => ({
  setItemAsync: jest.fn(),
  getItemAsync: jest.fn(),
  deleteItemAsync: jest.fn(),
}));

jest.mock('@react-native-async-storage/async-storage', () => ({
  setItem: jest.fn(),
  getItem: jest.fn(),
  removeItem: jest.fn(),
  clear: jest.fn(),
}));

// Mock Platform for controlling native/web
jest.mock('react-native', () => ({
  Platform: {
    OS: 'ios', // Default to iOS for native tests
    select: jest.fn((options: any) => options.ios),
  },
}));

// Mock Web Crypto API for web tests
const mockCrypto = {
  getRandomValues: jest.fn((arr) => {
    for (let i = 0; i < arr.length; i++) arr[i] = Math.floor(Math.random() * 256);
    return arr;
  }),
  subtle: {
    importKey: jest.fn(async (format, keyData, algorithm, extractable, keyUsages) => {
      // Return a dummy key object
      return { type: 'secret', algorithm: algorithm.name, extractable, usages: keyUsages };
    }),
    encrypt: jest.fn(async (algorithm, key, data) => {
      // Simulate encryption: just base64 encode for simplicity in mock
      return new ArrayBuffer(data.byteLength); // Return dummy ArrayBuffer
    }),
    decrypt: jest.fn(async (algorithm, key, data) => {
      // Simulate decryption: just return dummy ArrayBuffer
      return new ArrayBuffer(data.byteLength); // Return dummy ArrayBuffer
    }),
  },
};

// @ts-ignore
global.crypto = mockCrypto; // Make mock crypto available globally for web.ts


describe('SecureStorage (Native)', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    (Platform.OS as any) = 'ios'; // Ensure native platform for these tests
  });

  it('should set and get an item using SecureStore', async () => {
    (SecureStore.getItemAsync as jest.Mock).mockResolvedValueOnce('testValue');
    await SecureStorage.setItem('testKey', 'testValue');
    const value = await SecureStorage.getItem('testKey');
    expect(SecureStore.setItemAsync).toHaveBeenCalledWith('testKey', 'testValue');
    expect(value).toBe('testValue');
  });

  it('should delete an item using SecureStore', async () => {
    await SecureStorage.deleteItem('testKey');
    expect(SecureStore.deleteItemAsync).toHaveBeenCalledWith('testKey');
  });

  it('should return null for non-existent item using SecureStore', async () => {
    (SecureStore.getItemAsync as jest.Mock).mockResolvedValueOnce(null);
    const value = await SecureStorage.getItem('nonExistentKey');
    expect(value).toBeNull();
  });

  it('should check if an item exists using SecureStore', async () => {
    (SecureStore.getItemAsync as jest.Mock).mockResolvedValueOnce('someValue');
    const exists = await SecureStorage.hasItem('testKey');
    expect(exists).toBe(true);
    (SecureStore.getItemAsync as jest.Mock).mockResolvedValueOnce(null);
    const notExists = await SecureStorage.hasItem('nonExistentKey');
    expect(notExists).toBe(false);
  });

  it('should warn when calling clearAll on native and not perform operation', async () => {
    const consoleWarnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});
    await SecureStorage.clearAll();
    expect(consoleWarnSpy).toHaveBeenCalledWith(
      "SecureStorageNative.clearAll() is not directly supported by expo-secure-store."
    );
    consoleWarnSpy.mockRestore();
  });
});

describe('SecureStorage (Web)', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    (Platform.OS as any) = 'web'; // Ensure web platform for these tests
    // Mock AsyncStore with an in-memory store for web
    let store: { [key: string]: string } = {};
    (AsyncStorage.setItem as jest.Mock).mockImplementation(async (key, value) => {
      store[key] = value;
    });
    (AsyncStorage.getItem as jest.Mock).mockImplementation(async (key) => {
      return store[key] || null;
    });
    (AsyncStorage.removeItem as jest.Mock).mockImplementation(async (key) => {
      delete store[key];
    });
    (AsyncStorage.clear as jest.Mock).mockImplementation(async () => {
      store = {};
    });
    (mockCrypto.subtle.encrypt as jest.Mock).mockImplementation(async (algo, key, data) => {
        // Simulate encryption with base64 encoding (not actual crypto, but enough for mock)
        const text = new TextDecoder().decode(data);
        const encoded = btoa(text + '_ENCRYPTED_'); // Add a tag to show it was "encrypted"
        return Uint8Array.from(encoded, c => c.charCodeAt(0)).buffer;
    });
    (mockCrypto.subtle.decrypt as jest.Mock).mockImplementation(async (algo, key, data) => {
        // Simulate decryption by removing the tag
        const encoded = String.fromCharCode(...new Uint8Array(data));
        const text = atob(encoded);
        if (text.endsWith('_ENCRYPTED_')) {
            return new TextEncoder().encode(text.replace('_ENCRYPTED_', '')).buffer;
        }
        return new TextEncoder().encode(text).buffer;
    });
  });

  it('should set and get an item using AsyncStorage with encryption', async () => {
    await SecureStorage.setItem('webKey', 'webValue');
    const storedValue = await AsyncStorage.getItem('webKey');
    expect(storedValue).toContain('_ENCRYPTED_'); // Check if mock encrypt was called
    const retrievedValue = await SecureStorage.getItem('webKey');
    expect(retrievedValue).toBe('webValue');
  });

  it('should delete an item using AsyncStorage', async () => {
    await SecureStorage.setItem('webKeyToDelete', 'value');
    await SecureStorage.deleteItem('webKeyToDelete');
    const value = await AsyncStorage.getItem('webKeyToDelete');
    expect(value).toBeNull();
  });

  it('should return null for non-existent item on web', async () => {
    const value = await SecureStorage.getItem('nonExistentWebKey');
    expect(value).toBeNull();
  });

  it('should check if an item exists on web', async () => {
    await SecureStorage.setItem('existingWebKey', 'value');
    const exists = await SecureStorage.hasItem('existingWebKey');
    expect(exists).toBe(true);
    const notExists = await SecureStorage.hasItem('nonExistentWebKey');
    expect(notExists).toBe(false);
  });

  it('should clear all items on web using AsyncStorage.clear', async () => {
    await SecureStorage.setItem('key1', 'value1');
    await SecureStorage.setItem('key2', 'value2');
    await SecureStorage.clearAll();
    const value1 = await SecureStorage.getItem('key1');
    const value2 = await SecureStorage.getItem('key2');
    expect(value1).toBeNull();
    expect(value2).toBeNull();
  });
});
