import numpy as np
import sqlite3

class VectorStore:
    def __init__(self, model_adapter, brain):
        self.model_adapter = model_adapter
        self.brain = brain # Store brain instance for database access
        self.vectors = []
        self.contents = []
        self._load_from_db()
        print("VectorStore initialized.")

    def _load_from_db(self):
        rows = self.brain.db.execute("SELECT content, embedding FROM vector_store_data").fetchall()
        for content, embedding_blob in rows:
            self.contents.append(content)
            self.vectors.append(np.frombuffer(embedding_blob, dtype=np.float32))
        print(f"VectorStore: Loaded {len(self.contents)} entries from DB.")

    def add(self, content: str):
        embedding = self.model_adapter.get_embedding(content)
        self.vectors.append(embedding)
        self.contents.append(content)
        
        # Persist to DB
        self.brain.db.execute(
            "INSERT INTO vector_store_data(content, embedding) VALUES (?, ?)",
            (content, embedding.tobytes())
        )
        self.brain.db.commit()
        print(f"VectorStore: Added and persisted content: {content[:50]}...") # Truncate for display

    def search(self, query: str, k: int = 5) -> list[str]:
        if not self.vectors:
            return []

        query_embedding = self.model_adapter.get_embedding(query)
        
        similarities = []
        for i, vec in enumerate(self.vectors):
            # Calculate cosine similarity
            similarity = np.dot(query_embedding, vec) / (np.linalg.norm(query_embedding) * np.linalg.norm(vec))
            similarities.append((similarity, i))
        
        similarities.sort(key=lambda x: x[0], reverse=True)
        
        results = []
        for sim, idx in similarities[:k]:
            results.append(self.contents[idx])
        
        print(f"VectorStore: Searched for '{query[:50]}...', found {len(results)} results.")
        return results