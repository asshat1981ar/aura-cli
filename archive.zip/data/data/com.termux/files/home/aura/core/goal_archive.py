import json
import os

class GoalArchive:

    def __init__(self, archive_path="memory/goal_archive.json"):
        self.archive_path = archive_path
        self.completed = self._load_archive()

    def record(self, goal, score):
        self.completed.append((goal, score))
        self._save_archive()

    def _save_archive(self):
        os.makedirs(os.path.dirname(self.archive_path), exist_ok=True)
        with open(self.archive_path, 'w') as f:
            json.dump(self.completed, f, indent=4)

    def _load_archive(self):
        if os.path.exists(self.archive_path):
            with open(self.archive_path, 'r') as f:
                try:
                    return json.load(f)
                except json.JSONDecodeError:
                    print(f"Warning: Could not decode JSON from {self.archive_path}. Starting with empty archive.")
                    return []
        return []
