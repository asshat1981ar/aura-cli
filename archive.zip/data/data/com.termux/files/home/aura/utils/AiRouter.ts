// utils/AiRouter.ts
import { ApiService } from './ApiKeyManager';
import ConfigService from './ConfigService';
import OpenAIService from './services/OpenAIService';
import AnthropicService from './services/AnthropicService';
import GoogleAIService from './services/GoogleAIService';
import DeepLService from './services/DeepLService'; // Include if translation is part of AI routing

// Define a common interface for AI services that support chat completion
interface ChatCompletionService {
  chatCompletion(messages: any[], options?: any): Promise<any>;
}

// Define a common interface for AI services that support embedding generation
interface EmbeddingService {
  generateEmbedding(input: string | string[], model?: string): Promise<any>;
}

class AiRouter {
  /**
   * Performs a chat completion using the active AI service and its configured model.
   * @param messages Conversation history in a generic format.
   * @param options Generic options, specific options will be mapped to service-specific ones.
   * @returns Promise<any> Service-specific chat completion response.
   */
  static async chatCompletion(messages: any[], options?: any): Promise<any> {
    const activeService = await ConfigService.getActiveAiService();
    const defaultModel = await ConfigService.getDefaultModel(activeService);

    let serviceInstance: ChatCompletionService;

    switch (activeService) {
      case ApiService.OpenAI:
        serviceInstance = OpenAIService;
        break;
      case ApiService.Anthropic:
        serviceInstance = AnthropicService;
        break;
      case ApiService.Google:
        serviceInstance = GoogleAIService;
        break;
      // Add other chat-capable services here
      default:
        throw new Error(`Chat completion not supported for active service: ${activeService}`);
    }

    // Map generic options to service-specific options as needed
    const serviceOptions = { ...options, model: options?.model || defaultModel };

    return serviceInstance.chatCompletion(messages, serviceOptions);
  }

  /**
   * Generates embeddings using the active AI service and its configured model.
   * @param input The text or array of texts to generate embeddings for.
   * @param model The embedding model to use.
   * @returns Promise<any> Service-specific embedding response.
   */
  static async generateEmbedding(input: string | string[], model?: string): Promise<any> {
    const activeService = await ConfigService.getActiveAiService();
    const defaultModel = await ConfigService.getDefaultModel(activeService);

    let serviceInstance: EmbeddingService;

    switch (activeService) {
      case ApiService.OpenAI:
        serviceInstance = OpenAIService;
        break;
      case ApiService.Google: // Assuming GoogleAIService also has generateEmbedding
        serviceInstance = GoogleAIService;
        break;
      // Add other embedding-capable services here
      default:
        throw new Error(`Embedding generation not supported for active service: ${activeService}`);
    }

    const embeddingModel = model || defaultModel || 'text-embedding-ada-002'; // Fallback to OpenAI's common model

    return serviceInstance.generateEmbedding(input, embeddingModel);
  }

  /**
   * Performs translation using the active AI service if it supports translation.
   * @param text The text or array of texts to translate.
   * @param options Translation options (e.g., target_lang, source_lang).
   * @returns Promise<any> Service-specific translation response.
   */
  static async translate(text: string | string[], options: { target_lang: string; source_lang?: string; }): Promise<any> {
    const activeService = await ConfigService.getActiveAiService();

    let serviceInstance: any; // Use 'any' for now as not all services have a common TranslationService interface

    switch (activeService) {
      case ApiService.DeepL:
        serviceInstance = DeepLService;
        break;
      // Add other translation-capable services here
      default:
        throw new Error(`Translation not supported by active service: ${activeService}`);
    }

    return serviceInstance.translate(text, options);
  }

  // Add more generic AI functions as needed (e.g., image generation, content moderation)
}

export default AiRouter;
