import os
from typing import Dict, List
import json
from pathlib import Path

class ScaffolderAgent:
    def __init__(self, brain, model):
        self.brain = brain
        self.model = model

    def scaffold_project(self, project_name: str, description: str) -> str:
        prompt = f"""
You are an autonomous project scaffolding agent. Your task is to generate a suitable directory structure and basic file content for a new software project.

Project Name: {project_name}
Project Description: {description}

Previous memory:
{self.brain.recall_all()}

Generate a JSON object representing the project structure. Each key in the JSON should be a file or directory path relative to the project root.
For directories, the value should be an empty dictionary. For files, the value should be the content of the file.
Example:
{{
    "README.md": "# {project_name}

{description}",
    "src/": {{}},
    "src/main.py": "def main():
    print('Hello, {project_name}!')

if __name__ == '__main__':
    main()",
    "tests/": {{}}
}}
"""
        response = self.model.respond(prompt)
        self.brain.remember(f"Scaffolded project '{project_name}' with description: {description}. Structure: {response}")

        try:
            project_structure = json.loads(response)
            if not isinstance(project_structure, dict):
                raise ValueError("Response is not a valid JSON dictionary.")

            project_root = Path(f"projects/{project_name}")
            project_root.mkdir(parents=True, exist_ok=True)
            
            self._create_from_structure(project_root, project_structure)
            return f"Project '{project_name}' scaffolded successfully at {project_root.resolve()}"

        except json.JSONDecodeError:
            return f"Failed to parse project structure JSON. Raw response: {response}"
        except ValueError as e:
            return f"Error in scaffolding: {e}. Raw response: {response}"
        except Exception as e:
            return f"An unexpected error occurred during scaffolding: {e}"

    def _create_from_structure(self, current_path: Path, structure: Dict):
        for name, content in structure.items():
            path = current_path / name
            if isinstance(content, dict): # It's a directory
                path.mkdir(parents=True, exist_ok=True)
                self._create_from_structure(path, content)
            elif isinstance(content, str): # It's a file
                with open(path, "w") as f:
                    f.write(content)
            else:
                print(f"Warning: Unknown content type for {name}. Skipping.")