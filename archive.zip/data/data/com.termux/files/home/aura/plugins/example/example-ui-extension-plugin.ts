// plugins/example/example-ui-extension-plugin.ts
import { IUiExtensionPlugin } from '../../types/plugin/IUiExtensionPlugin';
import { PluginType } from '../../types/plugin/PluginType';
import React from 'react';
import { Text, View, StyleSheet } from 'react-native'; // Assuming React Native components for Expo UI

// Define a simple React component for the UI extension
const CustomWelcomeComponent: React.FC<{ userName?: string }> = ({ userName = 'Guest' }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Hello, {userName}!</Text>
      <Text style={styles.subtitle}>This is a UI extension plugin.</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 10,
    backgroundColor: '#e0f7fa',
    borderRadius: 8,
    marginVertical: 10,
    alignItems: 'center',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#00796b',
  },
  subtitle: {
    fontSize: 14,
    color: '#004d40',
  },
});

class ExampleUiExtensionPlugin implements IUiExtensionPlugin {
  id = 'com.example.ui.welcome-widget';
  name = 'Welcome Widget';
  version = '1.0.0';
  author = 'AURA Example';
  description = 'Provides a custom welcome message widget for the dashboard.';
  type = PluginType.UiExtension;

  extensionPoint = 'dashboard.top'; // Example extension point identifier

  async onLoad(): Promise<void> {
    console.log(`UI Extension Plugin '${this.name}' loaded.`);
  }

  async onUnload(): Promise<void> {
    console.log(`UI Extension Plugin '${this.name}' unloaded.`);
  }

  renderComponent(props: any): React.ComponentType<any> {
    // We pass the props received by renderComponent directly to our custom component
    return (p) => React.createElement(CustomWelcomeComponent, { ...props, ...p });
  }
}

export default ExampleUiExtensionPlugin;
