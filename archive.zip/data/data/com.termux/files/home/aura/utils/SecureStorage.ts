// utils/SecureStorage.ts
import { Platform } from 'react-native'; // Assuming react-native is available in Expo context

interface SecureStorageInterface {
  setItem(key: string, value: string): Promise<void>;
  getItem(key: string): Promise<string | null>;
  deleteItem(key: string): Promise<void>;
  hasItem(key: string): Promise<boolean>;
  clearAll(): Promise<void>;
}

let SecureStorage: SecureStorageInterface;

if (Platform.OS === 'web') {
  // @ts-ignore - SecureStorageWeb will be loaded from .web.ts
  SecureStorage = require('./SecureStorage.web').default;
} else {
  // @ts-ignore - SecureStorageNative will be loaded from .native.ts
  SecureStorage = require('./SecureStorage.native').default;
}

export default SecureStorage;
