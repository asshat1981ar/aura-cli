// __tests__/utils/SecurityMigrationService.test.ts
import SecurityMigrationService from '../../utils/SecurityMigrationService';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SecureStorage from '../../utils/SecureStorage';

jest.mock('@react-native-async-storage/async-storage', () => ({
  getItem: jest.fn(),
  removeItem: jest.fn(),
}));

jest.mock('../../utils/SecureStorage', () => ({
  setItem: jest.fn(),
  getItem: jest.fn(),
}));

// The list of sensitive keys from the service
const MOCKED_SENSITIVE_KEYS = ['legacy_api_key', 'old_user_token'];
// Mock the SENSITIVE_KEYS_IN_ASYNC_STORAGE constant in the service
jest.mock('../../utils/SecurityMigrationService', () => {
  const originalModule = jest.requireActual('../../utils/SecurityMigrationService');
  return {
    ...originalModule,
    SENSITIVE_KEYS_IN_ASYNC_STORAGE: MOCKED_SENSITIVE_KEYS,
  };
});


describe('SecurityMigrationService', () => {
  const MIGRATION_COMPLETED_KEY = 'security_migration_completed';
  let consoleLogSpy: jest.SpyInstance;
  let consoleWarnSpy: jest.SpyInstance;
  let consoleErrorSpy: jest.SpyInstance;

  beforeEach(() => {
    jest.clearAllMocks();
    consoleLogSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    consoleWarnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});
    consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    consoleLogSpy.mockRestore();
    consoleWarnSpy.mockRestore();
    consoleErrorSpy.mockRestore();
  });

  it('should not run migration if already completed', async () => {
    (SecureStorage.getItem as jest.Mock).mockResolvedValueOnce('true'); // Migration already completed
    await SecurityMigrationService.runMigration();

    expect(consoleLogSpy).toHaveBeenCalledWith("Starting security migration check...");
    expect(consoleLogSpy).toHaveBeenCalledWith("Security migration already completed.");
    expect(AsyncStorage.getItem).not.toHaveBeenCalled(); // No attempt to read insecure storage
    expect(SecureStorage.setItem).not.toHaveBeenCalledWith(MIGRATION_COMPLETED_KEY, 'true'); // Should not set again
  });

  it('should migrate sensitive data and remove from insecure storage', async () => {
    (SecureStorage.getItem as jest.Mock).mockResolvedValueOnce(null); // Migration not completed yet
    (AsyncStorage.getItem as jest.Mock)
      .mockResolvedValueOnce('legacy_api_key_value') // legacy_api_key exists
      .mockResolvedValueOnce('old_user_token_value'); // old_user_token exists
    
    // SecureStorage.getItem for verification
    (SecureStorage.getItem as jest.Mock)
      .mockResolvedValueOnce('legacy_api_key_value') // Verification for legacy_api_key
      .mockResolvedValueOnce('old_user_token_value'); // Verification for old_user_token

    await SecurityMigrationService.runMigration();

    // Expect checks
    expect(AsyncStorage.getItem).toHaveBeenCalledWith('legacy_api_key');
    expect(SecureStorage.setItem).toHaveBeenCalledWith('legacy_api_key', 'legacy_api_key_value');
    expect(SecureStorage.getItem).toHaveBeenCalledWith('legacy_api_key'); // Verification call
    expect(AsyncStorage.removeItem).toHaveBeenCalledWith('legacy_api_key');

    expect(AsyncStorage.getItem).toHaveBeenCalledWith('old_user_token');
    expect(SecureStorage.setItem).toHaveBeenCalledWith('old_user_token', 'old_user_token_value');
    expect(SecureStorage.getItem).toHaveBeenCalledWith('old_user_token'); // Verification call
    expect(AsyncStorage.removeItem).toHaveBeenCalledWith('old_user_token');

    expect(SecureStorage.setItem).toHaveBeenCalledWith(MIGRATION_COMPLETED_KEY, 'true');
    expect(consoleLogSpy).toHaveBeenCalledWith("Completed security migration for 2 item(s).");
  });

  it('should handle cases where insecure data does not exist', async () => {
    (SecureStorage.getItem as jest.Mock).mockResolvedValueOnce(null); // Migration not completed yet
    (AsyncStorage.getItem as jest.Mock)
      .mockResolvedValueOnce(null) // legacy_api_key does not exist
      .mockResolvedValueOnce(null); // old_user_token does not exist

    await SecurityMigrationService.runMigration();

    expect(AsyncStorage.getItem).toHaveBeenCalledWith('legacy_api_key');
    expect(AsyncStorage.getItem).toHaveBeenCalledWith('old_user_token');
    expect(SecureStorage.setItem).not.toHaveBeenCalledWith('legacy_api_key', expect.any(String));
    expect(SecureStorage.setItem).not.toHaveBeenCalledWith('old_user_token', expect.any(String));
    expect(AsyncStorage.removeItem).not.toHaveBeenCalled();
    expect(consoleLogSpy).toHaveBeenCalledWith("No sensitive items found for migration.");
    expect(SecureStorage.setItem).toHaveBeenCalledWith(MIGRATION_COMPLETED_KEY, 'true');
  });

  it('should warn if migration verification fails and not remove insecure data', async () => {
    (SecureStorage.getItem as jest.Mock).mockResolvedValueOnce(null); // Migration not completed yet
    (AsyncStorage.getItem as jest.Mock).mockResolvedValueOnce('legacy_api_key_value');
    (SecureStorage.getItem as jest.Mock).mockResolvedValueOnce('some_different_value'); // Verification fails

    await SecurityMigrationService.runMigration();

    expect(SecureStorage.setItem).toHaveBeenCalledWith('legacy_api_key', 'legacy_api_key_value');
    expect(SecureStorage.getItem).toHaveBeenCalledWith('legacy_api_key');
    expect(AsyncStorage.removeItem).not.toHaveBeenCalledWith('legacy_api_key'); // Should NOT remove
    expect(consoleWarnSpy).toHaveBeenCalledWith(
      "Migration verification failed for key: legacy_api_key. Data not removed from insecure storage."
    );
  });

  it('should log error if SecureStorage.setItem fails', async () => {
    (SecureStorage.getItem as jest.Mock).mockResolvedValueOnce(null); // Migration not completed yet
    (AsyncStorage.getItem as jest.Mock).mockResolvedValueOnce('legacy_api_key_value');
    (SecureStorage.setItem as jest.Mock).mockRejectedValueOnce(new Error('SecureStorage error'));

    await SecurityMigrationService.runMigration();

    expect(SecureStorage.setItem).toHaveBeenCalledWith('legacy_api_key', 'legacy_api_key_value');
    expect(consoleErrorSpy).toHaveBeenCalledWith(
      "Error migrating key legacy_api_key:", expect.any(Error)
    );
    expect(AsyncStorage.removeItem).not.toHaveBeenCalledWith('legacy_api_key');
    expect(SecureStorage.setItem).toHaveBeenCalledWith(MIGRATION_COMPLETED_KEY, 'true'); // Still marks as complete
  });
});
