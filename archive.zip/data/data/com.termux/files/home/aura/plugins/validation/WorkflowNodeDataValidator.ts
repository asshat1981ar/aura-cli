// plugins/validation/WorkflowNodeDataValidator.ts
import { z } from 'zod';
import { IDataDefinition, IInputDefinition, IOutputDefinition } from '../../types/workflow/IDataDefinition';
import Logger from '../../utils/Logger';

// Zod schema for IDataDefinition
const DataDefinitionSchema = z.object({
  name: z.string().min(1),
  type: z.enum(['string', 'number', 'boolean', 'object', 'array', 'enum', 'any']),
  description: z.string().optional(),
  required: z.boolean().optional(),
  defaultValue: z.any().optional(),
  options: z.array(z.union([z.string(), z.number()])).optional(),
  schema: z.record(z.string(), z.any()).optional(), // Placeholder for complex JSON Schema
});

// IInputDefinition and IOutputDefinition extend IDataDefinition
const InputDefinitionSchema = DataDefinitionSchema; // For now, same schema
const OutputDefinitionSchema = DataDefinitionSchema; // For now, same schema

/**
 * Helper to build a Zod schema from an IDataDefinition.
 * This function will dynamically create a Zod schema based on the 'type' and 'schema' properties.
 * @param definition The IDataDefinition to convert.
 * @returns A Zod schema.
 */
function buildZodSchemaFromDataDefinition(definition: IDataDefinition): z.ZodTypeAny {
  let schema: z.ZodTypeAny;

  switch (definition.type) {
    case 'string':
      schema = z.string();
      break;
    case 'number':
      schema = z.number();
      break;
    case 'boolean':
      schema = z.boolean();
      break;
    case 'object':
      // If a 'schema' is provided, try to use it. Otherwise, accept any object.
      schema = definition.schema ? z.record(z.string(), z.any()) : z.object({}); // TODO: Dynamically build Zod from JSON Schema
      break;
    case 'array':
      // If a 'schema' is provided, try to use it for array elements. Otherwise, accept any array.
      schema = definition.schema ? z.array(z.any()) : z.array(z.any()); // TODO: Dynamically build Zod from JSON Schema for elements
      break;
    case 'enum':
      schema = definition.options ? z.enum(definition.options as [string, ...string[]]) : z.string(); // Fallback to string if no options
      break;
    case 'any':
    default:
      schema = z.any();
      break;
  }

  if (definition.required) {
    schema = schema.refine((val) => val !== undefined, { message: `${definition.name} is required.` });
  } else {
    schema = schema.optional();
  }
  
  // If a default value is specified and the field is optional, apply it
  if (!definition.required && definition.defaultValue !== undefined) {
    schema = schema.default(definition.defaultValue);
  }

  return schema;
}


class WorkflowNodeDataValidator {
  /**
   * Validates input data for a workflow node against its input definitions.
   * @param data The actual input data received by the node.
   * @param inputDefinitions The expected input definitions from the plugin.
   * @throws {z.ZodError} or custom error if validation fails.
   */
  static validateInputData(data: Record<string, any>, inputDefinitions: IInputDefinition[]): void {
    const dataSchema: Record<string, z.ZodTypeAny> = {};
    for (const def of inputDefinitions) {
      dataSchema[def.name] = buildZodSchemaFromDataDefinition(def);
    }
    const finalSchema = z.object(dataSchema);

    try {
      finalSchema.parse(data);
    } catch (error: any) {
      Logger.warn(`Input data validation failed: ${error.message}`, error);
      throw error; // Re-throw ZodError
    }
    Logger.debug('Input data validated successfully.');
  }

  /**
   * Validates output data from a workflow node against its output definitions.
   * @param data The actual output data produced by the node.
   * @param outputDefinitions The expected output definitions from the plugin.
   * @throws {z.ZodError} or custom error if validation fails.
   */
  static validateOutputData(data: any, outputDefinitions: IOutputDefinition[]): void {
    // If no output definitions are provided, any output is considered valid
    if (!outputDefinitions || outputDefinitions.length === 0) {
      Logger.debug('No output definitions provided, skipping output validation.');
      return;
    }

    const dataSchema: Record<string, z.ZodTypeAny> = {};
    for (const def of outputDefinitions) {
      dataSchema[def.name] = buildZodSchemaFromDataDefinition(def);
    }
    const finalSchema = z.object(dataSchema);

    try {
      finalSchema.parse(data);
    } catch (error: any) {
      Logger.warn(`Output data validation failed: ${error.message}`, error);
      throw error; // Re-throw ZodError
    }
    Logger.debug('Output data validated successfully.');
  }
}

export default WorkflowNodeDataValidator;
