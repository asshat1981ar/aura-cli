// __tests__/plugins/PluginRegistry.test.ts
import PluginRegistry from '../../plugins/PluginRegistry';
import { IPlugin } from '../../types/plugin/IPlugin';
import { IPluginManifest } from '../../types/plugin/IPluginManifest';
import { PluginType } from '../../types/plugin/PluginType';
import Logger from '../../utils/Logger';

// Mock fs/promises and path
jest.mock('fs/promises', () => ({
  readdir: jest.fn(),
  readFile: jest.fn(),
}));
jest.mock('path', () => ({
  join: jest.fn((...args: string[]) => args.join('/')), // Simple join for mocking
  resolve: jest.fn((...args: string[]) => args.join('/')), // Simple resolve for mocking
}));

// Mock dynamic import for plugins
jest.mock('../../plugins/example/example-workflow-node', () => ({
  default: jest.fn(() => ({
    id: 'com.example.workflow.sum-numbers',
    name: 'Sum Numbers Node',
    version: '1.0.0',
    author: 'AURA Example',
    description: 'A simple workflow node that sums two input numbers.',
    type: PluginType.WorkflowNode,
    inputs: [],
    outputs: [],
    execute: jest.fn(),
    onLoad: jest.fn(),
    onUnload: jest.fn(),
  })),
}));

jest.mock('../../plugins/example/example-integration-plugin', () => ({
  default: jest.fn(() => ({
    id: 'com.example.integration.external-api',
    name: 'External API Integration',
    version: '1.0.0',
    author: 'AURA Example',
    description: 'Integrates with a dummy external API and exposes OpenAI/Google services.',
    type: PluginType.Integration,
    integratesWith: [],
    getService: jest.fn(),
    onLoad: jest.fn(),
    onUnload: jest.fn(),
  })),
}));

jest.mock('../../plugins/example/example-ui-extension-plugin', () => ({
  default: jest.fn(() => ({
    id: 'com.example.ui.welcome-widget',
    name: 'Welcome Widget',
    version: '1.0.0',
    author: 'AURA Example',
    description: 'Provides a custom welcome message widget for the dashboard.',
    type: PluginType.UiExtension,
    extensionPoint: 'dashboard.top',
    renderComponent: jest.fn(),
    onLoad: jest.fn(),
    onUnload: jest.fn(),
  })),
}));

// Mock the Logger to prevent console output during tests
jest.mock('../../utils/Logger', () => ({
  debug: jest.fn(),
  info: jest.fn(),
  warn: jest.fn(),
  error: jest.fn(),
}));

// Re-import the mocked fs and path after jest.mock calls
import * as fs from 'fs/promises';
import * as path from 'path';

describe('PluginRegistry', () => {
  let pluginRegistry: PluginRegistry;
  let mockLoggerWarn: jest.SpyInstance;
  let mockLoggerError: jest.SpyInstance;
  let mockLoggerInfo: jest.SpyInstance;

  beforeEach(() => {
    // Clear all mocks and re-initialize the registry instance for each test
    jest.clearAllMocks();
    // Reset the internal instance of the singleton to get a fresh one for each test
    // @ts-ignore
    PluginRegistry.instance = undefined;
    pluginRegistry = PluginRegistry.getInstance();

    mockLoggerWarn = jest.spyOn(Logger, 'warn').mockImplementation(() => {});
    mockLoggerError = jest.spyOn(Logger, 'error').mockImplementation(() => {});
    mockLoggerInfo = jest.spyOn(Logger, 'info').mockImplementation(() => {});
  });

  afterEach(() => {
    mockLoggerWarn.mockRestore();
    mockLoggerError.mockRestore();
    mockLoggerInfo.mockRestore();
  });

  it('should be a singleton', () => {
    const instance1 = PluginRegistry.getInstance();
    const instance2 = PluginRegistry.getInstance();
    expect(instance1).toBe(instance2);
  });

  describe('discoverPlugins', () => {
    const mockPluginManifest: IPluginManifest = {
      id: 'com.example.test-plugin',
      name: 'Test Plugin',
      version: '1.0.0',
      author: 'Test',
      description: 'A test plugin.',
      type: PluginType.WorkflowNode,
      entryPoint: 'index.js',
    };

    it('should discover valid plugins', async () => {
      (fs.readdir as jest.Mock).mockResolvedValueOnce([
        { name: 'test-plugin', isDirectory: () => true },
      ]);
      (fs.readFile as jest.Mock).mockResolvedValueOnce(JSON.stringify(mockPluginManifest));

      const manifests = await pluginRegistry.discoverPlugins(['/plugins']);
      expect(manifests).toHaveLength(1);
      expect(manifests[0].id).toBe('com.example.test-plugin');
      expect((manifests[0] as any)._pluginRootPath).toBe('/plugins/test-plugin');
    });

    it('should handle missing plugin.json gracefully', async () => {
      (fs.readdir as jest.Mock).mockResolvedValueOnce([
        { name: 'test-plugin', isDirectory: () => true },
      ]);
      (fs.readFile as jest.Mock).mockRejectedValueOnce({ code: 'ENOENT' }); // No plugin.json

      const manifests = await pluginRegistry.discoverPlugins(['/plugins']);
      expect(manifests).toHaveLength(0);
      expect(Logger.debug).toHaveBeenCalledWith(expect.stringContaining('No plugin.json found'));
    });

    it('should log error for invalid plugin.json format', async () => {
      (fs.readdir as jest.Mock).mockResolvedValueOnce([
        { name: 'invalid-plugin', isDirectory: () => true },
      ]);
      (fs.readFile as jest.Mock).mockResolvedValueOnce('{"id": "invalid"}'); // Missing name, version, entryPoint, type

      const manifests = await pluginRegistry.discoverPlugins(['/plugins']);
      expect(manifests).toHaveLength(0);
      expect(Logger.warn).toHaveBeenCalledWith(expect.stringContaining('Invalid plugin.json found'));
    });

    it('should log error for malformed JSON', async () => {
      (fs.readdir as jest.Mock).mockResolvedValueOnce([
        { name: 'malformed-plugin', isDirectory: () => true },
      ]);
      (fs.readFile as jest.Mock).mockResolvedValueOnce('{this is not json'); // Malformed JSON

      const manifests = await pluginRegistry.discoverPlugins(['/plugins']);
      expect(manifests).toHaveLength(0);
      expect(Logger.error).toHaveBeenCalledWith(expect.stringContaining('Error reading or parsing plugin.json'), expect.any(Error));
    });

    it('should handle non-existent plugin directories', async () => {
      (fs.readdir as jest.Mock).mockRejectedValueOnce({ code: 'ENOENT' }); // Directory not found

      const manifests = await pluginRegistry.discoverPlugins(['/non-existent-plugins']);
      expect(manifests).toHaveLength(0);
      expect(Logger.warn).toHaveBeenCalledWith(expect.stringContaining('Plugin directory not found'));
    });
  });

  describe('loadAndRegisterPlugin', () => {
    const mockWorkflowNodeManifest: IPluginManifest = {
      id: 'com.example.workflow.sum-numbers',
      name: 'Sum Numbers Node',
      version: '1.0.0',
      author: 'AURA Example',
      description: 'A simple workflow node that sums two input numbers.',
      type: PluginType.WorkflowNode,
      entryPoint: 'example-workflow-node.ts',
      _pluginRootPath: '/plugins/example',
    };
    const mockIntegrationPluginManifest: IPluginManifest = {
      id: 'com.example.integration.external-api',
      name: 'External API Integration',
      version: '1.0.0',
      author: 'AURA Example',
      description: 'Integrates with a dummy external API and exposes OpenAI/Google services.',
      type: PluginType.Integration,
      entryPoint: 'example-integration-plugin.ts',
      _pluginRootPath: '/plugins/example',
      dependencies: {
        'com.example.workflow.sum-numbers': '^1.0.0',
      },
    };

    it('should load and register a plugin successfully', async () => {
      // Mock dynamic import for specific plugin path
      jest.doMock('/plugins/example/example-workflow-node.ts', () => require('../../plugins/example/example-workflow-node'), { virtual: true });
      
      const plugin = await pluginRegistry.loadAndRegisterPlugin(mockWorkflowNodeManifest);

      expect(plugin.id).toBe(mockWorkflowNodeManifest.id);
      expect(pluginRegistry.getPlugin(mockWorkflowNodeManifest.id)).toBe(plugin);
      expect(plugin.onLoad).toHaveBeenCalledWith(pluginRegistry['pluginContext']);
      expect(Logger.info).toHaveBeenCalledWith(expect.stringContaining('loaded and registered.'));
    });

    it('should warn if dependency is not found', async () => {
        // Mock dynamic import for specific plugin path
        jest.doMock('/plugins/example/example-integration-plugin.ts', () => require('../../plugins/example/example-integration-plugin'), { virtual: true });
        
        await pluginRegistry.loadAndRegisterPlugin(mockIntegrationPluginManifest);
        expect(Logger.warn).toHaveBeenCalledWith(expect.stringContaining('Dependency 'com.example.workflow.sum-numbers' for plugin 'com.example.integration.external-api' not found.'));
    });

    it('should not load a plugin if already loaded', async () => {
      // Mock dynamic import
      jest.doMock('/plugins/example/example-workflow-node.ts', () => require('../../plugins/example/example-workflow-node'), { virtual: true });
      
      await pluginRegistry.loadAndRegisterPlugin(mockWorkflowNodeManifest);
      const plugin2 = await pluginRegistry.loadAndRegisterPlugin(mockWorkflowNodeManifest);

      expect(mockLoggerWarn).toHaveBeenCalledWith(expect.stringContaining('already loaded'));
      expect(pluginRegistry.getPlugin(mockWorkflowNodeManifest.id)).toBe(plugin2);
      expect(mockWorkflowNodeManifest.onLoad).toHaveBeenCalledTimes(1); // onLoad should only be called once
    });
  });

  describe('unloadPlugin', () => {
    const mockPlugin: IPlugin = {
      id: 'test-unload-plugin',
      name: 'Test Unload',
      version: '1.0.0',
      author: 'Test',
      description: 'A test plugin to unload.',
      type: PluginType.WorkflowNode,
      onLoad: jest.fn(),
      onUnload: jest.fn(),
    };

    beforeEach(() => {
      // Manually add plugin to registry for unload test
      pluginRegistry['plugins'].set(mockPlugin.id, mockPlugin);
    });

    it('should unload a plugin successfully', async () => {
      await pluginRegistry.unloadPlugin(mockPlugin.id);

      expect(mockPlugin.onUnload).toHaveBeenCalledWith(pluginRegistry['pluginContext']);
      expect(pluginRegistry.getPlugin(mockPlugin.id)).toBeUndefined();
      expect(Logger.info).toHaveBeenCalledWith(expect.stringContaining('unloaded.'));
    });

    it('should warn if attempting to unload non-existent plugin', async () => {
      await pluginRegistry.unloadPlugin('non-existent');
      expect(mockLoggerWarn).toHaveBeenCalledWith(expect.stringContaining('non-existent plugin'));
    });

    it('should throw error if onUnload fails', async () => {
      (mockPlugin.onUnload as jest.Mock).mockRejectedValueOnce(new Error('Unload error'));
      
      await expect(pluginRegistry.unloadPlugin(mockPlugin.id)).rejects.toThrow('Plugin unloading failed');
      expect(Logger.error).toHaveBeenCalledWith(expect.stringContaining('Error unloading plugin'), expect.any(Error));
    });
  });

  describe('getPlugin', () => {
    const pluginA: IPlugin = { ...mockWorkflowNodeManifest, id: 'pluginA', type: PluginType.WorkflowNode };
    const pluginB: IPlugin = { ...mockIntegrationPluginManifest, id: 'pluginB', type: PluginType.Integration };

    beforeEach(() => {
      pluginRegistry['plugins'].set(pluginA.id, pluginA);
      pluginRegistry['plugins'].set(pluginB.id, pluginB);
    });

    it('should retrieve a plugin by ID', () => {
      const retrieved = pluginRegistry.getPlugin('pluginA');
      expect(retrieved).toBe(pluginA);
    });

    it('should return undefined if plugin not found', () => {
      const retrieved = pluginRegistry.getPlugin('non-existent');
      expect(retrieved).toBeUndefined();
    });
  });

  describe('getPluginsByType', () => {
    const pluginW1: IPlugin = { ...mockWorkflowNodeManifest, id: 'w1', type: PluginType.WorkflowNode };
    const pluginW2: IPlugin = { ...mockWorkflowNodeManifest, id: 'w2', type: PluginType.WorkflowNode };
    const pluginI1: IPlugin = { ...mockIntegrationPluginManifest, id: 'i1', type: PluginType.Integration };

    beforeEach(() => {
      pluginRegistry['plugins'].set(pluginW1.id, pluginW1);
      pluginRegistry['plugins'].set(pluginW2.id, pluginW2);
      pluginRegistry['plugins'].set(pluginI1.id, pluginI1);
    });

    it('should retrieve plugins by type', () => {
      const workflowPlugins = pluginRegistry.getPluginsByType(PluginType.WorkflowNode);
      expect(workflowPlugins).toHaveLength(2);
      expect(workflowPlugins).toContain(pluginW1);
      expect(workflowPlugins).toContain(pluginW2);

      const integrationPlugins = pluginRegistry.getPluginsByType(PluginType.Integration);
      expect(integrationPlugins).toHaveLength(1);
      expect(integrationPlugins).toContain(pluginI1);
    });

    it('should return empty array if no plugins of specified type', () => {
      const uiPlugins = pluginRegistry.getPluginsByType(PluginType.UiExtension);
      expect(uiPlugins).toHaveLength(0);
    });
  });
});
