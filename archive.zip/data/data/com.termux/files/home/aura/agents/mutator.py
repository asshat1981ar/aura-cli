import os

class MutatorAgent:
    def __init__(self):
        print("MutatorAgent initialized.")

    def apply_mutation(self, mutation_proposal: str):
        print(f"MutatorAgent: Attempting to apply mutation proposal:\n{mutation_proposal}")

        lines = mutation_proposal.strip().split('\n')
        command_line = lines[0].strip()

        if command_line.startswith("ADD_FILE"):
            try:
                # Expected format: ADD_FILE <filepath>\n<content>
                parts = command_line.split(' ', 1) # Split only on the first space to get filepath
                if len(parts) < 2:
                    print("MutatorAgent Error: ADD_FILE command missing filepath. Skipping.")
                    return
                file_path = parts[1].strip()
                content = "\n".join(lines[1:]) # Rest of the lines are content
                
                # Ensure directory exists
                os.makedirs(os.path.dirname(file_path), exist_ok=True)

                with open(file_path, "w") as f:
                    f.write(content)
                print(f"MutatorAgent: Successfully ADDED/OVERWROTE file: {file_path}")
            except Exception as e:
                print(f"MutatorAgent Error: Failed to ADD_FILE. {e}")
        elif command_line.startswith("REPLACE_IN_FILE"):
            try:
                # Expected format:
                # REPLACE_IN_FILE <filepath>
                # ---OLD_CONTENT_START---
                # <old_string_lines>
                # ---OLD_CONTENT_END---
                # ---NEW_CONTENT_START---
                # <new_string_lines>
                # ---NEW_CONTENT_END---

                filepath_line = lines[1].strip()
                if not filepath_line.startswith("---OLD_CONTENT_START---"): # Ensure filepath is present
                    file_path = filepath_line
                    content_start_index = 2
                else: # file_path was not provided on its own line, assume it was part of REPLACE_IN_FILE on line 0
                    file_path_parts = command_line.split(' ', 1)
                    if len(file_path_parts) < 2:
                        print("MutatorAgent Error: REPLACE_IN_FILE command missing filepath. Skipping.")
                        return
                    file_path = file_path_parts[1].strip()
                    content_start_index = 1


                old_content_start_marker = "---OLD_CONTENT_START---"
                old_content_end_marker = "---OLD_CONTENT_END---"
                new_content_start_marker = "---NEW_CONTENT_START---"
                new_content_end_marker = "---NEW_CONTENT_END---"

                # Find indices of markers
                try:
                    old_start_idx = lines.index(old_content_start_marker, content_start_index)
                    old_end_idx = lines.index(old_content_end_marker, old_start_idx + 1)
                    new_start_idx = lines.index(new_content_start_marker, old_end_idx + 1)
                    new_end_idx = lines.index(new_content_end_marker, new_start_idx + 1)
                except ValueError:
                    print("MutatorAgent Error: REPLACE_IN_FILE format error: Missing content markers. Skipping.")
                    return

                old_string_lines = lines[old_start_idx + 1 : old_end_idx]
                new_string_lines = lines[new_start_idx + 1 : new_end_idx]

                old_string = "\n".join(old_string_lines)
                new_string = "\n".join(new_string_lines)
                
                if not os.path.exists(file_path):
                    print(f"MutatorAgent Error: REPLACE_IN_FILE failed. File not found: {file_path}")
                    return

                with open(file_path, "r") as f:
                    file_content = f.read()

                if old_string not in file_content:
                    print(f"MutatorAgent Error: REPLACE_IN_FILE failed. Old string not found in file: {file_path}")
                    return

                modified_content = file_content.replace(old_string, new_string)

                with open(file_path, "w") as f:
                    f.write(modified_content)
                print(f"MutatorAgent: Successfully REPLACED content in file: {file_path}")

            except Exception as e:
                print(f"MutatorAgent Error: Failed to REPLACE_IN_FILE. {e}")
        else:
            print(f"MutatorAgent: Unknown mutation command: {command_line}. Skipping.")
        
        print("MutatorAgent: Mutation application attempt complete.")