// types/plugin/PluginType.ts
export enum PluginType {
  WorkflowNode = 'workflow_node',
  Integration = 'integration',
  UiExtension = 'ui_extension',
}
