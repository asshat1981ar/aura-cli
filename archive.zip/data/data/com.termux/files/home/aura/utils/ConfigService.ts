// utils/ConfigService.ts
import SecureStorage from './SecureStorage';
import { ApiService } from './ApiKeyManager';

const ACTIVE_AI_SERVICE_KEY = 'config_active_ai_service';
const DEFAULT_MODEL_KEY_PREFIX = 'config_default_model_';

class ConfigService {
  /**
   * Sets the globally active AI service.
   * @param service The ApiService to set as active.
   * @returns Promise<void>
   */
  static async setActiveAiService(service: ApiService): Promise<void> {
    await SecureStorage.setItem(ACTIVE_AI_SERVICE_KEY, service);
  }

  /**
   * Gets the globally active AI service. Defaults to OpenAI if not set.
   * @returns Promise<ApiService>
   */
  static async getActiveAiService(): Promise<ApiService> {
    const service = await SecureStorage.getItem(ACTIVE_AI_SERVICE_KEY);
    return (service as ApiService) || ApiService.OpenAI; // Default to OpenAI
  }

  /**
   * Sets the default model for a specific AI service.
   * @param service The ApiService.
   * @param modelName The name of the default model.
   * @returns Promise<void>
   */
  static async setDefaultModel(service: ApiService, modelName: string): Promise<void> {
    await SecureStorage.setItem(`${DEFAULT_MODEL_KEY_PREFIX}${service}`, modelName);
  }

  /**
   * Gets the default model for a specific AI service.
   * @param service The ApiService.
   * @returns Promise<string | null> The model name or null if not set.
   */
  static async getDefaultModel(service: ApiService): Promise<string | null> {
    return await SecureStorage.getItem(`${DEFAULT_MODEL_KEY_PREFIX}${service}`);
  }

  /**
   * Clears all AI-related configuration settings.
   * @returns Promise<void>
   */
  static async clearAiConfig(): Promise<void> {
    await SecureStorage.deleteItem(ACTIVE_AI_SERVICE_KEY);
    // This is problematic. SecureStorage doesn't allow enumeration of keys.
    // If we want to clear only AI-related default models, we need to explicitly track them
    // or clear everything if `SecureStorage.clearAll()` is used.
    // For now, let's assume specific deletion or clearAll is acceptable.
    // A more robust solution would track model keys in a non-secure way.
    console.warn("clearAiConfig only clears the active AI service. Default models need explicit deletion or a different tracking mechanism.");
  }
}

export default ConfigService;
