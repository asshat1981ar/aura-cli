#!/usr/bin/env python3
"""
AURA Parchment
--------------
Stability repair utility for known structural issues in AURA v2.

Fixes:
- Unterminated f-strings in vector_store.add(...)
- Stray `p    print(...)` syntax errors
- Ensures CLI indentation sanity
- Optional repo anchoring injection
- Syntax validation after patching

Backups are created as: <file>.bak
"""

import re
import shutil
import sys
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parent


# -------------------------------------------------
# Utilities
# -------------------------------------------------

def backup(path: Path):
    bak = path.with_suffix(path.suffix + ".bak")
    shutil.copy2(path, bak)
    print(f"[backup] {bak}")


def validate_syntax(path: Path):
    result = subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        capture_output=True,
        text=True
    )
    if result.returncode == 0:
        print(f"[syntax OK] {path.name}")
        return True
    else:
        print(f"[syntax ERROR] {path.name}")
        print(result.stderr)
        return False


# -------------------------------------------------
# Fixers
# -------------------------------------------------

def fix_unterminated_fstrings(text: str) -> str:
    """
    Fix common broken pattern:
    vector_store.add(f"SOLVED: {goal}
    {best_code[:300]}")
    """

    pattern = re.compile(
        r'vector_store\.add\(f"([^"]*?)\n([^"]*?)"\)',
        re.DOTALL
    )

    def replacer(match):
        part1 = match.group(1)
        part2 = match.group(2)
        fixed = f'vector_store.add(f"{part1}\\n{part2}")'
        print("[fix] Repaired multiline f-string in vector_store.add")
        return fixed

    return pattern.sub(replacer, text)


def fix_stray_print(text: str) -> str:
    """
    Fix stray leading 'p' before print(...)
    """
    fixed = re.sub(r'^\s*p\s+print\(', 'print(', text, flags=re.MULTILINE)
    if fixed != text:
        print("[fix] Removed stray 'p' before print")
    return fixed


def inject_repo_anchor(text: str) -> str:
    """
    Ensures script runs relative to its own directory.
    Only inject if not already present.
    """

    if "os.chdir(" in text:
        return text

    inject_block = (
        "\n# --- AURA repo anchor injection ---\n"
        "from pathlib import Path\n"
        "import os\n"
        "HERE = Path(__file__).resolve().parent\n"
        "os.chdir(HERE)\n"
        "# -----------------------------------\n\n"
    )

    # inject after imports
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("import") or line.startswith("from"):
            continue
        else:
            lines.insert(i, inject_block)
            print("[inject] Added repo anchor logic")
            break

    return "\n".join(lines)


# -------------------------------------------------
# Main patch routine
# -------------------------------------------------

def patch_file(path: Path, inject_anchor=False):
    if not path.exists():
        print(f"[skip] {path.name} not found")
        return

    original = path.read_text(encoding="utf-8")
    modified = original

    modified = fix_unterminated_fstrings(modified)
    modified = fix_stray_print(modified)

    if inject_anchor:
        modified = inject_repo_anchor(modified)

    if modified != original:
        backup(path)
        path.write_text(modified, encoding="utf-8")
        print(f"[patched] {path.name}")
        validate_syntax(path)
    else:
        print(f"[clean] {path.name} — no changes needed")


def main():
    print("AURA Parchment — Stability Repair\n")

    conductor = ROOT / "conductor_v2.py"
    cli = ROOT / "aura_cli.py"

    patch_file(conductor, inject_anchor=False)
    patch_file(cli, inject_anchor=True)

    print("\nDone.\n")


if __name__ == "__main__":
    main()
