// plugins/PluginRuntime.ts
import { IPlugin } from '../types/plugin/IPlugin';
import { IPluginContext } from '../types/plugin/IPluginContext';
import { IExecutionContext } from '../types/workflow/IExecutionContext';
import { IWorkflowNodePlugin } from '../types/plugin/IWorkflowNodePlugin';
import PluginRegistry from './PluginRegistry';
import Logger from '../utils/Logger';
import WorkflowNodeDataValidator from '../plugins/validation/WorkflowNodeDataValidator'; // Import validator

// Define a standardized result structure for plugin execution
export interface PluginExecutionResult<T = any> {
  success: boolean;
  data?: T;
  error?: {
    message: string;
    details?: any;
  };
}

class PluginRuntime {
  private registry: PluginRegistry; // Reference to the PluginRegistry to get the shared context

  constructor(registry: PluginRegistry) {
    this.registry = registry;
  }

  /**
   * Executes the `onLoad` method of a plugin within a controlled environment.
   * @param plugin The plugin instance to load.
   * @returns A promise resolving to a PluginExecutionResult indicating success or failure.
   */
  async loadPlugin(plugin: IPlugin): Promise<PluginExecutionResult<void>> {
    try {
      // Pass the shared IPluginContext from the registry
      await plugin.onLoad(this.registry.pluginContext);
      Logger.info(`Plugin '${plugin.name}' (${plugin.id}) onLoad executed successfully.`);
      return { success: true };
    } catch (error: any) {
      Logger.error(`Error during onLoad for plugin '${plugin.id}':`, error);
      return { success: false, error: { message: `Plugin onLoad failed: ${error.message}`, details: error } };
    }
  }

  /**
   * Executes the `onUnload` method of a plugin within a controlled environment.
   * @param plugin The plugin instance to unload.
   * @returns A promise resolving to a PluginExecutionResult indicating success or failure.
   */
  async unloadPlugin(plugin: IPlugin): Promise<PluginExecutionResult<void>> {
    try {
      await plugin.onUnload(this.registry.pluginContext);
      Logger.info(`Plugin '${plugin.name}' (${plugin.id}) onUnload executed successfully.`);
      return { success: true };
    } catch (error: any) {
      Logger.error(`Error during onUnload for plugin '${plugin.id}':`, error);
      return { success: false, error: { message: `Plugin onUnload failed: ${error.message}`, details: error } };
    }
  }

  /**
   * Executes the `execute` method of a workflow node plugin within a controlled environment.
   * @param plugin The workflow node plugin instance.
   * @param data Input data for the node.
   * @param workflowId The ID of the workflow.
   * @param nodeId The ID of the node.
   * @returns A promise resolving to a PluginExecutionResult with the node's output data or error.
   */
  async executeWorkflowNode(
    plugin: IWorkflowNodePlugin,
    data: Record<string, any>,
    workflowId: string,
    nodeId: string
  ): Promise<PluginExecutionResult<any>> {
    const executionContext: IExecutionContext = {
      data,
      services: this.registry.pluginContext, // Access to core platform services
      workflowId,
      nodeId,
    };

    try {
      // 1. Validate input data
      WorkflowNodeDataValidator.validateInputData(data, plugin.inputs);

      // TODO: Implement more robust isolation (e.js. Node.js worker_threads, vm module)
      // TODO: Implement resource limits (CPU, memory, time)
      const output = await plugin.execute(executionContext);
      
      // 2. Validate output data
      WorkflowNodeDataValidator.validateOutputData(output, plugin.outputs);

      Logger.debug(`Workflow Node '${plugin.name}' (${plugin.id}) executed successfully.`, { workflowId, nodeId });
      return { success: true, data: output };
    } catch (error: any) {
      // Catch ZodErrors from validation or any other plugin execution errors
      Logger.error(`Error during execute for workflow node '${plugin.id}':`, error, { workflowId, nodeId });
      return { success: false, error: { message: `Workflow node execution failed: ${error.message}`, details: error } };
    }
  }

  // Add methods for other plugin types (e.g., UI extensions, integrations) if needed
}

export default PluginRuntime;
