import unittest
import os
import shutil
from pathlib import Path
from unittest.mock import MagicMock, patch, ANY # Import ANY
import subprocess # Import subprocess
import json # Import json

from git import InvalidGitRepositoryError, GitCommandError

from core.goal_queue import GoalQueue
from core.hybrid_loop import HybridClosedLoop
from core.goal_archive import GoalArchive
from memory.brain import Brain
from core.model_adapter import ModelAdapter
from core.git_tools import GitTools
from core.file_tools import replace_code # Need to make sure replace_code is used by model_adapter

class TestFullAURALoop(unittest.TestCase):

    def setUp(self):
        self.test_dir = Path("./temp_aura_repo")
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
        self.test_dir.mkdir()

        self.repo_path = self.test_dir / "my_test_repo"
        self.repo_path.mkdir(parents=True, exist_ok=True) # Ensure directory exists
        
        # Create a dummy file first
        self.dummy_file = self.repo_path / "dummy_file.py"
        self.dummy_file.write_text("print('hello world')")

        # Then initialize the repository using subprocess, explicitly setting cwd
        subprocess.run(["git", "init"], cwd=self.repo_path, check=True)
        subprocess.run(["git", "add", self.dummy_file.name], cwd=self.repo_path, check=True)
        subprocess.run(["git", "commit", "-m", "Initial commit"], cwd=self.repo_path, check=True)

        # Setup paths for test databases
        self.brain_db_path = self.test_dir / "brain.db"
        self.goal_queue_db_path = self.test_dir / "goal_queue.db"

        # Initialize real components, but mock model_adapter and git_tools
        self.model_adapter = ModelAdapter(vector_store=MagicMock()) # Mock vector_store if needed
        self.brain = Brain(db_path=self.brain_db_path)
        self.goal_queue = GoalQueue(db_path=self.goal_queue_db_path)
        self.goal_archive = GoalArchive() # GoalArchive is in-memory by default
        
        self.mock_git_tools = MagicMock(spec=GitTools) # Mock GitTools
        self.mock_git_tools.repo_path = str(self.repo_path) # Ensure mock has repo_path attribute

        # Mock the respond method of ModelAdapter
        self.mock_model_respond = MagicMock()
        self.model_adapter.respond = self.mock_model_respond

        self.hybrid_loop = HybridClosedLoop(self.model_adapter, self.brain, self.mock_git_tools)

    def tearDown(self):
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
        
        # Ensure DB connections are closed
        self.brain.db.close()
        self.goal_queue.db.close()

    @patch('core.model_adapter.replace_code', side_effect=replace_code) # Ensure replace_code is actually called
    def test_full_aura_loop_iteration(self, mock_replace_code):
        # Mock model response for the first iteration
        mock_response_iteration_1 = {
            "DEFINE": "Refactor dummy_file.py to use a function.",
            "PLAN": "Create a function 'greet' and move print statement into it. Update call.",
            "IMPLEMENT": {
                "file_path": str(self.dummy_file),
                "old_code": "print('hello world')",
                "new_code": "def greet():\\n    print('hello world')\\n\\ngreet()" # Use \n for newlines
            },
            "TEST": "Run dummy_file.py and check output.",
            "CRITIQUE": {
                "performance_score": 8,
                "stability_score": 9,
                "security_score": 8,
                "elegance_score": 7,
                "weaknesses": ["No docstrings for greet function."]
            },
            "IMPROVE": "Add a docstring to the greet function.",
            "VERSION": "feat: Refactor greet function in dummy_file.py",
            "SUMMARY": "Refactored dummy_file.py to use a greet function."
        }

        self.mock_model_respond.side_effect = [
            json.dumps(mock_response_iteration_1),
        ]

        goal = "Improve code elegance of dummy_file.py"
        self.goal_queue.add(goal)

        # Run only one iteration
        current_goal = self.goal_queue.next()
        print(f"--- Processing Goal: {current_goal} ---")
        
        loop_result = None
        try:
            loop_result_json_str = self.hybrid_loop.run(current_goal)
            loop_result = json.loads(loop_result_json_str)
        except Exception as e:
            self.fail(f"HybridLoop.run failed with exception: {e}")

        # Assertions
        self.assertIsNotNone(loop_result, "Loop result should not be None.")
        self.assertFalse(self.goal_queue.has_goals(), "Goal queue should be empty after one iteration (non-converged goal is not re-added yet).")
        
        # Verify dummy_file.py content after the first iteration
        final_file_content = self.dummy_file.read_text()
        expected_content = "def greet():\n    print('hello world')\n\ngreet()"
        self.assertEqual(final_file_content, expected_content, "dummy_file.py content should be updated after first iteration.")

        self.assertTrue(mock_replace_code.called, "replace_code should have been called.")
        calls = mock_replace_code.call_args_list
        self.assertEqual(len(calls), 1, "replace_code should be called once.")
        self.assertEqual(calls[0].args[0], str(self.dummy_file))
        self.assertEqual(calls[0].args[1], "print('hello world')")
        self.assertEqual(calls[0].args[2], expected_content)
        
        # Verify GitTools interactions
        self.mock_git_tools.stash.assert_called_once_with(message=ANY) # Called at start of run
        self.mock_git_tools.commit_all.assert_called_once_with(message=loop_result["VERSION"]) # Called if score improves

        # Verify brain recorded weaknesses
        weaknesses = self.brain.recall_weaknesses()
        self.assertTrue(any("No docstrings for greet function." in w for w in weaknesses), "Weakness about docstring should be in brain.")
