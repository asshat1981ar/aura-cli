from git import Repo
from git.exc import InvalidGitRepositoryError, GitCommandError
import os

# Custom Exception Classes for GitTools
class GitToolsError(Exception):
    """Base exception for GitTools operations."""
    pass

class GitRepoError(GitToolsError):
    """Exception raised when the Git repository is invalid or not found."""
    pass

class GitCommitError(GitToolsError):
    """Exception raised for errors during Git commit operations."""
    pass

class GitRollbackError(GitToolsError):
    """Exception raised for errors during Git rollback operations."""
    pass

class GitDiffError(GitToolsError):
    """Exception raised for errors during Git diff operations."""
    pass

class GitBranchError(GitToolsError):
    """Exception raised for errors during Git branch operations."""
    pass

class GitStashError(GitToolsError):
    """Exception raised for errors during Git stash operations."""
    pass

class GitStashPopError(GitToolsError):
    """Exception raised for errors during Git stash pop operations."""
    pass
from git import Repo, InvalidGitRepositoryError, NoSuchPathError

class GitRepoError(Exception):
    pass


class GitTools:
    def __init__(self, repo_path: str = None):
        try:
            if repo_path:
                self.repo = Repo(repo_path, search_parent_directories=True)
            else:
                # fallback to searching from current working dir
                self.repo = Repo(".", search_parent_directories=True)

            self.repo_root = self.repo.working_tree_dir

        except (InvalidGitRepositoryError, NoSuchPathError) as e:
            raise GitRepoError(
                f"Git repository not found. Start AURA inside a repo or pass repo_path. ({e})"
            )
