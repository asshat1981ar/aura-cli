import requests

try:
    print("Attempting to connect to Google.com...")
    response = requests.get("https://www.google.com", timeout=10)
    response.raise_for_status()
    print(f"Successfully connected to Google.com! Status Code: {response.status_code}")
    print("First 100 characters of response:")
    print(response.text[:100])
except requests.exceptions.RequestException as e:
    print(f"Request to Google.com failed: {e}")
except Exception as e:
    print(f"An unexpected error occurred: {e}")
