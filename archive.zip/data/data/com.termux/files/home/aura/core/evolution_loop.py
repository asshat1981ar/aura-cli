import re # Import re for regex parsing

class EvolutionLoop:

    def __init__(self, planner, coder, critic, brain, vector_store, git_tools, mutator):
        self.planner = planner
        self.coder = coder
        self.critic = critic
        self.brain = brain
        self.vector = vector_store
        self.git = git_tools
        self.mutator = mutator

    def run(self, goal):
        # Gather system state for PlannerAgent
        memory_snapshot = "\n".join(self.brain.recall_all())
        similar_past_problems = "\n".join(self.vector.search(goal))
        known_weaknesses = "\n".join(self.brain.recall_weaknesses())

        # 1. Hypothesize
        hypothesis = self.planner.plan(
            goal=f"Analyze this goal: {goal}\nIdentify:\n- Required capabilities\n- Missing architecture\n- Possible improvements to AURA itself",
            memory_snapshot=memory_snapshot,
            similar_past_problems=similar_past_problems,
            known_weaknesses=known_weaknesses
        )

        # 2. Decompose
        tasks = self.planner.plan(
            goal=f"Break this into atomic executable tasks:\n{hypothesis}",
            memory_snapshot=memory_snapshot,
            similar_past_problems=similar_past_problems,
            known_weaknesses=known_weaknesses
        )

        # 3. Execute
        implementation = self.coder.implement(tasks)

        # 4. Critique
        evaluation = self.critic.critique_code(
            task=goal,
            code=implementation,
            requirements="Evaluate the implementation against the goal and provide a score based on correctness, efficiency, and adherence to the task."
        )

        # Detect weaknesses from evaluation using Brain's method
        self.brain.analyze_critique_for_weaknesses(evaluation)

        # 5. Mutate (Self-Improvement)
        mutation = self.planner.plan(
            goal=f"Based on this critique:\n{evaluation}\n\nPropose modifications to:\n- Agents\n- Memory\n- Model routing\n- Tooling",
            memory_snapshot=memory_snapshot,
            similar_past_problems=similar_past_problems,
            known_weaknesses=known_weaknesses
        )

        # 6. Integrate mutation
        raw_validation_result = self.critic.validate_mutation(mutation)
        
        decision = "REJECTED"
        confidence_score = 0.0
        impact_assessment = "N/A"
        reasoning = "Could not parse validation response."

        # Attempt to parse the structured response
        decision_match = re.search(r"DECISION: (APPROVED|REJECTED)", raw_validation_result)
        if decision_match:
            decision = decision_match.group(1)
        
        confidence_match = re.search(r"CONFIDENCE_SCORE: ([\d.]+)", raw_validation_result)
        if confidence_match:
            confidence_score = float(confidence_match.group(1))

        impact_match = re.search(r"IMPACT_ASSESSMENT: (.*)", raw_validation_result)
        if impact_match:
            impact_assessment = impact_match.group(1).strip()
            
        reasoning_match = re.search(r"REASONING: (.*)", raw_validation_result, re.DOTALL)
        if reasoning_match:
            reasoning = reasoning_match.group(1).strip()

        print(f"\n--- Mutation Validation Result ---\nDECISION: {decision}\nCONFIDENCE: {confidence_score}\nIMPACT: {impact_assessment}\nREASONING: {reasoning}\n----------------------------------\n")

        # Programmatic decision to apply mutation
        if decision == "APPROVED" and confidence_score >= 0.7: # Example threshold
            self.mutator.apply_mutation(mutation)
            print("Mutation APPROVED and APPLIED based on programmatic decision.")
        else:
            print(f"Mutation REJECTED based on programmatic decision (Decision: {decision}, Confidence: {confidence_score}). Skipping application.")

        self.brain.remember(goal)
        self.brain.remember(hypothesis)
        self.brain.remember(evaluation)
        self.brain.remember(mutation)

        self.vector.add(goal)
        self.vector.add(mutation)

        # 7. Commit evolution
        self.git.commit_all(f"AURA evolutionary update: {goal}")

        return {
            "hypothesis": hypothesis,
            "tasks": tasks,
            "implementation": implementation,
            "evaluation": evaluation,
            "mutation": mutation
        }
