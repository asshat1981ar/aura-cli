// types/workflow/IExecutionContext.ts
import { IPluginContext } from '../plugin/IPluginContext';

export interface IExecutionContext {
  data: Record<string, any>; // Input data for the current node
  services: IPluginContext; // Access to core platform services
  workflowId: string; // ID of the currently executing workflow
  nodeId: string; // ID of the currently executing node
  // Add other contextual information as needed (e.g., logger, CancellationToken)
}
