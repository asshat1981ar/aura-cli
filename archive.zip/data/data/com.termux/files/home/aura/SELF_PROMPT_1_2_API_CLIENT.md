# Self-Prompt: 1.2 Secure API Client Implementation

## THOUGHT
The goal of this phase is to build upon the secure storage and authentication mechanisms established in Phase 1.1 to create a unified, multi-service API client. This client will abstract away the complexities of authenticating with various AI providers (OpenAI, Anthropic, Google, DeepL) and securely injecting API keys or OAuth tokens into requests. The client should be robust, easy to use for other parts of Project OP, and adhere to best practices for API communication.

## QUESTIONS
1.  What is the preferred approach for structuring the multi-service client: a single class with methods for each service, or a factory pattern that returns service-specific client instances?
2.  How will different authentication methods (API Key vs. OAuth) be handled transparently by the client, leveraging `ApiKeyManager` and `AuthService`?
3.  What common functionalities (e.g., retry logic, rate limiting, error handling) should be built into the base client or its interceptors?
4.  How will the client adapt to different API specifications and data formats across services (e.g., request/response payloads for chat completions)?
5.  What are the key endpoints or methods that the client should expose for each service (e.g., `chatCompletion`, `textGeneration`, `embedding`)?
6.  How will the client handle dynamic selection of the active AI model or service based on configuration or user preference?

## PLAN
1.  **Refine MultiServiceApiClient**:
    *   Review and enhance `utils/MultiServiceApiClient.ts` to explicitly define methods for common AI tasks (e.g., `chatCompletion`, `generateEmbedding`) rather than just generic `get`/`post`.
    *   Ensure robust integration with `ApiKeyManager` for API key injection.
    *   Consider how `AuthService` (for OAuth) can be integrated if a service requires it, potentially by allowing a `apiClient` instance (with OAuth interceptors) to be passed for specific service configurations.
2.  **Implement Service-Specific Adapters/Clients**:
    *   Create lightweight adapter classes for each `ApiService` (OpenAI, Anthropic, Google, DeepL) that use the `MultiServiceApiClient` base or a configured `axios` instance.
    *   These adapters will translate generic requests (e.g., `chatCompletion`) into service-specific API calls and handle their unique request/response formats.
3.  **Centralize Configuration**:
    *   Establish a configuration mechanism for service endpoints, model names, and any service-specific parameters.
    *   Ensure this configuration can be dynamically updated.
4.  **Error Handling and Logging**:
    *   Implement centralized error handling for API calls, providing consistent error formats.
    *   Integrate logging for API requests and responses (potentially sensitive, so careful logging practices are needed).
5.  **Dynamic Model/Service Selection**:
    *   Design a mechanism (e.g., a configuration setting or a simple routing logic) that allows other parts of Project OP to select which AI service/model to use for a given task.

## VERIFICATION
1.  **Unit Tests for `MultiServiceApiClient` Enhancements**:
    *   Verify new `chatCompletion`, `generateEmbedding` methods work correctly with mocked service adapters.
    *   Test correct API key injection for each `ApiService`.
    *   Test handling of scenarios where API keys are missing.
2.  **Integration Tests (Mocked External Services)**:
    *   Create mock responses for OpenAI, Anthropic, Google, and DeepL API endpoints.
    *   Test that the client correctly formats requests and parses responses for each service.
    *   Verify OAuth token refresh logic (via `AuthService`) is triggered correctly by HTTP 401s if applicable.
3.  **Security Review**:
    *   Ensure no API keys or tokens are exposed in logs or unencrypted storage.
    *   Confirm secure transmission (HTTPS).
    *   Verify token expiration and refresh handling logic.
4.  **Code Review**:
    *   Check for adherence to DRY principles and modularity.
    *   Ensure clear separation of concerns between authentication, storage, and API calling.
    *   Confirm consistent naming conventions.
