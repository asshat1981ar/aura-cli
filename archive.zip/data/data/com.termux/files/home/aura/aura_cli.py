import re
import os
import sys
import json
from pathlib import Path

# --- AURA repo anchor injection ---
HERE = Path(__file__).resolve().parent
os.chdir(HERE)
# -----------------------------------

# Ensure project root is on path
sys.path.insert(0, os.path.abspath('.'))

from core.goal_queue import GoalQueue
from core.hybrid_loop import HybridClosedLoop
from core.goal_archive import GoalArchive
from memory.brain import Brain
from core.model_adapter import ModelAdapter
from core.git_tools import GitTools, GitToolsError


def main():
    goal_queue = GoalQueue()
    goal_archive = GoalArchive()

    model_adapter = ModelAdapter()
    brain_instance = Brain()
    git_tools_instance = GitTools()

    loop = HybridClosedLoop(model_adapter, brain_instance, git_tools_instance)

    print("AURA Sequential Hybrid Loop Online")

    while True:
        command = input("\nCommand (add/run/exit/status) > ").strip()

        if command == "exit":
            break

        if command.startswith("add "):
            goal = command[4:].strip()
            if goal:
                goal_queue.add(goal)
                print(f"Goal added: '{goal}'")
            else:
                print("Please provide a goal after 'add'.")

        elif command == "run":
            if not goal_queue.has_goals():
                print("No goals in the queue. Add some goals first.")
                continue

            while goal_queue.has_goals():
                current_goal = goal_queue.next()
                print(f"\n--- Processing Goal: {current_goal} ---\n")

                converged = False
                loop.previous_score = 0
                loop.regression_count = 0
                loop.stable_convergence_count = 0

                cycle_count = 0

                while not converged:
                    cycle_count += 1
                    print(f"\n--- Cycle {cycle_count} for Goal: {current_goal} ---")

                    loop_result_json_str = loop.run(current_goal)
                    print(loop_result_json_str)

                    try:
                        result_json = json.loads(loop_result_json_str)
                    except json.JSONDecodeError as e:
                        print(f"Invalid JSON from HybridLoop: {e}")
                        result_json = {"FINAL_STATUS": "Error: HybridLoop returned invalid JSON."}

                    if result_json.get("DEFINE") == "Error: Model response failed." or \
                       result_json.get("FINAL_STATUS", "").startswith("Terminated"):
                        print("Model failure or termination detected. Continuing cycle.")
                        continue

                    implement_data = result_json.get("IMPLEMENT")

                    if implement_data and isinstance(implement_data, dict):
                        file_path = implement_data.get("file_path")
                        old_code = implement_data.get("old_code")
                        new_code = implement_data.get("new_code")

                        if all([file_path, old_code, new_code]):
                            print(f"SIMULATING: replace('{file_path}', old_code, new_code)")
                        else:
                            print("Incomplete IMPLEMENT data.")

                    if result_json.get("FINAL_STATUS", "").startswith("Optimization converged"):
                        converged = True

                        final_score_str = result_json.get("CRITIQUE", {}).get("weighted_score", 0)

                        try:
                            final_score = float(final_score_str)
                        except (ValueError, TypeError):
                            final_score = 0.0

                        goal_archive.record(current_goal, final_score)

                        print(f"\nGoal completed: {current_goal} (Score: {final_score})\n")
                        print(result_json.get("SUMMARY", ""))

                if not converged:
                    print(f"Goal '{current_goal}' terminated without convergence.")

            print("\nAll goals processed.")

        elif command == "status":
            print("\n--- AURA Status ---")
            print(f"Goals in queue: {len(goal_queue.queue)}")

            for i, goal in enumerate(goal_queue.queue):
                print(f"  {i+1}. {goal}")

            print(f"Completed goals: {len(goal_archive.completed)}")

            for goal, score in goal_archive.completed:
                print(f"  - '{goal}' (Score: {score:.2f})")

            print("-------------------\n")

        else:
            print("Invalid command. Use 'add <goal>', 'run', 'status', or 'exit'.")


if __name__ == "__main__":
    main()
