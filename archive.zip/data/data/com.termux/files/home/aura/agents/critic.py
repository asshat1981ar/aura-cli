from typing import List

class CriticAgent:
    def __init__(self, brain, model):
        self.brain = brain
        self.model = model

    def critique_plan(self, task: str, plan: List[str]) -> str:
        prompt = f"""
You are an autonomous critic agent. Your task is to evaluate a given plan against a high-level task.
Provide constructive feedback to improve the plan.

High-level Task:
{task}

Plan to critique:
{plan}

Previous memory:
{self.brain.recall_all()}

Evaluate the plan for completeness, clarity, feasibility, and alignment with the high-level task.
Suggest improvements or identify missing steps.
"""
        response = self.model.respond(prompt)
        self.brain.remember(f"Critiqued plan for task: {task}. Feedback: {response}")
        return response

    def critique_code(self, task: str, code: str, requirements: str = "") -> str:
        prompt = f"""
You are an autonomous critic agent. Your task is to evaluate provided code against a given task and requirements.
Provide constructive feedback to improve the code.

Task:
{task}

Code to critique:
```python
{code}
```

Requirements:
{requirements if requirements else "No specific requirements provided beyond the task."}

Previous memory:
{self.brain.recall_all()}

Evaluate the code for correctness, efficiency, readability, maintainability, and adherence to requirements.
Suggest improvements or identify potential issues.
"""
        response = self.model.respond(prompt)
        self.brain.remember(f"Critiqued code for task: {task}. Feedback: {response}")
        return response

    def validate_mutation(self, mutation_proposal: str) -> str:
        prompt = f"""
        You are a highly analytical critic agent responsible for validating proposed system mutations.
        Your goal is to assess the potential impact, safety, and effectiveness of a mutation.

        Mutation Proposal to Validate:
        ---
        {mutation_proposal}
        ---

        Based on your analysis, provide a structured response in the following format:
        
        DECISION: [APPROVED|REJECTED]
        CONFIDENCE_SCORE: [0.0-1.0] (Your certainty about the decision)
        IMPACT_ASSESSMENT: (Briefly describe the anticipated positive and negative impacts, e.g., "High confidence in fixing X, but might introduce risk Y.")
        REASONING: (Detailed explanation for your decision, including any potential risks or benefits.)

        Ensure your response strictly adheres to this format.
        """
        validation_response = self.model.respond(prompt)
        self.brain.remember(f"Validated mutation: {mutation_proposal}. Decision: {validation_response}")
        return validation_response