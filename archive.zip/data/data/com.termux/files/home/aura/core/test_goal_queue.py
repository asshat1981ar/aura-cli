import unittest
import os
from collections import deque
from pathlib import Path
from core.goal_queue import GoalQueue

class TestGoalQueue(unittest.TestCase):

    def setUp(self):
        self.test_db_path = Path(__file__).parent / "test_goal_queue.db"
        if self.test_db_path.exists():
            os.remove(self.test_db_path)
        self.goal_queue = GoalQueue(db_path=self.test_db_path)

    def tearDown(self):
        if self.test_db_path.exists():
            os.remove(self.test_db_path)

    def test_init_db_and_load_empty(self):
        self.assertFalse(self.goal_queue.has_goals())
        self.assertEqual(len(self.goal_queue.queue), 0)

    def test_add_goal(self):
        self.goal_queue.add("Implement feature A")
        self.assertTrue(self.goal_queue.has_goals())
        self.assertEqual(len(self.goal_queue.queue), 1)
        self.assertEqual(self.goal_queue.queue[0], "Implement feature A")

        # Verify in DB
        cursor = self.goal_queue.db.execute("SELECT goal_description, order_index FROM goals")
        rows = cursor.fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0][0], "Implement feature A")
        self.assertEqual(rows[0][1], 0)

    def test_next_goal(self):
        self.goal_queue.add("Implement feature A")
        self.goal_queue.add("Fix bug B")
        
        next_goal = self.goal_queue.next()
        self.assertEqual(next_goal, "Implement feature A")
        self.assertEqual(len(self.goal_queue.queue), 1)
        self.assertEqual(self.goal_queue.queue[0], "Fix bug B")

        # Verify in DB
        cursor = self.goal_queue.db.execute("SELECT goal_description, order_index FROM goals ORDER BY order_index ASC")
        rows = cursor.fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0][0], "Fix bug B")
        self.assertEqual(rows[0][1], 0) # Should be re-indexed

    def test_next_with_empty_queue(self):
        self.assertIsNone(self.goal_queue.next())
        self.assertFalse(self.goal_queue.has_goals())

    def test_persistence(self):
        self.goal_queue.add("Goal 1 for persistence")
        self.goal_queue.add("Goal 2 for persistence")
        
        # Simulate closing and reopening the queue
        self.goal_queue.db.close()
        new_queue = GoalQueue(db_path=self.test_db_path)

        self.assertTrue(new_queue.has_goals())
        self.assertEqual(len(new_queue.queue), 2)
        self.assertEqual(new_queue.queue[0], "Goal 1 for persistence")
        self.assertEqual(new_queue.queue[1], "Goal 2 for persistence")

        next_goal = new_queue.next()
        self.assertEqual(next_goal, "Goal 1 for persistence")

        new_queue.db.close()
        final_queue = GoalQueue(db_path=self.test_db_path)
        self.assertEqual(len(final_queue.queue), 1)
        self.assertEqual(final_queue.queue[0], "Goal 2 for persistence")

if __name__ == '__main__':
    unittest.main()
