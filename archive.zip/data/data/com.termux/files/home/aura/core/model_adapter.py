import os
import subprocess
import requests
import json
import re
import socket
import time
from pathlib import Path
import numpy as np

# Removed dangerous global IPv4-only monkeypatch for socket.getaddrinfo.
# This monkeypatch forced all network connections to use IPv4, potentially
# causing connectivity issues and hiding underlying network misconfigurations.
# The system should now correctly handle both IPv4 and IPv6 as determined
# by the operating system and network stack.

class ModelAdapter:

    def __init__(self):
        self.openrouter_key = os.getenv("OPENROUTER_API_KEY")
        self.openai_api_key = os.getenv("OPENAI_API_KEY") # Initialize OpenAI API key
        self.gemini_cli_path = "/data/data/com.termux/files/usr/bin/gemini" # Explicit path to gemini CLI

        # Validate gemini CLI path
        if not Path(self.gemini_cli_path).is_file():
            print(f"Warning: Gemini CLI executable not found at {self.gemini_cli_path}.")
            self.gemini_cli_path = None
        elif not os.access(self.gemini_cli_path, os.X_OK):
            print(f"Warning: Gemini CLI executable at {self.gemini_cli_path} is not executable.")
            self.gemini_cli_path = None

        # Define an explicit allowlist for tools
        self.ALLOWED_TOOLS = {"search", "read_file", "list_directory", "glob"}


    def _execute_tool(self, tool_name: str, args: dict) -> str:
        # This simulates calling an MCP tool via the SDK.
        # In a real scenario, you'd likely have a more robust way to interact with MCP servers.
        try:
            # Convert args dict to a JSON string for the SDK
            args_str = json.dumps(args)
            
            print(f"Executing tool: {tool_name} with args: {args_str}") # Debug print

            # Example: npx @modelcontextprotocol/sdk search "exa" '{"query": "latest news"}'
            command = ["npx", "@modelcontextprotocol/sdk", "call", tool_name, args_str]
            
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                check=True, # Raise an exception for non-zero exit codes
                timeout=60 # Timeout for tool execution
            )
            return result.stdout.strip()
        except subprocess.CalledProcessError as e:
            return f"Tool execution failed for {tool_name}: {e.stderr}"
        except json.JSONDecodeError:
            return f"Tool execution failed: Invalid JSON arguments for {tool_name}."
        except Exception as e:
            return f"Tool execution failed unexpectedly for {tool_name}: {str(e)}"

    def _make_request_with_retries(self, method, url, headers, json_payload, retries=3, backoff_factor=0.5):
        for attempt in range(retries):
            try:
                response = requests.request(method, url, headers=headers, json=json_payload, timeout=60) # Increased timeout to 60 seconds
                response.raise_for_status()
                return response
            except requests.exceptions.RequestException as e:
                if attempt < retries - 1:
                    sleep_time = backoff_factor * (2 ** attempt)
                    print(f"Request failed (attempt {attempt + 1}/{retries}): {e}. Retrying in {sleep_time:.2f} seconds...")
                    time.sleep(sleep_time)
                else:
                    raise # Re-raise exception if all retries fail
        return None # Should not be reached

    # -------- GEMINI CLI --------
    def call_gemini(self, prompt: str) -> str:
        if not self.gemini_cli_path:
            raise ValueError("Gemini CLI executable path not configured or found.")
        
        retries = 3
        backoff_factor = 0.5
        for attempt in range(retries):
            try:
                result = subprocess.run(
                    [self.gemini_cli_path, "chat", "--message", prompt], # Use explicit path
                    capture_output=True,
                    text=True,
                    check=True, # Raise CalledProcessError for non-zero exit codes
                    timeout=60 # Increased timeout for Gemini CLI
                )
                return result.stdout.strip()
            except subprocess.CalledProcessError as e:
                if "rate limit" in e.stderr.lower() or "quota" in e.stderr.lower():
                    if attempt < retries - 1:
                        sleep_time = backoff_factor * (2 ** attempt)
                        print(f"Gemini CLI call failed (attempt {attempt + 1}/{retries}) due to rate limit/quota: {e.stderr.strip()}. Retrying in {sleep_time:.2f} seconds...")
                        time.sleep(sleep_time)
                    else:
                        raise # Re-raise if all retries fail
                else:
                    raise # Re-raise for other errors immediately
            except Exception as e:
                raise RuntimeError(f"Gemini CLI call failed unexpectedly: {e}")
        return "" # Should not be reached


    # -------- OPENROUTER --------
    def call_openrouter(self, prompt: str) -> str:
        if not self.openrouter_key:
            raise ValueError("OPENROUTER_API_KEY not set for OpenRouter call.")
        url = "https://api.openrouter.ai/v1/chat/completions"

        headers = {
            "Authorization": f"Bearer {self.openrouter_key}",
            "Content-Type": "application/json"
        }

        payload = {
            "model": "openrouter/auto",
            "messages": [{"role": "user", "content": prompt}]
        }

        response = self._make_request_with_retries("POST", url, headers, payload)
        data = response.json()
        return data["choices"][0]["message"]["content"]

    # -------- OPENAI API --------
    def call_openai(self, prompt: str) -> str:
        if not self.openai_api_key:
            raise ValueError("OPENAI_API_KEY not set for OpenAI call.")
        url = "https://api.openai.com/v1/chat/completions"

        headers = {
            "Authorization": f"Bearer {self.openai_api_key}",
            "Content-Type": "application/json"
        }

        payload = {
            "model": "gpt-4o-mini",  # Using a cost-effective, capable model
            "messages": [{"role": "user", "content": prompt}]
        }

        response = self._make_request_with_retries("POST", url, headers, payload)
        data = response.json()
        return data["choices"][0]["message"]["content"]

    # -------- LOCAL FALLBACK --------
    def call_local(self, prompt: str) -> str:
        local_model_command = os.getenv("AURA_LOCAL_MODEL_COMMAND")
        if local_model_command:
            try:
                # Assuming the local model command expects the prompt as an argument
                # and outputs the response to stdout.
                command_parts = local_model_command.split()
                command_parts.append(prompt)
                
                result = subprocess.run(
                    command_parts,
                    capture_output=True,
                    text=True,
                    check=True,
                    timeout=120 # Increased timeout for local models
                )
                return result.stdout.strip()
            except FileNotFoundError:
                return "Error: Local model command not found. Please ensure it's in your PATH or specify full path."
            except subprocess.CalledProcessError as e:
                return f"Error: Local model command failed with exit code {e.returncode}. Stderr: {e.stderr.strip()}"
            except Exception as e:
                return f"Error: An unexpected error occurred while calling local model: {e}"
        else:
            return "Local model not configured. Set the AURA_LOCAL_MODEL_COMMAND environment variable " \
                   "to specify a command for local inference (e.g., 'ollama run llama2')."

    # -------- HYBRID ROUTING --------
    def respond(self, prompt: str):
        model_response = None
        
        # Try OpenAI first
        try:
            model_response = self.call_openai(prompt)
        except Exception as e:
            print(f"OpenAI call failed: {e}. Trying Gemini CLI...")
            # Fallback to Gemini CLI
            try:
                model_response = self.call_gemini(prompt)
            except Exception as e:
                print(f"Gemini CLI call failed: {e}. Trying OpenRouter...")
                # Fallback to OpenRouter (still problematic, but included for completeness)
                try:
                    model_response = self.call_openrouter(prompt)
                except Exception as e:
                    print(f"OpenRouter call failed: {e}. Falling back to local model...")
                    # Final fallback
                    model_response = self.call_local(prompt)

                    # Final fallback
                    model_response = self.call_local(prompt)

        if model_response is None:
            return "Error: No model successfully responded."
        
        try:
            parsed_response = json.loads(model_response)
            if isinstance(parsed_response, dict) and "tool_code" in parsed_response:
                tool_call_data = parsed_response["tool_code"]
                tool_name = tool_call_data.get("name")
                args = tool_call_data.get("args", {})

                if not isinstance(tool_name, str) or not isinstance(args, dict):
                    return "Model attempted tool call with invalid structure (name or args missing/wrong type)."

                if tool_name not in self.ALLOWED_TOOLS:
                    return f"Error: Tool '{tool_name}' is not allowed by the system configuration."

                tool_output = self._execute_tool(tool_name, args)
                return f"Tool Output: {tool_output}"
            else:
                # If it's valid JSON but not a tool_code, treat it as a direct model response.
                # The model might return structured data that is not a tool call.
                return model_response # Return original model response as it is not a tool call
        except json.JSONDecodeError:
            # Not a JSON response, treat as normal text response and return it directly.
            pass

        return model_response

    def get_embedding(self, text: str) -> list[float]:
        if not self.openai_api_key:
            raise ValueError("OPENAI_API_KEY not set for OpenAI embedding call. Please set it to use VectorStore.")

        url = "https://api.openai.com/v1/embeddings"
        headers = {
            "Authorization": f"Bearer {self.openai_api_key}",
            "Content-Type": "application/json"
        }
        payload = {
            "input": text,
            "model": "text-embedding-ada-002"  # A common and cost-effective embedding model
        }

        response = self._make_request_with_retries("POST", url, headers, payload)
        data = response.json()
        return np.array(data["data"][0]["embedding"], dtype=np.float32)