// __tests__/utils/ApiKeyManager.test.ts
import ApiKeyManager, { ApiService } from '../../utils/ApiKeyManager';
import SecureStorage from '../../utils/SecureStorage';

jest.mock('../../utils/SecureStorage', () => ({
  setItem: jest.fn(),
  getItem: jest.fn(),
  deleteItem: jest.fn(),
  hasItem: jest.fn(),
  clearAll: jest.fn(),
}));

describe('ApiKeyManager', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should store an API key for a service', async () => {
    await ApiKeyManager.setApiKey(ApiService.OpenAI, 'sk-openai-test');
    expect(SecureStorage.setItem).toHaveBeenCalledWith('api_key_openai', 'sk-openai-test');
  });

  it('should retrieve an API key for a service', async () => {
    (SecureStorage.getItem as jest.Mock).mockResolvedValueOnce('sk-openai-retrieved');
    const apiKey = await ApiKeyManager.getApiKey(ApiService.OpenAI);
    expect(SecureStorage.getItem).toHaveBeenCalledWith('api_key_openai');
    expect(apiKey).toBe('sk-openai-retrieved');
  });

  it('should remove an API key for a service', async () => {
    await ApiKeyManager.removeApiKey(ApiService.OpenAI);
    expect(SecureStorage.deleteItem).toHaveBeenCalledWith('api_key_openai');
  });

  it('should check if an API key exists for a service', async () => {
    (SecureStorage.hasItem as jest.Mock).mockResolvedValueOnce(true);
    const exists = await ApiKeyManager.hasApiKey(ApiService.OpenAI);
    expect(SecureStorage.hasItem).toHaveBeenCalledWith('api_key_openai');
    expect(exists).toBe(true);

    (SecureStorage.hasItem as jest.Mock).mockResolvedValueOnce(false);
    const notExists = await ApiKeyManager.hasApiKey(ApiService.Anthropic);
    expect(SecureStorage.hasItem).toHaveBeenCalledWith('api_key_anthropic');
    expect(notExists).toBe(false);
  });

  it('should throw an error if service is empty for setApiKey', async () => {
    await expect(ApiKeyManager.setApiKey('' as ApiService, 'key')).rejects.toThrow("Service and API key cannot be empty.");
  });

  it('should throw an error if apiKey is empty for setApiKey', async () => {
    await expect(ApiKeyManager.setApiKey(ApiService.OpenAI, '')).rejects.toThrow("Service and API key cannot be empty.");
  });

  it('should throw an error if service is empty for getApiKey', async () => {
    await expect(ApiKeyManager.getApiKey('' as ApiService)).rejects.toThrow("Service cannot be empty.");
  });

  it('should throw an error if service is empty for removeApiKey', async () => {
    await expect(ApiKeyManager.removeApiKey('' as ApiService)).rejects.toThrow("Service cannot be empty.");
  });

  it('should throw an error if service is empty for hasApiKey', async () => {
    await expect(ApiKeyManager.hasApiKey('' as ApiService)).rejects.toThrow("Service cannot be empty.");
  });

  it('should clear all API keys by calling SecureStorage.clearAll and warn', async () => {
    const consoleWarnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});
    await ApiKeyManager.clearAllApiKeys();
    expect(SecureStorage.clearAll).toHaveBeenCalledTimes(1);
    expect(consoleWarnSpy).toHaveBeenCalledWith(
      "clearAllApiKeys will clear ALL items in SecureStorage due to underlying platform limitations."
    );
    consoleWarnSpy.mockRestore();
  });
});
