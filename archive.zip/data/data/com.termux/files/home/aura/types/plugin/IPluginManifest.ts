// types/plugin/IPluginManifest.ts
import { PluginType } from './PluginType';

export interface IPluginManifest {
  id: string;
  name: string;
  version: string;
  author: string;
  description: string;
  type: PluginType;
  entryPoint: string; // Path to the main plugin file relative to the plugin's root directory

  // Optional dependencies on other plugins (semver range)
  dependencies?: {
    [pluginId: string]: string; // e.g., { "another-plugin-id": "^1.0.0" }
  };

  // Optional configuration specific to the plugin type (e.g., for UI extensions)
  config?: Record<string, any>;

  // Optional i18n support
  locales?: string[]; // e.g., ['en', 'es']
}
