#!/usr/bin/env python3
"""
fstring_doctor.py
- Scans .py files for likely unterminated f-strings and brace mismatches.
- Optional: --fix will attempt a conservative fix for the common pattern:
    line contains:  something(f"...{expr}
    and the line ends without closing quote/paren -> appends '")' at end of line
  (It ONLY does this when it can be fairly confident.)

Usage:
  python fstring_doctor.py /path/to/project
  python fstring_doctor.py /path/to/project --fix
  python fstring_doctor.py /path/to/file.py --fix
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path
from typing import Iterable, Tuple


FSTRING_START_RE = re.compile(
    r"""(?x)
    (?:^|[^A-Za-z0-9_])      # not in an identifier
    (?:[rubfRUBF]{0,3})      # string prefixes in any order-ish
    (f|F)                    # must include f/F
    (['"])                   # quote
    """
)

# Heuristic: line has f" or f' and ends without matching quote.
# We'll ignore triple-quoted starts (""" or ''') because those can be multiline.
TRIPLE_START_RE = re.compile(r"""(?x)(f|F)(\"\"\"|\'\'\')""")


def iter_py_files(root: Path) -> Iterable[Path]:
    if root.is_file() and root.suffix == ".py":
        yield root
        return
    for p in root.rglob("*.py"):
        # skip common junk dirs
        if any(part in {".git", "__pycache__", ".venv", "venv", "node_modules"} for part in p.parts):
            continue
        yield p


def likely_unterminated_fstring(line: str) -> bool:
    if TRIPLE_START_RE.search(line):
        return False
    m = re.search(r"""(?i)\bf(['"])""", line)  # f" or f'
    if not m:
        return False
    quote = m.group(1)
    # Count quotes on the line. If odd, it's probably unterminated.
    # This is a heuristic; escaped quotes reduce accuracy, but catches the common case.
    cnt = line.count(quote)
    return cnt % 2 == 1


def brace_balance_in_fstring_fragment(s: str) -> int:
    """
    Very rough brace balance counter for { } ignoring escaped {{ }}.
    Returns net open braces.
    """
    # remove escaped double braces first
    s = s.replace("{{", "").replace("}}", "")
    return s.count("{") - s.count("}")


def conservative_fix(line: str) -> Tuple[str, bool]:
    """
    Attempt to fix a very specific common failure:
      vector_store.add(f"SOLVED: {goal}
    by appending '")' at end of line IF:
      - it looks like it started f" or f'
      - line ends without closing quote
      - line seems to be inside a call (contains '(' after the start)
      - net braces are balanced (or at least not wildly negative)
    """
    if not likely_unterminated_fstring(line):
        return line, False

    # Find first occurrence of f" or f'
    m = re.search(r"""(?i)\bf(['"])""", line)
    if not m:
        return line, False
    quote = m.group(1)

    # If the line already ends with backslash continuation, skip
    if line.rstrip().endswith("\\"):
        return line, False

    # If there's no "(" before the f-string start, we avoid guessing
    start_idx = m.start()
    if "(" not in line[:start_idx + 1] and "(" not in line[:]:
        return line, False

    # Basic brace sanity in the remainder of the line (from f-string start)
    frag = line[start_idx:]
    bb = brace_balance_in_fstring_fragment(frag)
    if bb < 0:
        # more } than { suggests messy fragment; do not auto-fix
        return line, False

    # If it *already* contains the quote later somehow (count odd says no),
    # but we still proceed: append closing quote and if line seems like a call, add )
    fixed = line.rstrip("\n")
    # Add closing quote
    fixed += quote
    # If the line likely belongs to a function call and doesn't already end with ')', add it
    if not fixed.rstrip().endswith(")"):
        fixed += ")"
    fixed += "\n"
    return fixed, True


def scan_file(path: Path, do_fix: bool) -> Tuple[int, int]:
    """
    Returns (issues_found, fixes_applied)
    """
    issues = 0
    fixes = 0
    try:
        text = path.read_text(encoding="utf-8", errors="replace").splitlines(True)
    except Exception as e:
        print(f"[WARN] Could not read {path}: {e}", file=sys.stderr)
        return 0, 0

    changed = False
    out_lines = []

    for i, line in enumerate(text, start=1):
        flagged = False

        if likely_unterminated_fstring(line):
            issues += 1
            flagged = True
            print(f"[ISSUE] {path}:{i}: likely unterminated f-string")
            print(f"        {line.rstrip()}")
            if do_fix:
                new_line, did = conservative_fix(line)
                if did:
                    out_lines.append(new_line)
                    fixes += 1
                    changed = True
                    print(f"[FIXED] {path}:{i}: appended closing quote/paren")
                else:
                    out_lines.append(line)
            else:
                out_lines.append(line)
        else:
            out_lines.append(line)

        # Optional extra: detect obviously unbalanced braces in *single-line* f-strings
        # (This is advisory only.)
        if not flagged and re.search(r"""(?i)\bf(['"])""", line) and not TRIPLE_START_RE.search(line):
            # crude: look between first quote and end-of-line
            m = re.search(r"""(?i)\bf(['"])""", line)
            if m:
                q = m.group(1)
                tail = line[m.start():]
                # only check if it seems closed on same line
                if tail.count(q) % 2 == 0:
                    bb = brace_balance_in_fstring_fragment(tail)
                    if bb != 0:
                        issues += 1
                        print(f"[WARN ] {path}:{i}: possible {{}} imbalance inside f-string (net={bb})")
                        print(f"        {line.rstrip()}")

    if do_fix and changed:
        bak = path.with_suffix(path.suffix + ".bak")
        try:
            if not bak.exists():
                bak.write_text("".join(text), encoding="utf-8")
            path.write_text("".join(out_lines), encoding="utf-8")
        except Exception as e:
            print(f"[ERROR] Failed writing {path}: {e}", file=sys.stderr)

    return issues, fixes


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("target", help="file or directory to scan")
    ap.add_argument("--fix", action="store_true", help="apply conservative auto-fixes")
    args = ap.parse_args()

    root = Path(args.target).expanduser().resolve()
    if not root.exists():
        print(f"Target not found: {root}", file=sys.stderr)
        return 2

    total_issues = 0
    total_fixes = 0

    for f in iter_py_files(root):
        issues, fixes = scan_file(f, args.fix)
        total_issues += issues
        total_fixes += fixes

    print("\n=== Summary ===")
    print(f"Issues flagged: {total_issues}")
    print(f"Fixes applied:  {total_fixes}  (backups: *.py.bak)")
    if args.fix:
        print("Re-run your program now; some issues may require manual edits.")
    else:
        print("Run again with --fix to apply conservative fixes.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
