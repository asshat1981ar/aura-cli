# DebuggerAgent Implementation Plan

## Overview
Create a new `DebuggerAgent` that analyzes raw stderr output from `SandboxAgent` to identify common error types (e.g., `ImportError`, `NameError`, `SyntaxError`) and provide structured, actionable feedback to the `CoderAgent` for targeted bug fixing.

## Scope Definition (CRITICAL)
### In Scope
- Create `agents/debugger.py` with a `DebuggerAgent` class.
- Implement an `analyze_stderr` method that takes `stderr` as input.
- Implement logic within `analyze_stderr` to detect `ImportError` and `NameError` initially.
- For detected errors, output a structured dictionary including `error_type`, `description`, and `fix_strategy`.
- Integrate the `DebuggerAgent` into `conductor_v2.py`'s `run_self_improvement_cycle` to process `sandbox_result.stderr` before passing feedback to `CoderAgent`.
### Out of Scope (DO NOT TOUCH)
- Detecting all possible error types (start with common ones).
- Implementing complex code analysis or AST parsing for deeper root cause analysis.
- Modifying `SandboxAgent` or `CoderAgent` beyond integration points.
- Building the `DebuggerAgent` as a standalone executable.

## Current State Analysis
*   `conductor_v2.py`: Currently passes `sandbox_result.stderr` directly or as part of `sandbox_feedback` to `CoderAgent`. This is where `DebuggerAgent` will be integrated.
*   `agents/coder.py`: `implement` method accepts `feedback` as a string. This needs to be adapted to receive structured feedback from `DebuggerAgent`. (This will be a minor modification during integration).
*   `agents/sandbox.py`: Provides `SandboxResult` containing `stderr`.

## Implementation Phases
### Phase 1: Create `DebuggerAgent` Skeleton
-   **Goal**: Establish the basic structure of the `DebuggerAgent` and its primary analysis method.
-   **Steps**:
    1.  [x] Create `agents/debugger.py` with an empty `DebuggerAgent` class and an `__init__` method.
    2.  [x] Add a placeholder `analyze_stderr(self, stderr: str) -> dict` method to the `DebuggerAgent` class, returning a simple dictionary `{"error_type": "Unknown", "description": stderr, "fix_strategy": "Review stderr output"}`.
-   **Verification**:
    *   Automated: Create `tests/test_debugger.py` with a basic test to instantiate `DebuggerAgent` and call `analyze_stderr` with sample `stderr`, verifying it returns the placeholder structure.

### Phase 2: Implement Basic Error Detection
-   **Goal**: Enable `DebuggerAgent` to detect `ImportError` and `NameError` from `stderr`.
-   **Steps**:
    1.  [x] In `DebuggerAgent.analyze_stderr`, add regex-based logic to identify `ImportError` patterns and extract the missing module name.
    2.  [x] For `ImportError`, return a structured diagnosis: `{"error_type": "ImportError", "description": "Missing import", "missing_module": "...", "fix_strategy": "Add import statement or install missing package"}`.
    3.  [x] Implement similar logic for `NameError` to identify the undefined name.
    4.  [x] For `NameError`, return: `{"error_type": "NameError", "description": "Undefined name", "undefined_name": "...", "fix_strategy": "Define the variable/function or check spelling"}`.
    5.  [x] Refine the "Unknown" error handling for cases not yet covered.
-   **Verification**:
    *   Automated: Extend `tests/test_debugger.py` with test cases for `ImportError` (e.g., `ModuleNotFoundError: No module named 'numpy'`) and `NameError` (e.g., `NameError: name 'my_func' is not defined`), verifying the structured output.

### Phase 3: Integrate `DebuggerAgent` into `conductor_v2.py`
-   **Goal**: Use `DebuggerAgent` to preprocess sandbox feedback before `CoderAgent` receives it.
-   **Steps**:
    1.  [ ] Instantiate `DebuggerAgent` in `conductor_v2.py`'s `build_system` function.
    2.  [ ] In `run_self_improvement_cycle`, modify the feedback loop:
        *   When `sandbox_result.stderr` indicates a failure, pass `sandbox_result.stderr` to `DebuggerAgent.analyze_stderr`.
        *   Update `sandbox_feedback` string to include the structured diagnosis from `DebuggerAgent` for `CoderAgent`.
-   **Verification**:
    *   Manual: Run `conductor_v2.py` with a goal that intentionally produces an `ImportError` or `NameError` in the `SandboxAgent` (e.g., by asking `CoderAgent` to write code with a missing import). Observe that `CoderAgent` receives structured feedback, and ideally, attempts to fix the issue in the next iteration.

### Phase 4: `CoderAgent` Feedback Adaptation
-   **Goal**: Enable `CoderAgent` to effectively interpret and utilize the structured diagnostic feedback from `DebuggerAgent`.
-   **Steps**:
    1.  [ ] Modify `agents/coder.py`'s `implement` method to accept `feedback` as a structured dictionary (from `DebuggerAgent`) instead of a raw string.
    2.  [ ] Within `CoderAgent.implement`, if `feedback` is a dictionary, parse its contents (e.g., `error_type`, `missing_module`, `fix_strategy`).
    3.  [ ] Adjust the prompt sent to the underlying model in `CoderAgent` to incorporate this structured feedback, guiding the model towards a more targeted fix (e.g., "The previous code failed with an ImportError for module 'X'. Please add `import X` to resolve this.").
-   **Verification**:
    *   Manual: Run `conductor_v2.py` with a goal that produces an error detectable by `DebuggerAgent` (e.g., missing import). Observe `CoderAgent`'s generated code in the next iteration to ensure it attempts a targeted fix based on the structured feedback, and that the `CoderAgent`'s model prompt clearly reflects the debugger's output.
