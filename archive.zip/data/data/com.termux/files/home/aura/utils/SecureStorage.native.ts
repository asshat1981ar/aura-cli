// utils/SecureStorage.native.ts
import * as SecureStore from 'expo-secure-store';

const SecureStorageNative = {
  async setItem(key: string, value: string): Promise<void> {
    await SecureStore.setItemAsync(key, value);
  },

  async getItem(key: string): Promise<string | null> {
    return await SecureStore.getItemAsync(key);
  },

  async deleteItem(key: string): Promise<void> {
    await SecureStore.deleteItemAsync(key);
  },

  async hasItem(key: string): Promise<boolean> {
    const value = await SecureStore.getItemAsync(key);
    return value !== null;
  },

  async clearAll(): Promise<void> {
    // expo-secure-store does not have a clearAll method.
    // This would require iterating over all keys, which SecureStore also doesn't provide directly.
    // For now, this will be a no-op or a warning.
    // A more robust solution might require tracking keys explicitly if clearAll is critical.
    console.warn("SecureStorageNative.clearAll() is not directly supported by expo-secure-store.");
    // Alternatively, if we store key names in a separate, less secure storage (AsyncStorage),
    // we could retrieve them and delete individually. But this introduces complexity.
    // For now, it's a known limitation.
  },
};

export default SecureStorageNative;
