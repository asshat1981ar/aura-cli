// plugins/validation/PluginManifestValidator.ts
import { z } from 'zod';
import { IPluginManifest } from '../../types/plugin/IPluginManifest';
import { PluginType } from '../../types/plugin/PluginType';

// Zod schema for PluginType enum
const PluginTypeSchema = z.nativeEnum(PluginType);

// Zod schema for IPluginManifest
const PluginManifestSchema = z.object({
  id: z.string().min(1, 'Plugin ID cannot be empty.'),
  name: z.string().min(1, 'Plugin name cannot be empty.'),
  version: z.string().regex(/^\d+\.\d+\.\d+(-.+)?$/, 'Invalid version format. Must be semver (e.g., 1.0.0).'),
  author: z.string().min(1, 'Plugin author cannot be empty.'),
  description: z.string().min(1, 'Plugin description cannot be empty.'),
  type: PluginTypeSchema,
  entryPoint: z.string().min(1, 'Plugin entry point cannot be empty.'),
  dependencies: z.record(z.string(), z.string().regex(/^\^?\d+\.\d+\.\d+(-.+)?$/, 'Invalid semver range for dependency.'),).optional(),
  config: z.record(z.string(), z.any()).optional(),
  locales: z.array(z.string()).optional(),
});

/**
 * Validates a raw object against the IPluginManifest schema.
 * @param manifest The raw object to validate.
 * @returns The validated IPluginManifest object.
 * @throws {z.ZodError} if validation fails.
 */
export function validateManifest(manifest: any): IPluginManifest {
  return PluginManifestSchema.parse(manifest);
}
