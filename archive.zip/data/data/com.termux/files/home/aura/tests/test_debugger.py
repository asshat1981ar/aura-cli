import unittest
from unittest.mock import MagicMock, patch
from agents.debugger import DebuggerAgent
from memory.brain import Brain # Assuming Brain needs to be mocked or instantiated

class TestDebuggerAgent(unittest.TestCase):

    def setUp(self):
        self.mock_brain = MagicMock(spec=Brain)
        self.debugger_agent = DebuggerAgent(self.mock_brain)

    def test_analyze_stderr_placeholder_structure(self):
        sample_stderr = "Some raw error output from sandbox."
        expected_output = {
            "error_type": "Unknown",
            "description": sample_stderr,
            "fix_strategy": "Review stderr output"
        }
        
        result = self.debugger_agent.analyze_stderr(sample_stderr)
        self.assertEqual(result, expected_output)

    def test_analyze_stderr_import_error(self):
        stderr_output = "Traceback (most recent call last):\n  File \"<stdin>\", line 1, in <module>\nModuleNotFoundError: No module named 'numpy'\n"
        expected_output = {
            "error_type": "ImportError",
            "description": "Missing import",
            "missing_module": "numpy",
            "fix_strategy": "Add `import numpy` statement or install missing package `numpy`."
        }
        result = self.debugger_agent.analyze_stderr(stderr_output)
        self.assertEqual(result, expected_output)

    def test_analyze_stderr_name_error(self):
        stderr_output = "Traceback (most recent call last):\n  File \"<stdin>\", line 1, in <module>\nNameError: name 'my_variable' is not defined\n"
        expected_output = {
            "error_type": "NameError",
            "description": "Undefined name",
            "undefined_name": "my_variable",
            "fix_strategy": "Define the variable/function `my_variable` or check for spelling errors."
        }
        result = self.debugger_agent.analyze_stderr(stderr_output)
        self.assertEqual(result, expected_output)

    def test_analyze_stderr_unknown_error(self):
        stderr_output = "Traceback (most recent call last):\n  File \"<stdin>\", line 1, in <module>\nTypeError: 'int' object is not callable\n"
        expected_output = {
            "error_type": "Unknown",
            "description": stderr_output,
            "fix_strategy": "Review stderr output"
        }
        result = self.debugger_agent.analyze_stderr(stderr_output)
        self.assertEqual(result, expected_output)

if __name__ == '__main__':
    unittest.main()

