// utils/BiometricAuthService.ts
import * as LocalAuthentication from 'expo-local-authentication';
import SecureStorage from './SecureStorage';

const BIOMETRIC_ENABLED_KEY = 'biometric_auth_enabled';

class BiometricAuthService {
  /**
   * Checks if biometric authentication is available and enrolled on the device.
   * @returns Promise<boolean> True if biometrics are available and enrolled.
   */
  static async isBiometricAvailableAndEnrolled(): Promise<boolean> {
    const hasHardware = await LocalAuthentication.hasHardwareAsync();
    const isEnrolled = await LocalAuthentication.isEnrolledAsync();
    return hasHardware && isEnrolled;
  }

  /**
   * Checks if biometric authentication is enabled by the user in app settings.
   * @returns Promise<boolean> True if user has enabled biometrics.
   */
  static async isBiometricEnabledByUser(): Promise<boolean> {
    const enabled = await SecureStorage.getItem(BIOMETRIC_ENABLED_KEY);
    return enabled === 'true';
  }

  /**
   * Enables or disables biometric authentication for the user.
   * @param enable True to enable, false to disable.
   * @returns Promise<void>
   */
  static async setBiometricEnabled(enable: boolean): Promise<void> {
    await SecureStorage.setItem(BIOMETRIC_ENABLED_KEY, enable ? 'true' : 'false');
  }

  /**
   * Prompts the user for biometric authentication.
   * @param promptMessage The message to display to the user during authentication.
   * @returns Promise<LocalAuthentication.AuthenticationResult> The result of the authentication attempt.
   */
  static async authenticate(promptMessage: string): Promise<LocalAuthentication.AuthenticationResult> {
    const isAvailable = await BiometricAuthService.isBiometricAvailableAndEnrolled();
    if (!isAvailable) {
      return { success: false, error: 'BIOMETRIC_NOT_AVAILABLE', warning: 'Biometric hardware not available or not enrolled.' };
    }

    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: promptMessage,
      fallbackLabel: 'Use Passcode', // Fallback to device passcode
      disableDeviceFallback: false, // Allows device passcode as fallback
    });
    return result;
  }

  /**
   * Authenticates the user using biometrics if enabled, otherwise signals fallback.
   * This method orchestrates the user-facing biometric flow.
   * @param purpose A message indicating the purpose of authentication (e.g., "login", "confirm purchase").
   * @returns Promise<{ success: boolean; requiresFallback: boolean; error?: string }>
   */
  static async authenticateIfEnabled(purpose: string): Promise<{ success: boolean; requiresFallback: boolean; error?: string }> {
    const isAvailableAndEnrolled = await BiometricAuthService.isBiometricAvailableAndEnrolled();
    const isEnabledByUser = await BiometricAuthService.isBiometricEnabledByUser();

    if (isAvailableAndEnrolled && isEnabledByUser) {
      const result = await BiometricAuthService.authenticate(`Authenticate to ${purpose}`);
      if (result.success) {
        return { success: true, requiresFallback: false };
      } else {
        // If biometric failed (e.g., too many attempts, user cancelled),
        // we might still offer a password/PIN fallback in the UI.
        console.log("Biometric authentication failed:", result.error);
        return { success: false, requiresFallback: true, error: result.error };
      }
    } else if (!isEnabledByUser) {
      console.log("Biometric authentication is not enabled by the user.");
      return { success: false, requiresFallback: true, error: "BIOMETRIC_DISABLED_BY_USER" };
    } else {
      console.log("Biometric authentication not available or not enrolled.");
      return { success: false, requiresFallback: true, error: "BIOMETRIC_NOT_AVAILABLE_OR_ENROLLED" };
    }
  }
}

export default BiometricAuthService;
