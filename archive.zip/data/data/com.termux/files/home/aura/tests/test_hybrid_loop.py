import unittest
from unittest.mock import MagicMock, patch
from core.hybrid_loop import HybridClosedLoop
from memory.brain import Brain 
import re
import io # Import io for stdout capturing

# Mock classes for dependencies
class MockModelAdapter:
    def respond(self, prompt: str) -> str:
        # This will be replaced by specific mock behaviors in tests
        return """[CRITIQUE]
Performance Score: 7
Stability Score: 7
Security Score: 7
Elegance Score: 7
Weaknesses: None
"""

class MockGitTools:
    def commit_all(self, message: str):
        pass # Mock commit
    def rollback_last_commit(self, message: str = ""):
        pass # Mock rollback

class TestHybridClosedLoop(unittest.TestCase):

    def setUp(self):
        # Setup mocks
        self.mock_model = MockModelAdapter()
        self.mock_brain = MagicMock(spec=Brain)
        self.mock_git = MockGitTools()

        # Mock brain methods that are called by HybridClosedLoop
        self.mock_brain.recall_all.return_value = []
        self.mock_brain.remember.return_value = None

        self.hybrid_loop = HybridClosedLoop(self.mock_model, self.mock_brain, self.mock_git)
        self.hybrid_loop.previous_score = 0 # Ensure fresh state for each test
        self.hybrid_loop.regression_count = 0
        self.hybrid_loop.stable_convergence_count = 0

    def test_model_respond_exception_handling(self):
        # Simulate an exception from model.respond
        with patch.object(self.mock_model, 'respond', side_effect=ValueError("Model error")) as mock_respond:
            goal = "Test Goal"
            response = self.hybrid_loop.run(goal)
            
            mock_respond.assert_called_once_with(self.hybrid_loop._bootstrap_prompt_template.format(GOAL=goal, STATE="Memory entries: 0"))
            
            # Verify that a structured error response is returned
            self.assertIn("Error: Model response failed.", response)
            
            # Check if scores are set to prevent convergence (e.g., all 0s)
            error_scores = self.hybrid_loop.extract_scores(response)
            for score_value in error_scores.values():
                self.assertEqual(score_value, 0)
            
            self.assertEqual(self.hybrid_loop.weighted_score(error_scores), 0)
            self.assertIn("Continuing evolution", response) # Should continue as score is 0
            self.assertEqual(self.hybrid_loop.stable_convergence_count, 0) # Should not converge

    def test_extract_scores_missing_score_lines(self):
        malformed_response = """
[CRITIQUE]
Performance Score: 8
Stability Score: 7
Security Score: 6
Weaknesses: Some issues.
""" # Missing Elegance Score intentionally

        with patch('sys.stdout', new_callable=io.StringIO) as mock_stdout:
            scores = self.hybrid_loop.extract_scores(malformed_response)
            
            self.assertIn("Warning: Score not found for 'elegance'. Defaulting to 0.", mock_stdout.getvalue())

        self.assertEqual(scores['performance'], 8)
        self.assertEqual(scores['stability'], 7)
        self.assertEqual(scores['security'], 6)
        self.assertEqual(scores['elegance'], 0) # Should default to 0
        self.assertAlmostEqual(self.hybrid_loop.weighted_score(scores), 8*0.30 + 7*0.30 + 6*0.25 + 0*0.15)

    def test_extract_scores_varied_spacing(self):
        varied_spacing_response = """
[CRITIQUE]
Performance Score:  9
Stability   Score: 8
Security Score   : 7
Elegance Score: 6
Weaknesses: None.
"""
        scores = self.hybrid_loop.extract_scores(varied_spacing_response)
        self.assertEqual(scores['performance'], 9)
        self.assertEqual(scores['stability'], 8)
        self.assertEqual(scores['security'], 7)
        self.assertEqual(scores['elegance'], 6)
        self.assertAlmostEqual(self.hybrid_loop.weighted_score(scores), 9*0.30 + 8*0.30 + 7*0.25 + 6*0.15)


    def test_git_rollback_on_repeated_regression(self):
        # Mock GitTools.rollback_last_commit to check if it's called
        with patch.object(self.mock_git, 'rollback_last_commit') as mock_rollback:
            # Simulate regression 3 times
            self.hybrid_loop.previous_score = 10 # Start with a high score
            
            # Cycle 1: Regression
            response1 = """[CRITIQUE]
Performance Score: 6
Stability Score: 6
Security Score: 6
Elegance Score: 6
Weaknesses: None.
"""
            with patch.object(self.mock_model, 'respond', return_value=response1):
                result1 = self.hybrid_loop.run("Goal 1")
                self.assertIn("Continuing evolution", result1)
                self.assertEqual(self.hybrid_loop.regression_count, 1)
                mock_rollback.assert_not_called()

            # Cycle 2: Regression
            response2 = """[CRITIQUE]
Performance Score: 5
Stability Score: 5
Security Score: 5
Elegance Score: 5
Weaknesses: None.
"""
            with patch.object(self.mock_model, 'respond', return_value=response2):
                result2 = self.hybrid_loop.run("Goal 2")
                self.assertIn("Continuing evolution", result2)
                self.assertEqual(self.hybrid_loop.regression_count, 2)
                mock_rollback.assert_not_called()

            # Cycle 3: Regression - should trigger rollback
            response3 = """[CRITIQUE]
Performance Score: 4
Stability Score: 4
Security Score: 4
Elegance Score: 4
Weaknesses: None.
"""
            with patch.object(self.mock_model, 'respond', return_value=response3):
                with patch('sys.stdout', new_callable=io.StringIO) as mock_stdout:
                    result3 = self.hybrid_loop.run("Goal 3")
                    self.assertIn("Terminated: Repeated regression detected.", result3)
                    self.assertEqual(self.hybrid_loop.regression_count, 3)
                    mock_rollback.assert_called_once()
                    self.assertIn("GitTools: Performing rollback due to repeated regression.", mock_stdout.getvalue())

if __name__ == '__main__':
    unittest.main()

