// __tests__/utils/services/OpenAIService.test.ts
import OpenAIService from '../../../utils/services/OpenAIService';
import MultiServiceApiClient from '../../../utils/MultiServiceApiClient';
import { ApiService } = from '../../../utils/ApiKeyManager';
import axios from 'axios';

// Mock MultiServiceApiClient to control the axios instance it returns
jest.mock('../../../utils/MultiServiceApiClient', () => ({
  getClient: jest.fn(),
}));

describe('OpenAIService', () => {
  const mockAxiosInstance = {
    post: jest.fn(),
  } as unknown as axios.AxiosInstance;

  beforeEach(() => {
    jest.clearAllMocks();
    (MultiServiceApiClient.getClient as jest.Mock).mockResolvedValue(mockAxiosInstance);
  });

  describe('chatCompletion', () => {
    const mockMessages = [{ role: 'user', content: 'Hello' }];
    const mockResponseData = {
      id: 'chatcmpl-123',
      object: 'chat.completion',
      created: 1678886400,
      model: 'gpt-3.5-turbo',
      choices: [{ index: 0, message: { role: 'assistant', content: 'Hi there!' }, logprobs: null, finish_reason: 'stop' }],
      usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 },
    };

    it('should call chat completions API with default model', async () => {
      mockAxiosInstance.post.mockResolvedValue({ data: mockResponseData });

      const response = await OpenAIService.chatCompletion(mockMessages);

      expect(MultiServiceApiClient.getClient).toHaveBeenCalledWith(ApiService.OpenAI);
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/chat/completions', {
        model: 'gpt-3.5-turbo',
        messages: mockMessages,
      });
      expect(response).toEqual(mockResponseData);
    });

    it('should call chat completions API with specified model and options', async () => {
      mockAxiosInstance.post.mockResolvedValue({ data: mockResponseData });

      const options = { model: 'gpt-4', temperature: 0.7, max_tokens: 100 };
      const response = await OpenAIService.chatCompletion(mockMessages, options);

      expect(MultiServiceApiClient.getClient).toHaveBeenCalledWith(ApiService.OpenAI);
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/chat/completions', {
        model: 'gpt-4',
        messages: mockMessages,
        temperature: 0.7,
        max_tokens: 100,
      });
      expect(response).toEqual(mockResponseData);
    });
  });

  describe('generateEmbedding', () => {
    const mockInput = 'This is a test sentence.';
    const mockResponseData = {
      object: 'list',
      data: [{ object: 'embedding', embedding: [0.1, 0.2, 0.3], index: 0 }],
      model: 'text-embedding-ada-002',
      usage: { prompt_tokens: 5, total_tokens: 5 },
    };

    it('should call embeddings API with default model', async () => {
      mockAxiosInstance.post.mockResolvedValue({ data: mockResponseData });

      const response = await OpenAIService.generateEmbedding(mockInput);

      expect(MultiServiceApiClient.getClient).toHaveBeenCalledWith(ApiService.OpenAI);
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/embeddings', {
        model: 'text-embedding-ada-002',
        input: mockInput,
      });
      expect(response).toEqual(mockResponseData);
    });

    it('should call embeddings API with specified model', async () => {
      mockAxiosInstance.post.mockResolvedValue({ data: mockResponseData });

      const model = 'custom-embedding-model';
      const response = await OpenAIService.generateEmbedding(mockInput, model);

      expect(MultiServiceApiClient.getClient).toHaveBeenCalledWith(ApiService.OpenAI);
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/embeddings', {
        model: model,
        input: mockInput,
      });
      expect(response).toEqual(mockResponseData);
    });
  });
});
