// utils/ApiKeyManager.ts
import SecureStorage from './SecureStorage';

export enum ApiService {
  OpenAI = 'openai',
  Anthropic = 'anthropic',
  Google = 'google',
  DeepL = 'deepl',
  // Add other services as needed
}

const API_KEY_PREFIX = 'api_key_'; // Prefix to store API keys in SecureStorage

class ApiKeyManager {
  /**
   * Stores an API key for a specific service.
   * @param service The API service (e.g., ApiService.OpenAI).
   * @param apiKey The API key string.
   * @returns Promise<void>
   */
  static async setApiKey(service: ApiService, apiKey: string): Promise<void> {
    if (!service || !apiKey) {
      throw new Error("Service and API key cannot be empty.");
    }
    await SecureStorage.setItem(`${API_KEY_PREFIX}${service}`, apiKey);
  }

  /**
   * Retrieves an API key for a specific service.
   * @param service The API service.
   * @returns Promise<string | null> The API key or null if not found.
   */
  static async getApiKey(service: ApiService): Promise<string | null> {
    if (!service) {
      throw new Error("Service cannot be empty.");
    }
    return await SecureStorage.getItem(`${API_KEY_PREFIX}${service}`);
  }

  /**
   * Removes an API key for a specific service.
   * @param service The API service.
   * @returns Promise<void>
   */
  static async removeApiKey(service: ApiService): Promise<void> {
    if (!service) {
      throw new Error("Service cannot be empty.");
    }
    await SecureStorage.deleteItem(`${API_KEY_PREFIX}${service}`);
  }

  /**
   * Checks if an API key exists for a specific service.
   * @param service The API service.
   * @returns Promise<boolean>
   */
  static async hasApiKey(service: ApiService): Promise<boolean> {
    if (!service) {
      throw new Error("Service cannot be empty.");
    }
    return await SecureStorage.hasItem(`${API_KEY_PREFIX}${service}`);
  }

  /**
   * Clears all API keys managed by this manager.
   * Note: This uses SecureStorage.clearAll(), which might have limitations on native.
   * @returns Promise<void>
   */
  static async clearAllApiKeys(): Promise<void> {
    // This will clear ALL items in SecureStorage, not just API keys,
    // due to SecureStorage's lack of key enumeration on native.
    // A more granular approach would require tracking keys in another, less secure storage.
    // For now, this is a known trade-off.
    console.warn("clearAllApiKeys will clear ALL items in SecureStorage due to underlying platform limitations.");
    await SecureStorage.clearAll();
  }
}

export default ApiKeyManager;
