// types/workflow/IOutputDefinition.ts
import { IDataDefinition } from './IDataDefinition';

export interface IOutputDefinition extends IDataDefinition {
  // Specific properties for output if any, currently same as IDataDefinition
}
