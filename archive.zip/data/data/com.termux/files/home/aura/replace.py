#!/usr/bin/env python3
import os
import shutil

# Define files
files_to_edit = [
    "memory/brain.py",
    "agents/coder.py"
]

backup_suffix = ".backup"

# Step 1: Backup files
for file_path in files_to_edit:
    if os.path.exists(file_path):
        shutil.copyfile(file_path, file_path + backup_suffix)
        print(f"Backed up {file_path} -> {file_path + backup_suffix}")

# Step 2: Edit brain.py
brain_path = "memory/brain.py"
if os.path.exists(brain_path):
    with open(brain_path, "r") as f:
        lines = f.readlines()

    new_lines = []
    for line in lines:
        # Comment out imports and semantic/vector lines
        if any(keyword in line for keyword in [
            "SentenceTransformer", "faiss", "self.vector_db",
            "self._load_embeddings_into_faiss", "embedding_model.encode",
            "semantic_recall", "self.vector_db.add"
        ]):
            if not line.strip().startswith("#"):
                new_lines.append("# " + line)
            else:
                new_lines.append(line)
        else:
            new_lines.append(line)

    with open(brain_path, "w") as f:
        f.writelines(new_lines)
    print(f"Edited {brain_path} - semantic search disabled")

# Step 3: Edit coder.py
coder_path = "agents/coder.py"
if os.path.exists(coder_path):
    with open(coder_path, "r") as f:
        content = f.read()

    content = content.replace("self.brain.semantic_recall", "self.brain.recall_all")

    with open(coder_path, "w") as f:
        f.write(content)
    print(f"Edited {coder_path} - semantic_recall -> recall_all")

print("✅ All modifications applied. You can now run main.py without semantic memory.")
