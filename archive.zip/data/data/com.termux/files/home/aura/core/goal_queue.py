import json
import os
from collections import deque

class GoalQueue:

    def __init__(self, queue_path="memory/goal_queue.json"):
        self.queue_path = queue_path
        self.queue = self._load_queue() # Load into a deque

    def add(self, goal):
        self.queue.append(goal)
        self._save_queue()

    def next(self):
        if self.queue:
            goal = self.queue.popleft() # Optimized pop
            self._save_queue()
            return goal
        return None

    def has_goals(self):
        return len(self.queue) > 0

    def _save_queue(self):
        os.makedirs(os.path.dirname(self.queue_path), exist_ok=True)
        with open(self.queue_path, 'w') as f:
            json.dump(list(self.queue), f, indent=4) # Convert deque to list for JSON serialization

    def _load_queue(self):
        if os.path.exists(self.queue_path):
            with open(self.queue_path, 'r') as f:
                try:
                    return deque(json.load(f))
                except json.JSONDecodeError:
                    print(f"Warning: Could not decode JSON from {self.queue_path}. Starting with empty queue.")
                    return deque()
        return deque()
