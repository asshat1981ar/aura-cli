// utils/services/OpenAIService.ts
import MultiServiceApiClient from '../MultiServiceApiClient';
import { ApiService } from '../ApiKeyManager';

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface ChatCompletionOptions {
  model?: string; // e.g., "gpt-3.5-turbo", "gpt-4"
  temperature?: number;
  max_tokens?: number;
  // Add other OpenAI specific options as needed
}

interface ChatCompletionResponse {
  id: string;
  object: string;
  created: number;
  model: string;
  choices: Array<{
    index: number;
    message: ChatMessage;
    logprobs: any | null;
    finish_reason: string;
  }>;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

interface EmbeddingResponse {
  object: string;
  data: Array<{
    object: string;
    embedding: number[];
    index: number;
  }>;
  model: string;
  usage: {
    prompt_tokens: number;
    total_tokens: number;
  };
}

class OpenAIService {
  private static service: ApiService = ApiService.OpenAI;

  /**
   * Performs a chat completion using the OpenAI API.
   * @param messages Conversation history.
   * @param options Chat completion options.
   * @returns Promise<ChatCompletionResponse>
   */
  static async chatCompletion(
    messages: ChatMessage[],
    options?: ChatCompletionOptions
  ): Promise<ChatCompletionResponse> {
    const client = await MultiServiceApiClient.getClient(OpenAIService.service);
    const response = await client.post<ChatCompletionResponse>('/chat/completions', {
      model: options?.model || 'gpt-3.5-turbo', // Default model
      messages,
      ...options,
    });
    return response.data;
  }

  /**
   * Generates embeddings for a given text using the OpenAI API.
   * @param input The text to generate embeddings for.
   * @param model The embedding model to use (e.g., "text-embedding-ada-002").
   * @returns Promise<EmbeddingResponse>
   */
  static async generateEmbedding(
    input: string | string[],
    model: string = 'text-embedding-ada-002'
  ): Promise<EmbeddingResponse> {
    const client = await MultiServiceApiClient.getClient(OpenAIService.service);
    const response = await client.post<EmbeddingResponse>('/embeddings', {
      model,
      input,
    });
    return response.data;
  }
}

export default OpenAIService;
