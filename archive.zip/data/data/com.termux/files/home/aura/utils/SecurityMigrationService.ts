// utils/SecurityMigrationService.ts
import AsyncStorage from '@react-native-async-storage/async-storage';
import SecureStorage from './SecureStorage';

// List of keys known to store sensitive data in insecure locations
// This list should be maintained as the app evolves
const SENSITIVE_KEYS_IN_ASYNC_STORAGE = [
  'legacy_api_key',
  'old_user_token',
  // Add other keys that might have been stored insecurely
];

const MIGRATION_COMPLETED_KEY = 'security_migration_completed'; // Flag to ensure one-time execution

class SecurityMigrationService {
  /**
   * Runs the security migration process.
   * This should be called early in the application's lifecycle.
   * @returns Promise<void>
   */
  static async runMigration(): Promise<void> {
    console.log("Starting security migration check...");

    // Check if migration has already been completed
    const migrationCompleted = await SecureStorage.getItem(MIGRATION_COMPLETED_KEY);
    if (migrationCompleted === 'true') {
      console.log("Security migration already completed.");
      return;
    }

    let migratedCount = 0;
    for (const key of SENSITIVE_KEYS_IN_ASYNC_STORAGE) {
      const insecureValue = await AsyncStorage.getItem(key);

      if (insecureValue !== null) {
        console.log(`Migrating sensitive key: ${key}`);
        try {
          // Store securely
          await SecureStorage.setItem(key, insecureValue);
          // Verify (optional, but good practice)
          const verifiedValue = await SecureStorage.getItem(key);
          if (verifiedValue === insecureValue) {
            // Remove from insecure location
            await AsyncStorage.removeItem(key);
            console.log(`Successfully migrated and removed key: ${key}`);
            migratedCount++;
          } else {
            console.warn(`Migration verification failed for key: ${key}. Data not removed from insecure storage.`);
          }
        } catch (error) {
          console.error(`Error migrating key ${key}:`, error);
        }
      }
    }

    if (migratedCount > 0) {
      console.log(`Completed security migration for ${migratedCount} item(s).`);
    } else {
      console.log("No sensitive items found for migration.");
    }

    // Mark migration as completed only if we tried to migrate
    await SecureStorage.setItem(MIGRATION_COMPLETED_KEY, 'true');
    console.log("Security migration check finished.");
  }
}

export default SecurityMigrationService;
