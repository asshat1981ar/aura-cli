// utils/ApiClient.ts
import axios, { AxiosInstance, AxiosRequestConfig, AxiosError } from 'axios';
import AuthService from './AuthService';
import Logger from './Logger'; // Import Logger

// Base URL for your API
const API_BASE_URL = 'https://your-api.com/v1';

const apiClient: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request Interceptor: Attach access token to outgoing requests
apiClient.interceptors.request.use(
  async (config: AxiosRequestConfig) => {
    const accessToken = await AuthService.getAccessToken();
    const isExpired = await AuthService.isAccessTokenExpired();

    if (accessToken && !isExpired) {
      if (!config.headers) {
        config.headers = {};
      }
      config.headers.Authorization = `Bearer ${accessToken}`;
    } else if (accessToken && isExpired) {
      // Access token is expired, try to refresh
      const refreshToken = await AuthService.getRefreshToken();
      if (refreshToken) {
        const newTokens = await AuthService.refreshAccessToken(refreshToken);
        if (newTokens) {
          // Successfully refreshed, update header with new token
          if (!config.headers) {
            config.headers = {};
          }
          config.headers.Authorization = `Bearer ${newTokens.accessToken}`;
        } else {
          // Refresh failed, clear tokens and prompt re-authentication
          await AuthService.clearTokens();
          // TODO: Implement actual re-authentication flow (e.g., redirect to login)
          console.warn("Token refresh failed. User needs to re-authenticate.");
          return Promise.reject(new AxiosError('Token refresh failed, re-authentication required.', '401', config));
        }
      } else {
        // No refresh token, clear tokens and prompt re-authentication
        await AuthService.clearTokens();
        // TODO: Implement actual re-authentication flow (e.g., redirect to login)
        console.warn("No refresh token available. User needs to re-authenticate.");
        return Promise.reject(new AxiosError('No refresh token, re-authentication required.', '401', config));
      }
    }
    return config;
  },
  (error: AxiosError) => {
    return Promise.reject(error);
  }
);

// Response Interceptor: Handle 401 Unauthorized errors (e.g., if token unexpectedly invalid)
apiClient.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config;
    const statusCode = error.response?.status;
    const errorMessage = error.response?.data || error.message;

    // Log the error
    Logger.error(`API Call Error: ${error.message}`, error, {
      url: originalRequest?.url,
      method: originalRequest?.method,
      statusCode: statusCode,
      response: errorMessage,
    });

    // Handle 401 Unauthorized errors
    if (statusCode === 401 && originalRequest && !(originalRequest as any)._retry) {
      (originalRequest as any)._retry = true; // Mark request as retried
      const refreshToken = await AuthService.getRefreshToken();
      if (refreshToken) {
        try {
          const newTokens = await AuthService.refreshAccessToken(refreshToken);
          if (newTokens) {
            // Update original request with new token and retry
            if (!originalRequest.headers) {
              originalRequest.headers = {};
            }
            originalRequest.headers.Authorization = `Bearer ${newTokens.accessToken}`;
            Logger.info('Successfully refreshed token and retrying original request.');
            return apiClient(originalRequest); // Retry the original request
          }
        } catch (refreshError) {
          Logger.error('Failed to refresh token during 401 retry.', refreshError);
        }
      }
      // If refresh failed or no refresh token, clear tokens and prompt re-authentication
      await AuthService.clearTokens();
      // TODO: Implement actual re-authentication flow (e.g., redirect to login)
      Logger.warn("Token refresh failed or no refresh token available. User needs to re-authenticate.");
      return Promise.reject(new AxiosError('Authentication required.', '401', originalRequest));
    }

    // Handle other HTTP errors
    if (statusCode && statusCode >= 400) {
      // You can define a custom error class here or return a standardized object
      return Promise.reject({
        status: statusCode,
        message: `API Error: ${statusCode}`,
        details: errorMessage,
        isApiError: true,
      });
    }

    return Promise.reject(error); // Re-throw other errors
  }
);

export default apiClient;
