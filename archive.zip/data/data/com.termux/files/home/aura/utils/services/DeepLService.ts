// utils/services/DeepLService.ts
import MultiServiceApiClient from '../MultiServiceApiClient';
import { ApiService } from '../ApiKeyManager';

interface DeepLTranslateOptions {
  source_lang?: string; // Source language code (e.g., 'en', 'de')
  target_lang: string; // Target language code (e.g., 'es', 'fr')
  // Add other DeepL specific options like 'formality'
}

interface DeepLTranslateResponse {
  translations: Array<{
    detected_source_language: string;
    text: string;
  }>;
}

class DeepLService {
  private static service: ApiService = ApiService.DeepL;

  /**
   * Performs text translation using the DeepL API.
   * @param text The text or array of texts to translate.
   * @param options Translation options (e.g., target_lang, source_lang).
   * @returns Promise<DeepLTranslateResponse>
   */
  static async translate(
    text: string | string[],
    options: DeepLTranslateOptions
  ): Promise<DeepLTranslateResponse> {
    const client = await MultiServiceApiClient.getClient(DeepLService.service);
    const response = await client.post<DeepLTranslateResponse>('/translate', {
      text: Array.isArray(text) ? text : [text],
      source_lang: options.source_lang,
      target_lang: options.target_lang,
      // Add other options here
    });
    return response.data;
  }
}

export default DeepLService;
