// types/plugin/IUiExtensionPlugin.ts
import { IPlugin } from './IPlugin';
import { PluginType } from './PluginType';
import React from 'react'; // Assuming React context for UI components

export interface IUiExtensionPlugin extends IPlugin {
  type: PluginType.UiExtension; // Enforce specific plugin type

  extensionPoint: string; // Identifier for where in the UI this extension should be rendered

  /**
   * Renders the UI component provided by the plugin.
   * @param props Properties to pass to the React component.
   * @returns A React component type (e.g., a functional component or class component).
   */
  renderComponent(props: any): React.ComponentType<any>;
}
