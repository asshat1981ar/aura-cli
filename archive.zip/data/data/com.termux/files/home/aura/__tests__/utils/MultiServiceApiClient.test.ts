// __tests__/utils/MultiServiceApiClient.test.ts
import MultiServiceApiClient from '../../utils/MultiServiceApiClient';
import ApiKeyManager, { ApiService } from '../../utils/ApiKeyManager';
import axios from 'axios';

jest.mock('../../utils/ApiKeyManager', () => ({
  getApiKey: jest.fn(),
  ApiService: {
    OpenAI: 'openai',
    Anthropic: 'anthropic',
    Google: 'google',
    DeepL: 'deepl',
  },
}));

jest.mock('axios', () => ({
  create: jest.fn(() => ({
    interceptors: {
      request: { use: jest.fn() },
      response: { use: jest.fn() },
    },
    get: jest.fn(),
    post: jest.fn(),
  })),
}));

describe('MultiServiceApiClient', () => {
  const mockAxiosInstance = (axios.create as jest.Mock).mock.results[0].value; // Get the mocked axios instance

  beforeEach(() => {
    jest.clearAllMocks();
    // Reset the clients map to ensure fresh instances for each test
    (MultiServiceApiClient as any).clients = new Map();
  });

  it('should create an Axios instance with the correct base URL', async () => {
    await MultiServiceApiClient.getClient(ApiService.OpenAI);
    expect(axios.create).toHaveBeenCalledWith({
      baseURL: 'https://api.openai.com/v1',
      headers: { 'Content-Type': 'application/json' },
    });
  });

  it('should return the same instance for subsequent calls with the same service', async () => {
    const client1 = await MultiServiceApiClient.getClient(ApiService.OpenAI);
    const client2 = await MultiServiceApiClient.getClient(ApiService.OpenAI);
    expect(client1).toBe(client2);
    expect(axios.create).toHaveBeenCalledTimes(1); // Should only create once
  });

  describe('Request Interceptor', () => {
    it('should inject OpenAI API key into Authorization header', async () => {
      const mockApiKey = 'sk-openai-test';
      (ApiKeyManager.getApiKey as jest.Mock).mockResolvedValue(mockApiKey);
      const client = await MultiServiceApiClient.getClient(ApiService.OpenAI);
      
      const requestInterceptor = mockAxiosInstance.interceptors.request.use.mock.calls[0][0];
      const config: AxiosRequestConfig = {};
      const newConfig = await requestInterceptor(config);

      expect(newConfig.headers?.Authorization).toBe(`Bearer ${mockApiKey}`);
    });

    it('should inject Anthropic API key into x-api-key header', async () => {
      const mockApiKey = 'sk-anthropic-test';
      (ApiKeyManager.getApiKey as jest.Mock).mockResolvedValue(mockApiKey);
      const client = await MultiServiceApiClient.getClient(ApiService.Anthropic);
      
      const requestInterceptor = mockAxiosInstance.interceptors.request.use.mock.calls[0][0];
      const config: AxiosRequestConfig = {};
      const newConfig = await requestInterceptor(config);

      expect(newConfig.headers?.['x-api-key']).toBe(mockApiKey);
    });

    it('should inject Google API key as a query parameter', async () => {
      const mockApiKey = 'google-api-key-test';
      (ApiKeyManager.getApiKey as jest.Mock).mockResolvedValue(mockApiKey);
      const client = await MultiServiceApiClient.getClient(ApiService.Google);
      
      const requestInterceptor = mockAxiosInstance.interceptors.request.use.mock.calls[0][0];
      const config: AxiosRequestConfig = {};
      const newConfig = await requestInterceptor(config);

      expect(newConfig.params?.key).toBe(mockApiKey);
    });

    it('should inject DeepL API key into Authorization header', async () => {
      const mockApiKey = 'deepl-api-key-test';
      (ApiKeyManager.getApiKey as jest.Mock).mockResolvedValue(mockApiKey);
      const client = await MultiServiceApiClient.getClient(ApiService.DeepL);
      
      const requestInterceptor = mockAxiosInstance.interceptors.request.use.mock.calls[0][0];
      const config: AxiosRequestConfig = {};
      const newConfig = await requestInterceptor(config);

      expect(newConfig.headers?.Authorization).toBe(`DeepL-Auth-Key ${mockApiKey}`);
    });

    it('should not inject API key if not found', async () => {
      (ApiKeyManager.getApiKey as jest.Mock).mockResolvedValue(null);
      const client = await MultiServiceApiClient.getClient(ApiService.OpenAI);
      
      const requestInterceptor = mockAxiosInstance.interceptors.request.use.mock.calls[0][0];
      const config: AxiosRequestConfig = {};
      const newConfig = await requestInterceptor(config);

      expect(newConfig.headers?.Authorization).toBeUndefined();
    });
  });

  it('should make a GET request using the configured client', async () => {
    const mockData = { message: 'success' };
    mockAxiosInstance.get.mockResolvedValue({ data: mockData });
    
    const result = await MultiServiceApiClient.get(ApiService.OpenAI, '/models');
    expect(mockAxiosInstance.get).toHaveBeenCalledWith('/models', undefined);
    expect(result).toEqual(mockData);
  });

  it('should make a POST request using the configured client', async () => {
    const mockData = { id: 'chat-123' };
    const postPayload = { prompt: 'hello' };
    mockAxiosInstance.post.mockResolvedValue({ data: mockData });
    
    const result = await MultiServiceApiClient.post(ApiService.Anthropic, '/messages', postPayload);
    expect(mockAxiosInstance.post).toHaveBeenCalledWith('/messages', postPayload, undefined);
    expect(result).toEqual(mockData);
  });
});
