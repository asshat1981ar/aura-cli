// types/workflow/IInputDefinition.ts
import { IDataDefinition } from './IDataDefinition';

export interface IInputDefinition extends IDataDefinition {
  // Specific properties for input if any, currently same as IDataDefinition
}
