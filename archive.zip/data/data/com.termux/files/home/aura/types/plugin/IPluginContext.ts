// types/plugin/IPluginContext.ts
// Import core services that plugins might need
import Logger from '../../utils/Logger';
import ConfigService from '../../utils/ConfigService';
import { ApiKeyManager } from '../../utils/ApiKeyManager';
import AuthService from '../../utils/AuthService';
import BiometricAuthService from '../../utils/BiometricAuthService';
import MultiServiceApiClient from '../../utils/MultiServiceApiClient'; // For direct API client access

export interface IPluginContext {
  logger: typeof Logger;
  config: typeof ConfigService;
  apiKeyManager: typeof ApiKeyManager;
  authService: typeof AuthService;
  biometricAuthService: typeof BiometricAuthService;
  apiClient: typeof MultiServiceApiClient; // To access multi-service API clients
  // Add other core services as they are defined (e.g., StorageService, WorkflowEngine, EventBus)
  // Add generic utility functions
}
