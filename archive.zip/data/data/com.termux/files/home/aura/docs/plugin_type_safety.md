# Plugin System Type Safety Considerations

This document outlines the strategies for ensuring type safety within Project OP's plugin system, covering both compile-time and runtime aspects.

## Compile-Time Type Safety (TypeScript)

Project OP leverages TypeScript as its primary mechanism for compile-time type safety. Plugin developers are expected to write their plugins in TypeScript (or provide TypeScript declaration files for JavaScript plugins) to ensure they adhere to the defined plugin interfaces.

### Enforcement:
*   **Interface Implementation**: All plugins (e.g., `IWorkflowNodePlugin`, `IIntegrationPlugin`, `IUiExtensionPlugin`) must explicitly implement the relevant TypeScript interfaces. The TypeScript compiler will enforce that all required properties and methods are present and correctly typed.
*   **Core Platform API**: The core platform provides its own APIs (e.g., `IPluginContext`, `IExecutionContext`) with well-defined types. Plugins interacting with these APIs will benefit from compile-time checks, preventing common integration errors.
*   **Shared Type Definitions**: Essential types (`PluginType`, `IDataDefinition`) are exported from the `types` directory, providing a single source of truth for plugin contracts.

### Plugin Development Guidelines:
*   **Use TypeScript**: Plugin developers are strongly encouraged to write plugins in TypeScript.
*   **Strict Mode**: Plugins should be developed with TypeScript's strict mode enabled (`"strict": true` in `tsconfig.json`) to catch potential type-related issues early.
*   **Type Declarations**: For plugins written in plain JavaScript, corresponding `.d.ts` (declaration) files should be provided to enable type checking when consumed by TypeScript projects.

## Runtime Type Checking (for untrusted inputs and dynamic loading)

While TypeScript provides excellent compile-time safety, plugins (especially those loaded dynamically or from external/untrusted sources) operate in a runtime environment where type contracts can be violated. Additionally, data flowing into workflow nodes (`IExecutionContext.data`) often comes from external sources and cannot be guaranteed to conform to `IInputDefinition` schemas at compile time.

### Strategy:
1.  **Plugin Manifest Validation**:
    *   When a plugin's `plugin.json` manifest is loaded, its structure will be validated against `IPluginManifest` at runtime. This can be achieved using schema validation libraries.
2.  **Input/Output Schema Validation for Workflow Nodes**:
    *   For `IWorkflowNodePlugin`, the `inputs` and `outputs` definitions (which can include `schema` properties) will be used to validate actual data (`IExecutionContext.data`) at runtime.
    *   Before executing `IWorkflowNodePlugin.execute()`, input data should be validated against `IInputDefinition.schema`.
    *   After execution, output data should be validated against `IOutputDefinition.schema` before propagating to the next node.
3.  **Runtime Plugin Object Validation**:
    *   When a plugin module is dynamically loaded, the instantiated plugin object should undergo basic runtime checks to ensure it possesses the expected properties and methods of its declared `PluginType`. This can involve custom type guard functions or schema validation on the plugin's instance properties.

### Recommended Libraries (Future Consideration):
*   **Zod**: A TypeScript-first schema declaration and validation library. Excellent for defining runtime schemas that are also type-inferred for TypeScript.
*   **Yup**: A schema builder for value parsing and validation. Widely used and robust.
*   **JSON Schema**: For complex input/output data structures, JSON Schema can be used to define portable validation rules that can be enforced at runtime.

### Example Runtime Validation (Pseudo-code for Zod):

```typescript
// Example: Validating workflow node input
import { z } from 'zod';
import { IInputDefinition } from './interfaces/workflow/IInputDefinition'; // Or similar

function validateNodeInput(inputData: Record<string, any>, inputDefinitions: IInputDefinition[]): boolean {
  for (const definition of inputDefinitions) {
    if (definition.schema) {
      // Use Zod schema from definition.schema to validate inputData[definition.name]
      const schema = z.object(definition.schema); // Simplified for example
      try {
        schema.parse(inputData[definition.name]);
      } catch (error) {
        console.error(`Validation failed for input '${definition.name}':`, error);
        return false;
      }
    } else if (definition.required && inputData[definition.name] === undefined) {
      console.error(`Required input '${definition.name}' is missing.`);
      return false;
    }
    // Basic type checking for primitive types
    if (inputData[definition.name] !== undefined && typeof inputData[definition.name] !== definition.type) {
        console.warn(`Input '${definition.name}' has unexpected type. Expected ${definition.type}, got ${typeof inputData[definition.name]}`);
        // Depending on strictness, this might be a failure
    }
  }
  return true;
}
```

This comprehensive approach ensures that the plugin system is robust against type-related issues throughout its lifecycle.
