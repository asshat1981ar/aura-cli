// __tests__/utils/services/DeepLService.test.ts
import DeepLService from '../../../utils/services/DeepLService';
import MultiServiceApiClient from '../../../utils/MultiServiceApiClient';
import { ApiService } from '../../../utils/ApiKeyManager';
import axios from 'axios';

// Mock MultiServiceApiClient to control the axios instance it returns
jest.mock('../../../utils/MultiServiceApiClient', () => ({
  getClient: jest.fn(),
}));

describe('DeepLService', () => {
  const mockText = 'Hello, world!';
  const mockOptions = { target_lang: 'es' };
  const mockResponseData = {
    translations: [{ detected_source_language: 'en', text: '¡Hola, mundo!' }],
  };

  const mockAxiosInstance = {
    post: jest.fn(),
  } as unknown as axios.AxiosInstance;

  beforeEach(() => {
    jest.clearAllMocks();
    (MultiServiceApiClient.getClient as jest.Mock).mockResolvedValue(mockAxiosInstance);
  });

  describe('translate', () => {
    it('should call translate API with string text and options', async () => {
      mockAxiosInstance.post.mockResolvedValue({ data: mockResponseData });

      const response = await DeepLService.translate(mockText, mockOptions);

      expect(MultiServiceApiClient.getClient).toHaveBeenCalledWith(ApiService.DeepL);
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/translate', {
        text: [mockText],
        target_lang: 'es',
        source_lang: undefined,
      });
      expect(response).toEqual(mockResponseData);
    });

    it('should call translate API with array of texts and options', async () => {
      mockAxiosInstance.post.mockResolvedValue({ data: mockResponseData });

      const texts = ['Hello', 'World'];
      const options = { target_lang: 'fr', source_lang: 'en' };
      const response = await DeepLService.translate(texts, options);

      expect(MultiServiceApiClient.getClient).toHaveBeenCalledWith(ApiService.DeepL);
      expect(mockAxiosInstance.post).toHaveBeenCalledWith('/translate', {
        text: texts,
        target_lang: 'fr',
        source_lang: 'en',
      });
      expect(response).toEqual(mockResponseData);
    });
  });
});
