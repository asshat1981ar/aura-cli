// __tests__/plugins/validation/WorkflowNodeDataValidator.test.ts
import WorkflowNodeDataValidator from '../../../plugins/validation/WorkflowNodeDataValidator';
import { IInputDefinition, IOutputDefinition } from '../../../types/workflow/IDataDefinition';
import Logger from '../../../utils/Logger';
import { z } from 'zod';

// Mock Logger
jest.mock('../../../utils/Logger', () => ({
  debug: jest.fn(),
  info: jest.fn(),
  warn: jest.fn(),
  error: jest.fn(),
}));

describe('WorkflowNodeDataValidator', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('validateInputData', () => {
    it('should successfully validate data with correct types and required fields', () => {
      const inputDefinitions: IInputDefinition[] = [
        { name: 'name', type: 'string', required: true },
        { name: 'age', type: 'number', required: true },
        { name: 'optionalField', type: 'boolean', required: false, defaultValue: false },
      ];
      const data = { name: 'Alice', age: 30 };
      expect(() => WorkflowNodeDataValidator.validateInputData(data, inputDefinitions)).not.toThrow();
      expect(Logger.debug).toHaveBeenCalledWith('Input data validated successfully.');
    });

    it('should throw ZodError for missing required fields', () => {
      const inputDefinitions: IInputDefinition[] = [{ name: 'name', type: 'string', required: true }];
      const data = { age: 30 }; // Missing 'name'
      expect(() => WorkflowNodeDataValidator.validateInputData(data, inputDefinitions)).toThrow(z.ZodError);
      expect(Logger.warn).toHaveBeenCalledWith(expect.stringContaining('Input data validation failed'), expect.any(z.ZodError));
    });

    it('should throw ZodError for incorrect data types', () => {
      const inputDefinitions: IInputDefinition[] = [{ name: 'age', type: 'number', required: true }];
      const data = { age: 'thirty' }; // Incorrect type
      expect(() => WorkflowNodeDataValidator.validateInputData(data, inputDefinitions)).toThrow(z.ZodError);
      expect(Logger.warn).toHaveBeenCalledWith(expect.stringContaining('Input data validation failed'), expect.any(z.ZodError));
    });

    it('should apply default values for optional fields', () => {
      const inputDefinitions: IInputDefinition[] = [
        { name: 'name', type: 'string', required: true },
        { name: 'isActive', type: 'boolean', required: false, defaultValue: true },
      ];
      const data = { name: 'Bob' };
      expect(() => WorkflowNodeDataValidator.validateInputData(data, inputDefinitions)).not.toThrow();
      // Note: Zod's .default() applies during .parse(). The data object itself won't be mutated by this validation call.
      // This test mainly ensures that the validation passes if a default is expected for a missing optional field.
      // To test the default value application, you would parse the data *through* the schema, which happens internally.
    });

    it('should validate enum types correctly', () => {
      const inputDefinitions: IInputDefinition[] = [
        { name: 'status', type: 'enum', options: ['pending', 'completed'], required: true },
      ];
      const validData = { status: 'pending' };
      expect(() => WorkflowNodeDataValidator.validateInputData(validData, inputDefinitions)).not.toThrow();
      const invalidData = { status: 'invalid_status' };
      expect(() => WorkflowNodeDataValidator.validateInputData(invalidData, inputDefinitions)).toThrow(z.ZodError);
    });
  });

  describe('validateOutputData', () => {
    it('should successfully validate data with correct types', () => {
      const outputDefinitions: IOutputDefinition[] = [
        { name: 'result', type: 'string', required: true },
      ];
      const data = { result: 'Operation successful' };
      expect(() => WorkflowNodeDataValidator.validateOutputData(data, outputDefinitions)).not.toThrow();
      expect(Logger.debug).toHaveBeenCalledWith('Output data validated successfully.');
    });

    it('should return without error if no output definitions are provided', () => {
      const outputDefinitions: IOutputDefinition[] = [];
      const data = { some: 'data' };
      expect(() => WorkflowNodeDataValidator.validateOutputData(data, outputDefinitions)).not.toThrow();
      expect(Logger.debug).toHaveBeenCalledWith('No output definitions provided, skipping output validation.');
    });

    it('should throw ZodError for incorrect output data types', () => {
      const outputDefinitions: IOutputDefinition[] = [{ name: 'count', type: 'number', required: true }];
      const data = { count: 'one' }; // Incorrect type
      expect(() => WorkflowNodeDataValidator.validateOutputData(data, outputDefinitions)).toThrow(z.ZodError);
      expect(Logger.warn).toHaveBeenCalledWith(expect.stringContaining('Output data validation failed'), expect.any(z.ZodError));
    });
  });
});
