// utils/AuthService.ts
import SecureStorage from './SecureStorage';

const ACCESS_TOKEN_KEY = 'oauth_access_token';
const REFRESH_TOKEN_KEY = 'oauth_refresh_token';
const ACCESS_TOKEN_EXPIRY_KEY = 'oauth_access_token_expiry'; // To store expiration time

class AuthService {
  /**
   * Stores access and refresh tokens along with access token expiry.
   */
  static async setTokens(accessToken: string, refreshToken: string, expiresIn: number): Promise<void> {
    const expiryTime = Date.now() + (expiresIn * 1000); // expiresIn is usually in seconds
    await SecureStorage.setItem(ACCESS_TOKEN_KEY, accessToken);
    await SecureStorage.setItem(REFRESH_TOKEN_KEY, refreshToken);
    await SecureStorage.setItem(ACCESS_TOKEN_EXPIRY_KEY, String(expiryTime)); // Store as string
  }

  /**
   * Retrieves the access token.
   */
  static async getAccessToken(): Promise<string | null> {
    return await SecureStorage.getItem(ACCESS_TOKEN_KEY);
  }

  /**
   * Retrieves the refresh token.
   */
  static async getRefreshToken(): Promise<string | null> {
    return await SecureStorage.getItem(REFRESH_TOKEN_KEY);
  }

  /**
   * Checks if the access token is expired.
   */
  static async isAccessTokenExpired(): Promise<boolean> {
    const expiryTimeStr = await SecureStorage.getItem(ACCESS_TOKEN_EXPIRY_KEY);
    if (!expiryTimeStr) return true; // No expiry info means it's effectively expired or never set
    
    const expiryTime = Number(expiryTimeStr);
    return Date.now() >= expiryTime;
  }

  /**
   * Clears all OAuth tokens.
   */
  static async clearTokens(): Promise<void> {
    await SecureStorage.deleteItem(ACCESS_TOKEN_KEY);
    await SecureStorage.deleteItem(REFRESH_TOKEN_KEY);
    await SecureStorage.deleteItem(ACCESS_TOKEN_EXPIRY_KEY);
  }

  /**
   * Simulates a token refresh request to an authentication server.
   * In a real app, this would be an actual API call.
   * @param refreshToken The current refresh token.
   * @returns Promise<{accessToken: string, refreshToken: string, expiresIn: number} | null> New tokens or null if refresh fails.
   */
  static async refreshAccessToken(refreshToken: string): Promise<{accessToken: string, refreshToken: string, expiresIn: number} | null> {
    console.log("Simulating token refresh with refresh token:", refreshToken);
    // TODO: Replace with actual API call to your authentication server
    await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate network request

    if (refreshToken === "valid_refresh_token") { // Placeholder for actual validation
      const newAccessToken = "new_simulated_access_token_" + Date.now();
      const newRefreshToken = "new_simulated_refresh_token_" + Date.now();
      const newExpiresIn = 3600; // 1 hour
      await AuthService.setTokens(newAccessToken, newRefreshToken, newExpiresIn);
      return { accessToken: newAccessToken, refreshToken: newRefreshToken, expiresIn: newExpiresIn };
    }
    return null; // Refresh failed
  }
}

export default AuthService;
