// utils/MultiServiceApiClient.ts
import { ApiService, ApiKeyManager } from './ApiKeyManager';
import apiClient from './ApiClient'; // Assuming this is your base Axios client with interceptors
import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';
import AuthService from './AuthService'; // For OAuth details if needed

// Define base URLs for different services (these would typically be in a config file)
const SERVICE_BASE_URLS: Record<ApiService, string> = {
  [ApiService.OpenAI]: 'https://api.openai.com/v1',
  [ApiService.Anthropic]: 'https://api.anthropic.com/v1',
  [ApiService.Google]: 'https://generativelanguage.googleapis.com/v1', // Example for Google Gemini API
  [ApiService.DeepL]: 'https://api-free.deepl.com/v2', // Example for DeepL
};

/**
 * MultiServiceApiClient manages API requests to various AI services.
 * It integrates API key management and OAuth handling.
 */
class MultiServiceApiClient {
  private static clients: Map<ApiService, AxiosInstance> = new Map();

  /**
   * Returns an Axios instance configured for a specific API service.
   * Handles API key or OAuth token injection automatically.
   * @param service The API service to get a client for.
   * @returns A configured Axios instance.
   */
  static async getClient(service: ApiService): Promise<AxiosInstance> {
    if (MultiServiceApiClient.clients.has(service)) {
      return MultiServiceApiClient.clients.get(service)!;
    }

    const newClient = axios.create({
      baseURL: SERVICE_BASE_URLS[service],
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Add a request interceptor to inject API keys or OAuth tokens
    newClient.interceptors.request.use(
      async (config: AxiosRequestConfig) => {
        // --- API Key Handling ---
        const apiKey = await ApiKeyManager.getApiKey(service);
        if (apiKey) {
          // Specific header for each service (adjust as needed)
          if (!config.headers) config.headers = {};
          switch (service) {
            case ApiService.OpenAI:
              config.headers.Authorization = `Bearer ${apiKey}`;
              break;
            case ApiService.Anthropic:
              config.headers['x-api-key'] = apiKey;
              break;
            case ApiService.Google:
              config.params = { ...config.params, key: apiKey }; // Google often uses query param
              break;
            case ApiService.DeepL:
              config.headers.Authorization = `DeepL-Auth-Key ${apiKey}`;
              break;
            default:
              console.warn(`No specific API key header defined for service: ${service}`);
              break;
          }
        }
        // --- OAuth Token Handling (if applicable, can be more complex) ---
        // If a service uses OAuth, the existing `apiClient` (from ApiClient.ts)
        // should ideally be used or its interceptor logic replicated/integrated here.
        // For simplicity and to avoid circular deps with `ApiClient.ts`,
        // this client focuses on API keys. If a service requires OAuth, it would
        // be configured through `AuthService` and potentially use `apiClient` directly.
        // For multi-service, OAuth might be shared or service-specific.
        // This is a design decision. For now, assume API key is dominant for these services.
        // If the primary `apiClient` is *always* used for all requests, then this
        // MultiServiceApiClient could just return a configured `apiClient` with
        // service-specific headers/base_url. For now, it creates its own axios instance.
        
        return config;
      },
      (error) => Promise.reject(error)
    );

    MultiServiceApiClient.clients.set(service, newClient);
    return newClient;
  }

}

export default MultiServiceApiClient;
