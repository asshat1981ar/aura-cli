// types/plugin/IIntegrationPlugin.ts
import { IPlugin } from './IPlugin';
import { PluginType } from './PluginType';

export interface IIntegrationPlugin extends IPlugin {
  type: PluginType.Integration; // Enforce specific plugin type

  integratesWith: string[]; // List of services/systems this plugin integrates with

  /**
   * Provides access to the integrated service client or SDK instance.
   * @param serviceId The ID of the specific service to access (from integratesWith list).
   * @returns An instance of the service client/SDK.
   */
  getService(serviceId: string): any; // Return type 'any' for flexibility, can be refined with generics
}
