// __tests__/utils/BiometricAuthService.test.ts
import BiometricAuthService from '../../utils/BiometricAuthService';
import * as LocalAuthentication from 'expo-local-authentication';
import SecureStorage from '../../utils/SecureStorage';

jest.mock('expo-local-authentication', () => ({
  hasHardwareAsync: jest.fn(),
  isEnrolledAsync: jest.fn(),
  authenticateAsync: jest.fn(),
}));

jest.mock('../../utils/SecureStorage', () => ({
  setItem: jest.fn(),
  getItem: jest.fn(),
}));

describe('BiometricAuthService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('isBiometricAvailableAndEnrolled', () => {
    it('should return true if hardware is available and enrolled', async () => {
      (LocalAuthentication.hasHardwareAsync as jest.Mock).mockResolvedValue(true);
      (LocalAuthentication.isEnrolledAsync as jest.Mock).mockResolvedValue(true);
      await expect(BiometricAuthService.isBiometricAvailableAndEnrolled()).resolves.toBe(true);
    });

    it('should return false if hardware is not available', async () => {
      (LocalAuthentication.hasHardwareAsync as jest.Mock).mockResolvedValue(false);
      (LocalAuthentication.isEnrolledAsync as jest.Mock).mockResolvedValue(true);
      await expect(BiometricAuthService.isBiometricAvailableAndEnrolled()).resolves.toBe(false);
    });

    it('should return false if not enrolled', async () => {
      (LocalAuthentication.hasHardwareAsync as jest.Mock).mockResolvedValue(true);
      (LocalAuthentication.isEnrolledAsync as jest.Mock).mockResolvedValue(false);
      await expect(BiometricAuthService.isBiometricAvailableAndEnrolled()).resolves.toBe(false);
    });
  });

  describe('isBiometricEnabledByUser', () => {
    it('should return true if biometric is enabled in SecureStorage', async () => {
      (SecureStorage.getItem as jest.Mock).mockResolvedValue('true');
      await expect(BiometricAuthService.isBiometricEnabledByUser()).resolves.toBe(true);
    });

    it('should return false if biometric is not enabled in SecureStorage', async () => {
      (SecureStorage.getItem as jest.Mock).mockResolvedValue('false');
      await expect(BiometricAuthService.isBiometricEnabledByUser()).resolves.toBe(false);
    });

    it('should return false if no setting found in SecureStorage', async () => {
      (SecureStorage.getItem as jest.Mock).mockResolvedValue(null);
      await expect(BiometricAuthService.isBiometricEnabledByUser()).resolves.toBe(false);
    });
  });

  it('should set biometric enabled status in SecureStorage', async () => {
    await BiometricAuthService.setBiometricEnabled(true);
    expect(SecureStorage.setItem).toHaveBeenCalledWith('biometric_auth_enabled', 'true');
    await BiometricAuthService.setBiometricEnabled(false);
    expect(SecureStorage.setItem).toHaveBeenCalledWith('biometric_auth_enabled', 'false');
  });

  describe('authenticate', () => {
    it('should authenticate successfully if available', async () => {
      jest.spyOn(BiometricAuthService, 'isBiometricAvailableAndEnrolled').mockResolvedValue(true);
      (LocalAuthentication.authenticateAsync as jest.Mock).mockResolvedValue({ success: true });
      await expect(BiometricAuthService.authenticate('Test Prompt')).resolves.toEqual({ success: true });
      expect(LocalAuthentication.authenticateAsync).toHaveBeenCalledWith({
        promptMessage: 'Test Prompt',
        fallbackLabel: 'Use Passcode',
        disableDeviceFallback: false,
      });
    });

    it('should return error if biometric not available', async () => {
      jest.spyOn(BiometricAuthService, 'isBiometricAvailableAndEnrolled').mockResolvedValue(false);
      await expect(BiometricAuthService.authenticate('Test Prompt')).resolves.toEqual({
        success: false,
        error: 'BIOMETRIC_NOT_AVAILABLE',
        warning: 'Biometric hardware not available or not enrolled.',
      });
      expect(LocalAuthentication.authenticateAsync).not.toHaveBeenCalled();
    });
  });

  describe('authenticateIfEnabled', () => {
    it('should authenticate successfully if enabled and available', async () => {
      jest.spyOn(BiometricAuthService, 'isBiometricAvailableAndEnrolled').mockResolvedValue(true);
      jest.spyOn(BiometricAuthService, 'isBiometricEnabledByUser').mockResolvedValue(true);
      jest.spyOn(BiometricAuthService, 'authenticate').mockResolvedValue({ success: true });

      await expect(BiometricAuthService.authenticateIfEnabled('login')).resolves.toEqual({
        success: true,
        requiresFallback: false,
      });
      expect(BiometricAuthService.authenticate).toHaveBeenCalledWith('Authenticate to login');
    });

    it('should require fallback if biometric failed but enabled and available', async () => {
      jest.spyOn(BiometricAuthService, 'isBiometricAvailableAndEnrolled').mockResolvedValue(true);
      jest.spyOn(BiometricAuthService, 'isBiometricEnabledByUser').mockResolvedValue(true);
      jest.spyOn(BiometricAuthService, 'authenticate').mockResolvedValue({ success: false, error: 'some_error' });

      const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
      await expect(BiometricAuthService.authenticateIfEnabled('login')).resolves.toEqual({
        success: false,
        requiresFallback: true,
        error: 'some_error',
      });
      expect(consoleLogSpy).toHaveBeenCalledWith("Biometric authentication failed:", 'some_error');
      consoleLogSpy.mockRestore();
    });

    it('should require fallback if not enabled by user', async () => {
      jest.spyOn(BiometricAuthService, 'isBiometricAvailableAndEnrolled').mockResolvedValue(true);
      jest.spyOn(BiometricAuthService, 'isBiometricEnabledByUser').mockResolvedValue(false);

      const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
      await expect(BiometricAuthService.authenticateIfEnabled('login')).resolves.toEqual({
        success: false,
        requiresFallback: true,
        error: 'BIOMETRIC_DISABLED_BY_USER',
      });
      expect(consoleLogSpy).toHaveBeenCalledWith("Biometric authentication is not enabled by the user.");
      consoleLogSpy.mockRestore();
    });

    it('should require fallback if not available or enrolled', async () => {
      jest.spyOn(BiometricAuthService, 'isBiometricAvailableAndEnrolled').mockResolvedValue(false);
      jest.spyOn(BiometricAuthService, 'isBiometricEnabledByUser').mockResolvedValue(true); // Enabled but not available

      const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
      await expect(BiometricAuthService.authenticateIfEnabled('login')).resolves.toEqual({
        success: false,
        requiresFallback: true,
        error: 'BIOMETRIC_NOT_AVAILABLE_OR_ENROLLED',
      });
      expect(consoleLogSpy).toHaveBeenCalledWith("Biometric authentication not available or not enrolled.");
      consoleLogSpy.mockRestore();
    });
  });
});
